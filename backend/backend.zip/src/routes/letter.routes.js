import express from "express";
import multer from "multer";
import {
    getLetters,
    getLetterById,
    getLetterBySlug,
    createLetter,
    updateLetter,
    deleteLetter,
} from "../controllers/letter.controller.js";

// تنظیم مسیر ذخیره فایل‌ها (می‌توانید تنظیمات دیگر multer مانند نام فایل و ... هم اضافه کنید)
const upload = multer({ dest: "uploads/" });

const router = express.Router();

// گرفتن همه نامه‌ها + سرچ
router.get("/", getLetters);

// گرفتن نامه با slug (این مسیر باید قبل از مسیر with :id باشد)
router.get("/slug/:slug", getLetterBySlug);

// گرفتن نامه با id
router.get("/:id", getLetterById);

// ایجاد نامه جدید با پشتیبانی آپلود چند فایل در کلید "images"
router.post("/", upload.array("images"), createLetter);

// ویرایش نامه با پشتیبانی آپلود چند فایل در کلید "images"
router.put("/:id", upload.array("images"), updateLetter);

// حذف نامه
router.delete("/:id", deleteLetter);

export default router;
