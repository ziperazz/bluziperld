import express from "express";
import {
    createPayment,
    verifyPayment,
} from "../controllers/payment.controller.js";

const router = express.Router();

router.post("/request", createPayment);

router.get("/verify", verifyPayment);

export default router;
