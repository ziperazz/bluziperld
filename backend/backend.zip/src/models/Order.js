import mongoose from "mongoose";

const CartItemSchema = new mongoose.Schema({
    productId: { type: String, required: true },
    productType: { type: String, required: true },

    title: { type: String }, // اضافه شد
    image: { type: String }, // اضافه شد

    price: { type: Number, required: true },
    priceAfterDiscount: { type: Number }, // اضافه شد (فرانت ممکنه بفرسته)

    quantity: { type: Number, required: true },

    writingType: { type: String, default: null }, // اضافه شد
    letterText: { type: String, default: null },
});

const OrderSchema = new mongoose.Schema(
    {
        trackingCode: { type: String, required: true, unique: true },

        user: {
            type: mongoose.Schema.Types.ObjectId,
            ref: "User",
            required: true,
        },

        cart: [CartItemSchema],

        shipping: {
            fullName: String,
            phone: String,
            address: String,
            province: String,
            city: String,
            postalCode: String,
            shippingMethod: String,
            shippingPrice: Number,
            note: String, // ← اضافه شد
        },


        subtotal: Number,
        shippingCost: Number,
        total: Number,

        status: {
            type: String,
            default: "AWAITING_ADMIN_REVIEW",
        },

        fakeOrderIdFromGateway: String,
    },
    { timestamps: true }
);

export default mongoose.model("Order", OrderSchema);
