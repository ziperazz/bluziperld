const MERCHANT = process.env.ZARINPAL_MERCHANT_ID;
const isSandbox = process.env.ZARINPAL_MODE === "sandbox";

const requestURL = isSandbox
    ? "https://sandbox.zarinpal.com/pg/v4/payment/request.json"
    : "https://api.zarinpal.com/pg/v4/payment/request.json";

const startPayURL = isSandbox
    ? "https://sandbox.zarinpal.com/pg/StartPay/"
    : "https://www.zarinpal.com/pg/StartPay/";

const verifyURL = isSandbox
    ? "https://sandbox.zarinpal.com/pg/v4/payment/verify.json"
    : "https://api.zarinpal.com/pg/v4/payment/verify.json";


/* ---------------- CREATE PAYMENT ---------------- */

export const createPayment = async (req, res) => {
    try {
        const MERCHANT = process.env.ZARINPAL_MERCHANT_ID;
        const isSandbox = process.env.ZARINPAL_MODE === "sandbox";

        if (!MERCHANT) {
            return res.status(500).json({
                success: false,
                message: "Merchant ID تنظیم نشده است",
            });
        }

        const requestURL = isSandbox
            ? "https://sandbox.zarinpal.com/pg/v4/payment/request.json"
            : "https://api.zarinpal.com/pg/v4/payment/request.json";

        const startPayURL = isSandbox
            ? "https://sandbox.zarinpal.com/pg/StartPay/"
            : "https://www.zarinpal.com/pg/StartPay/";

        const { amount } = req.body;

        if (!amount || amount < 1000) {
            return res.status(400).json({
                success: false,
                message: "مبلغ پرداخت نامعتبر است",
            });
        }

        const callback_url = `${process.env.FRONTEND_URL}/payment/verify`;

        console.log("MERCHANT:", MERCHANT);
        console.log("AMOUNT:", amount);
        console.log("CALLBACK:", callback_url);

        const response = await fetch(requestURL, {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
                "Accept": "application/json"
            },
            body: JSON.stringify({
                merchant_id: MERCHANT,
                amount: Number(amount),
                callback_url,
                description: "پرداخت سفارش",
            }),
        });

        const text = await response.text();

        let data;
        try {
            data = JSON.parse(text);
        } catch (err) {
            console.error("ZARINPAL RAW RESPONSE:", text);
            throw new Error("Invalid JSON from Zarinpal");
        }

        console.log("ZARINPAL REQUEST RESPONSE:", data);


        if (data?.data?.authority) {
            return res.json({
                success: true,
                url: `${startPayURL}${data.data.authority}`,
                authority: data.data.authority,
            });
        }

        return res.status(400).json({
            success: false,
            message: "زرین پال authority برنگرداند",
            zarinpal: data,
        });

    } catch (error) {
        console.error("ZARINPAL REQUEST ERROR:", error);
        res.status(500).json({
            success: false,
            message: "خطا در اتصال به زرین پال",
        });
    }
};


/* ---------------- VERIFY PAYMENT ---------------- */

export const verifyPayment = async (req, res) => {
    try {
        const MERCHANT = process.env.ZARINPAL_MERCHANT_ID;

        if (!MERCHANT) {
            return res.status(500).json({
                success: false,
                message: "Merchant ID تنظیم نشده است",
            });
        }

        const { Authority, Status } = req.query;

        if (!Authority || Status !== "OK") {
            return res.json({
                success: false,
                message: "پرداخت لغو شد",
            });
        }

        const response = await fetch(verifyURL, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
                merchant_id: MERCHANT,
                authority: Authority,
                amount: 1000, // بعداً از DB بخون
            }),
        });

        const data = await response.json();
        console.log("ZARINPAL VERIFY RESPONSE:", data);

        if (data?.data?.code === 100) {
            return res.json({
                success: true,
                refId: data.data.ref_id,
            });
        }

        return res.json({
            success: false,
            message: "تایید پرداخت ناموفق",
            zarinpal: data,
        });

    } catch (error) {
        console.error("ZARINPAL VERIFY ERROR:", error);
        res.status(500).json({
            success: false,
            message: "خطا در تایید پرداخت",
        });
    }
};
