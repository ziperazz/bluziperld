import Letter from "../models/letter.js";

const createSlug = (text) => {
    return text
        .toString()
        .trim()
        .toLowerCase()
        .replace(/[\u200c]/g, " ")         // حذف نیم‌فاصله
        .replace(/\s+/g, "-")              // جایگزینی فاصله با خط تیره
        .replace(/[^\u0600-\u06FFa-z0-9\-]/g, "") // حذف کاراکترهای غیرمجاز
        .replace(/\-\-+/g, "-")            // حذف تکرار خط تیره
        .replace(/^-+|-+$/g, "");          // حذف خط تیره‌های ابتدا و انتها
};


// تبدیل امن مقدار به آرایه
const normalizeToArray = (value) => {
    if (!value) return [];
    return Array.isArray(value) ? value : [value];
};

// تبدیل specs
const parseSpecs = (specs) => {
    if (!specs) return [];
    if (Array.isArray(specs)) return specs;

    try {
        return JSON.parse(specs);
    } catch {
        return [];
    }
};

// ساخت آدرس فایل‌های آپلودشده
const mapUploadedFiles = (files) => {
    if (!files || !Array.isArray(files)) return [];
    return files.map((file) => `/uploads/${file.filename}`);
};

// =========================
// دریافت همه نامه‌ها + سرچ
// =========================
export const getLetters = async (req, res) => {
    try {
        const { search } = req.query;

        let filter = {};

        // اگر سرچ وجود داشت
        if (search) {
            filter = {
                $or: [
                    { title: { $regex: search, $options: "i" } },
                    { description: { $regex: search, $options: "i" } },
                    { category: { $regex: search, $options: "i" } }
                ]
            };
        }

        const letters = await Letter.find(filter).sort({ createdAt: -1 });

        res.json(letters);
    } catch (error) {
        console.error("خطا در دریافت نامه‌ها:", error);
        res.status(500).json({ message: "خطا در دریافت نامه‌ها" });
    }
};

// =========================
// دریافت یک نامه با id + افزایش بازدید
// =========================
export const getLetterById = async (req, res) => {
    try {
        // ⚠️ همین یک تغییر: همزمان با برگرداندن نامه، visits را ۱ واحد زیاد می‌کنیم
        const letter = await Letter.findByIdAndUpdate(
            req.params.id,
            { $inc: { visits: 1 } },
            { new: true }
        );

        if (!letter) {
            return res.status(404).json({ message: "نامه پیدا نشد" });
        }

        res.json(letter);
    } catch (error) {
        console.error("خطا در دریافت نامه:", error);
        res.status(500).json({ message: "خطا در دریافت نامه" });
    }
};

// =========================
// ایجاد نامه جدید
// =========================
export const createLetter = async (req, res) => {
    try {
        const uploadedImages = mapUploadedFiles(req.files);

        const slug = createSlug(req.body.title);

        // اگر بخواهی می‌توانی چک کنی که slug تکراری نباشد و به صورت هوشمند شماره‌دار کنی

        const newLetter = new Letter({
            title: req.body.title,
            slug,
            description: req.body.description || "",
            category: req.body.category || "",
            price: Number(req.body.price) || 0,
            discount: Number(req.body.discount) || 0,
            instock: Number(req.body.instock) || 0,
            isActive: req.body.isActive === "true" || req.body.isActive === true,
            printingExtraPrice: Number(req.body.printingExtraPrice) || 0,
            handwritingExtraPrice: Number(req.body.handwritingExtraPrice) || 0,
            visits: Number(req.body.visits) || 0,
            purchaseCount: Number(req.body.purchaseCount) || 0,
            ratingAverage: Number(req.body.ratingAverage) || 0,
            rating: Number(req.body.rating) || 0,
            specs: parseSpecs(req.body.specs),
            images: uploadedImages,
        });

        const savedLetter = await newLetter.save();
        res.status(201).json(savedLetter);
    } catch (error) {
        console.error("خطا در ایجاد نامه:", error);
        res.status(500).json({
            message: "خطا در ایجاد نامه",
            error: error.message,
        });
    }
};

// =========================
// ویرایش نامه
// =========================
export const updateLetter = async (req, res) => {
    try {
        const letter = await Letter.findById(req.params.id);

        if (!letter) {
            return res.status(404).json({ message: "نامه پیدا نشد" });
        }

        // عکس‌های قبلی که از فرانت نگه داشته شده‌اند
        const existingImages = normalizeToArray(req.body.existingImages).filter(Boolean);

        // عکس‌های جدید آپلود شده
        const uploadedImages = mapUploadedFiles(req.files);

        // ترکیب نهایی تصاویر
        const finalImages = [...existingImages, ...uploadedImages];

        // اگر عنوان تغییر کرده، slug را هم بروز کن
        if (req.body.title && req.body.title !== letter.title) {
            letter.title = req.body.title;
            letter.slug = createSlug(req.body.title);  // ← ساخت slug جدید
        } else {
            letter.title = letter.title;
        }

        letter.description = req.body.description ?? letter.description;
        letter.category = req.body.category ?? letter.category;
        letter.price = req.body.price !== undefined ? Number(req.body.price) : letter.price;
        letter.discount = req.body.discount !== undefined ? Number(req.body.discount) : letter.discount;
        letter.instock = req.body.instock !== undefined ? Number(req.body.instock) : letter.instock;

        if (req.body.isActive !== undefined) {
            letter.isActive = req.body.isActive === "true" || req.body.isActive === true;
        }

        letter.printingExtraPrice = req.body.printingExtraPrice !== undefined ? Number(req.body.printingExtraPrice) : letter.printingExtraPrice;
        letter.handwritingExtraPrice = req.body.handwritingExtraPrice !== undefined ? Number(req.body.handwritingExtraPrice) : letter.handwritingExtraPrice;

        letter.visits = req.body.visits !== undefined ? Number(req.body.visits) : letter.visits;
        letter.purchaseCount = req.body.purchaseCount !== undefined ? Number(req.body.purchaseCount) : letter.purchaseCount;
        letter.ratingAverage = req.body.ratingAverage !== undefined ? Number(req.body.ratingAverage) : letter.ratingAverage;
        letter.rating = req.body.rating !== undefined ? Number(req.body.rating) : letter.rating;

        if (req.body.specs !== undefined) {
            letter.specs = parseSpecs(req.body.specs);
        }

        letter.images = finalImages;

        const updatedLetter = await letter.save();
        res.json(updatedLetter);
    } catch (error) {
        console.error("خطا در ویرایش نامه:", error);
        res.status(500).json({
            message: "خطا در ویرایش نامه",
            error: error.message,
        });
    }
};


// =========================
// حذف نامه
// =========================
export const deleteLetter = async (req, res) => {
    try {
        const deletedLetter = await Letter.findByIdAndDelete(req.params.id);

        if (!deletedLetter) {
            return res.status(404).json({ message: "نامه پیدا نشد" });
        }

        res.json({ message: "نامه با موفقیت حذف شد" });
    } catch (error) {
        console.error("خطا در حذف نامه:", error);
        res.status(500).json({ message: "خطا در حذف نامه" });
    }
};
export const getLetterBySlug = async (req, res) => {
    try {
        const letter = await Letter.findOne({ slug: req.params.slug });
        if (!letter) {
            return res.status(404).json({ message: "نامه پیدا نشد" });
        }
        res.json(letter);
    } catch (error) {
        console.error("خطا در دریافت نامه:", error);
        res.status(500).json({ message: "خطا در دریافت نامه" });
    }
};
