"use client"

import { useState, useEffect, useRef } from "react"
import { ShoppingCart, Trash2, Plus, Minus } from "lucide-react"
import Link from "next/link"

export default function CartDropdown() {
  const [open, setOpen] = useState(false)
  const containerRef = useRef<HTMLDivElement | null>(null)
  const [cart, setCart] = useState<any[]>([])

  const loadCart = () => {
    const saved = JSON.parse(localStorage.getItem("cart") || "[]")
    setCart(saved)
  }

  useEffect(() => {
    loadCart()
  }, [])

  useEffect(() => {
    const handler = () => loadCart()
    window.addEventListener("cart-updated", handler)
    return () => window.removeEventListener("cart-updated", handler)
  }, [])

  useEffect(() => {
    localStorage.setItem("cart", JSON.stringify(cart))
  }, [cart])

  const changeQty = (productId: string, delta: number) => {
    const updated = cart.map(i =>
      i.productId === productId
        ? { ...i, quantity: Math.max(1, i.quantity + delta) }
        : i
    )

    setCart(updated)
    localStorage.setItem("cart", JSON.stringify(updated))
    window.dispatchEvent(new Event("cart-updated"))
  }

  const removeItem = (productId: string) => {
    const updated = cart.filter(i => i.productId !== productId)
    setCart(updated)
    localStorage.setItem("cart", JSON.stringify(updated))
    window.dispatchEvent(new Event("cart-updated"))
  }

  useEffect(() => {
    const handleClick = (e: MouseEvent) => {
      if (containerRef.current && !containerRef.current.contains(e.target as Node)) {
        setOpen(false)
      }
    }
    document.addEventListener("mousedown", handleClick)
    return () => document.removeEventListener("mousedown", handleClick)
  }, [])

  const totalQty = cart.reduce((a, b) => a + b.quantity, 0)
  const totalPrice = cart.reduce((a, b) => a + b.quantity * b.price, 0)

  return (
    <div className="relative" ref={containerRef}>
      <button
        onClick={() => setOpen(o => !o)}
        className="relative flex items-center cursor-pointer hover:opacity-80 transition"
      >
        <ShoppingCart size={21} className="text-gray-200" />

        <span
          className="absolute -top-1 -right-2 text-[10px] px-1.5 py-[1px] rounded-full text-white font-medium"
          style={{
            background: "linear-gradient(135deg,#2563eb,#3b82f6)",
            boxShadow: "0 0 6px rgba(37,99,235,0.45)",
          }}
        >
          {totalQty}
        </span>
      </button>

      {open && (
        <div
          className="absolute top-0 left-full ml-3 w-64 h-[380px] flex flex-col rounded-2xl p-3 shadow-xl animate-fadeIn z-50"
          style={{
            background: "rgba(10,12,18,0.72)",
            backdropFilter: "blur(65px) saturate(140%)",
            WebkitBackdropFilter: "blur(65px) saturate(140%)",
            border: "1px solid rgba(255,255,255,0.08)",
            boxShadow: "0 20px 60px rgba(0,0,0,0.8)"
          }}
        >
          <p className="text-gray-100 text-xs mb-2 font-medium tracking-wide">
            سبد خرید ({totalQty})
          </p>

          <div className="flex-1 overflow-y-auto pr-1 fancy-scroll">
            {cart.length === 0 && (
              <p className="text-gray-400 text-center py-3 text-sm">
                سبد خالیه! زود پر کن جیگر 😁
              </p>
            )}

            {cart.map(item => (
              <div
                key={`${item.productId}-${item.writingType}-${item.letterText?.slice(0, 10)}`}
                className="flex items-center gap-3 mb-3 pb-3 border-b border-white/10"
              >
                <img
                  src={item.image}
                  className="w-10 h-10 rounded-lg object-cover shadow-md"
                  alt={item.title}
                />

                <div className="flex flex-col w-[48%]">
                  <span className="text-gray-100 text-xs font-medium">
                    {item.title.slice(0,5)}
                  </span>

                  {item.productType === "letter" && item.letterText && (
                    <span className="text-[10px] text-gray-400 mt-1">
                      {item.letterText.slice(0,4)}...
                    </span>
                  )}

                  <div className="flex items-center gap-2 mt-1">
                    <button
                      onClick={() => changeQty(item.productId, -1)}
                      className="text-gray-400 hover:text-white transition"
                    >
                      <Minus size={12} />
                    </button>

                    <span className="text-gray-200 text-xs">
                      {item.quantity}
                    </span>

                    <button
                      onClick={() => changeQty(item.productId, +1)}
                      className="text-gray-400 hover:text-white transition"
                    >
                      <Plus size={12} />
                    </button>
                  </div>
                </div>

                <span className="text-blue-400 text-xs ml-auto whitespace-nowrap">
                  {(item.quantity * item.price).toLocaleString()} تومان
                </span>

                <button
                  onClick={() => removeItem(item.productId)}
                  className="text-red-400 hover:text-red-500 transition ml-1"
                >
                  <Trash2 size={14} />
                </button>
              </div>
            ))}
          </div>

          {cart.length > 0 && (
            <div className="pt-2 border-t border-white/10 mt-1">
              <div className="flex justify-between text-xs text-gray-300 mb-2">
                <span>جمع کل:</span>
                <span className="text-blue-400 font-medium">
                  {totalPrice.toLocaleString()} تومان
                </span>
              </div>

              <Link
                href="/cart"
                className="w-full py-2 rounded-xl text-xs font-medium text-white text-center block transition"
                style={{
                  background: "linear-gradient(135deg,#2563eb,#3b82f6)",
                  boxShadow: "0 0 10px rgba(37,99,235,0.32)",
                }}
              >
                مشاهده سبد خرید
              </Link>
            </div>
          )}
        </div>
      )}
    </div>
  )
}
