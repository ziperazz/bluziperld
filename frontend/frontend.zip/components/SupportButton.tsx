"use client";

import { Headset } from "lucide-react";
import Link from "next/link";

export default function SupportButton() {
  return (
    <Link
      href="/support/new"
      className="
        fixed bottom-6 left-6
        w-13 h-13
        flex items-center justify-center
        rounded-full
        bg-white/10
        backdrop-blur-sm
        border border-[#2a475e]
        text-[#c7d5e0]
        hover:text-white
        hover:border-[#66c0f4]
        hover:shadow-lg
        transition
        z-50
        "
    >
      <Headset size={22} />
    </Link>
  );
}
