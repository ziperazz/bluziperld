"use client";

import React, { useEffect, useState, useCallback } from "react";
import dayjs from "dayjs";
import "dayjs/locale/fa";
import jalaliday from "jalaliday";
import {
  FaStar,
  FaRegStar,
  FaThumbsUp,
  FaThumbsDown,
  FaUserCircle,
  FaShoppingBag,
  FaCheckCircle,
} from "react-icons/fa";

dayjs.extend(jalaliday);
dayjs.locale("fa");

/* ---------------------------------------------
   Types
--------------------------------------------- */

interface User {
  name: string;
}
interface CommentType {
  _id: string;
  content: string;
  rating: number;
  isBuyer: boolean;
  user: User;
  likes: string[];
  dislikes: string[];
  createdAt: string;
  replies: CommentType[];
  parent?: string | null;
}
interface Props {
  productId: string;
  currentUserId?: string;
  token?: string;
  targetType: "product" | "letter";
}
const PAGE_LIMIT = 5;
const api =
  process.env.NEXT_PUBLIC_API_URL?.replace(/\/+$/, "") ||
  "http://localhost:5000";

/* ---------------------------------------------
   نمایش ستاره‌ها
--------------------------------------------- */
const StarDisplay = ({ rating }: { rating: number }) => (
  <div className="flex gap-0.5 text-blue-400 drop-shadow-md">
    {[1, 2, 3, 4, 5].map((i) =>
      i <= rating ? <FaStar key={i} /> : <FaRegStar key={i} />
    )}
  </div>
);

const StarInput = ({
  rating,
  setRating,
}: {
  rating: number;
  setRating: (v: number) => void;
}) => (
  <div className="flex gap-2 text-blue-400">
    {[1, 2, 3, 4, 5].map((i) => (
      <button
        key={i}
        type="button"
        onClick={() => setRating(i)}
        className="hover:scale-125 transition ease-out"
      >
        {i <= rating ? <FaStar /> : <FaRegStar />}
      </button>
    ))}
  </div>
);

/* ---------------------------------------------
   MAIN
--------------------------------------------- */
export default function CommentsSection({
  productId,
  token,
  currentUserId,
  targetType,
}: Props) {
  const [comments, setComments] = useState<CommentType[]>([]);
  const [page, setPage] = useState(1);
  const [loading, setLoading] = useState(true);
  const [content, setContent] = useState("");
  const [rating, setRating] = useState(5);
  const [sending, setSending] = useState(false);
  const [notif, setNotif] = useState(false); // 🔔 کنترل نوتیف

  /* -----------------------------------------
     Fetch Comments
  ----------------------------------------- */
  const fetchComments = useCallback(async () => {
    try {
      setLoading(true);
      const res = await fetch(
        `${api}/api/comments/${targetType}/${productId}?page=${page}&limit=${PAGE_LIMIT}`
      );
      const data = await res.json();
      setComments(data);
    } catch (err) {
      console.error("fetch err:", err);
    }
    setLoading(false);
  }, [productId, page, targetType]);

  useEffect(() => {
    fetchComments();
  }, [fetchComments]);

  /* -----------------------------------------
     Submit
  ----------------------------------------- */
  const submitComment = async () => {
    if (!token) return alert("ابتدا وارد شوید");
    if (content.trim() === "") return alert("متن خالی است");

    try {
      setSending(true);
      const res = await fetch(`${api}/api/comments`, {
        method: "POST",
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          content,
          rating,
          targetId: productId,
          targetType: targetType === "product" ? "Product" : "Letter",
        }),
      });

      const data = await res.json();
      if (!res.ok) {
        alert(data.message || "خطا");
        setSending(false);
        return;
      }

      // وضعیت ارسال موفق
      setContent("");
      setRating(5);
      fetchComments();

      // نمایش نوتیف زیبا
      setNotif(true);
      setTimeout(() => setNotif(false), 3800);
    } catch (e) {
      console.error("submit error:", e);
    }

    setSending(false);
  };

  /* -----------------------------------------
     Like / Dislike
  ----------------------------------------- */
  const like = async (id: string) => {
    if (!token) return alert("ابتدا وارد شوید");
    await fetch(`${api}/api/comments/${id}/like`, {
      method: "POST",
      headers: { Authorization: `Bearer ${token}` },
    });
    fetchComments();
  };

  const dislike = async (id: string) => {
    if (!token) return alert("ابتدا وارد شوید");
    await fetch(`${api}/api/comments/${id}/dislike`, {
      method: "POST",
      headers: { Authorization: `Bearer ${token}` },
    });
    fetchComments();
  };

  /* -----------------------------------------
     Glass Style
  ----------------------------------------- */
  const glass = `
    bg-[rgba(20,25,45,0.45)]
    backdrop-blur-xl
    border border-[rgba(255,255,255,0.08)]
    shadow-[0_8px_32px_rgba(0,0,0,0.45)]
  `;

  /* -----------------------------------------
     UI
  ----------------------------------------- */
  return (
    <section className="max-w-4xl mx-auto p-6 text-white relative overflow-hidden">
      <h2 className="text-3xl font-bold mb-6 tracking-wide">نظرات کاربران</h2>

      {/* ✅ نوتیف زیبا */}
      {notif && (
  <div className="fixed top-10 left-1/2 -translate-x-1/2 z-50 transition-all animate-fade-in-out bg-[#020617]/95 border border-[#1e3a8a] text-slate-100 rounded-2xl px-6 py-3 shadow-2xl flex items-center gap-3 backdrop-blur-md">
    <FaCheckCircle className="text-2xl text-blue-400" />
    <div className="text-sm font-medium">
      نظر شما با موفقیت ثبت شد.
      <br />
      پس از تأیید مدیر در صفحه نمایش داده خواهد شد.
    </div>
  </div>
)}


      {/* Form */}
      <div className={`${glass} p-6 rounded-2xl mb-10`}>
        <h3 className="font-semibold text-lg mb-3 text-blue-300">
          ثبت نظر شما
        </h3>

        <textarea
          rows={4}
          value={content}
          onChange={(e) => setContent(e.target.value)}
          placeholder="نظر خود را با دیگران به اشتراک بگذارید..."
          className="w-full bg-[rgba(255,255,255,0.06)] backdrop-blur-md border border-white/10 rounded-xl px-4 py-3 text-sm focus:ring-2 focus:ring-blue-500 transition-all"
        />

        <div className="flex justify-between items-center mt-4">
          <StarInput rating={rating} setRating={setRating} />
          <button
            onClick={submitComment}
            disabled={sending}
            className="px-7 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 transition disabled:opacity-40 text-sm"
          >
            {sending ? "در حال ارسال..." : "ثبت نظر"}
          </button>
        </div>
      </div>

      {/* لیست کامنت‌ها */}
      {loading ? (
        Array.from({ length: 3 }).map((_, i) => (
          <div key={i} className={`${glass} p-5 rounded-2xl animate-pulse mb-6`} />
        ))
      ) : comments.length === 0 ? (
        <p className="text-center text-gray-400 py-10">
          هنوز نظری ثبت نشده است
        </p>
      ) : (
        comments.map((c) => (
          <div
            key={c._id}
            className={`${glass} p-5 rounded-2xl mb-6 hover:bg-[rgba(20,30,55,0.55)] transition-all`}
          >
            {/* Header */}
            <div className="flex justify-between items-start">
              <div className="flex items-center gap-3">
                <FaUserCircle size={32} className="text-gray-400" />
                <div>
                  <div className="font-bold text-white/90">
                    {c.user?.name || "کاربر ناشناس"}
                  </div>
                  <div className="flex gap-3 text-xs text-gray-400 mt-1">
                    {/* ✅ تاریخ شمسی */}
                    <span>
                      {dayjs(c.createdAt)
                        .calendar("jalali")
                        .format("YYYY/MM/DD")}
                    </span>
                    {c.isBuyer && (
                      <span className="text-green-400 flex items-center gap-1">
                        <FaShoppingBag /> خریدار
                      </span>
                    )}
                  </div>
                </div>
              </div>
              <StarDisplay rating={c.rating} />
            </div>

            <p className="mt-4 text-sm text-white/85 leading-relaxed">
              {c.content}
            </p>

            {/* Likes */}
            <div className="flex gap-8 mt-5 text-white/60">
              <button
                onClick={() => like(c._id)}
                className="flex items-center gap-1 hover:text-blue-300 transition"
              >
                <FaThumbsUp />
                {c.likes.length}
              </button>
              <button
                onClick={() => dislike(c._id)}
                className="flex items-center gap-1 hover:text-blue-300 transition"
              >
                <FaThumbsDown />
                {c.dislikes.length}
              </button>
            </div>
          </div>
        ))
      )}

      {/* Pagination */}
      <div className="flex justify-center gap-4 mt-6">
        <button
          disabled={page === 1}
          onClick={() => setPage((p) => p - 1)}
          className="px-4 py-2 bg-white/10 rounded-lg hover:bg-white/20 transition disabled:opacity-20"
        >
          قبلی
        </button>
        <button
          disabled={comments.length < PAGE_LIMIT}
          onClick={() => setPage((p) => p + 1)}
          className="px-4 py-2 bg-white/10 rounded-lg hover:bg-white/20 transition disabled:opacity-20"
        >
          بعدی
        </button>
      </div>

      {/* انیمیشن برای نوتیف */}
      <style jsx global>{`
        @keyframes fadeInOut {
          0% {
            opacity: 0;
            transform: translateY(-20px);
          }
          15% {
            opacity: 1;
            transform: translateY(0);
          }
          85% {
            opacity: 1;
            transform: translateY(0);
          }
          100% {
            opacity: 0;
            transform: translateY(-20px);
          }
        }
        .animate-fade-in-out {
          animation: fadeInOut 4s ease-in-out forwards;
        }
      `}</style>
    </section>
  );
}
