"use client"

import { useState, useEffect, useRef } from "react"
import Link from "next/link"
import { Menu, Search, X, Home, Package, Mail, Phone, Loader2 } from "lucide-react"
import { useRouter } from "next/navigation"
import ProfileDropdown from "./ProfileDropdown"
import CartDropdown from "./CartDropdown"

export default function Navbar() {
  const [searchFocused, setSearchFocused] = useState(false)
  const [openMobileMenu, setOpenMobileMenu] = useState(false)
  const [scrolled, setScrolled] = useState(false)
  const [search, setSearch] = useState("")
  const [results, setResults] = useState<{products: any[], letters: any[]} | null>(null)
  const [loading, setLoading] = useState(false)
  const [showResults, setShowResults] = useState(false)

  const router = useRouter()
  const searchContainerRef = useRef<HTMLDivElement>(null)

  // ✅ اسکرول نرم به فوتر
  const scrollToFooter = () => {
    const footer = document.getElementById("footer")
    if (footer) {
      footer.scrollIntoView({ behavior: "smooth" })
    }
  }

  // ✅ حل مشکل رفرش بعد از لاگین
  useEffect(() => {
  const handleAuthChange = () => {
    router.refresh()
  }

  window.addEventListener("auth-change", handleAuthChange)

  return () => {
    window.removeEventListener("auth-change", handleAuthChange)
  }
}, [router])


  // هندل شیشه‌ای شدن نوبار هنگام اسکرول
  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 10)
    window.addEventListener("scroll", handleScroll)
    return () => window.removeEventListener("scroll", handleScroll)
  }, [])

  // بستن پنجره نتایج با کلیک بیرون
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (searchContainerRef.current && !searchContainerRef.current.contains(e.target as Node)) {
        setShowResults(false)
      }
    }
    document.addEventListener("mousedown", handleClickOutside)
    return () => document.removeEventListener("mousedown", handleClickOutside)
  }, [])

  // منطق سرچ زنده
  useEffect(() => {
    const delayDebounceFn = setTimeout(async () => {
      if (search.trim().length > 2) {
        setLoading(true)
        setShowResults(true)
        try {
          const api =
        process.env.NEXT_PUBLIC_API_URL?.replace(/\/+$/, "") ||
        "http://localhost:5000"

        const res = await fetch(`${api}/api/search/global-search?query=${search}`)

          const data = await res.json()
          setResults(data)
        } catch (err) {
          console.error("Search error:", err)
        } finally {
          setLoading(false)
        }
      } else {
        setResults(null)
        setShowResults(false)
      }
    }, 400)

    return () => clearTimeout(delayDebounceFn)
  }, [search])
  

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (!search.trim()) return
    router.push(`/letters?search=${encodeURIComponent(search)}`)
    setShowResults(false)
  }

  const menuItems = [
    { href: "/", label: "خانه", icon: Home },
    { href: "/letters", label: "پاکت نامه ها", icon: Mail },
    { href: "/products", label: "محصولات", icon: Package },
    { href: "/about-us", label: "درباره ما", icon: Phone },
  ]

  return (
    <>
      {searchFocused && (
  <div
    className="fixed inset-0 backdrop-blur-sm bg-black/30 z-40 transition-all duration-300"
    onClick={() => {
      setSearchFocused(false)
      setShowResults(false)
    }}
  />
)}

      <header
        className={`sticky top-0 z-50 transition-all duration-500 border-b ${
          scrolled ? "backdrop-blur-2xl bg-black/40" : "backdrop-blur-xl bg-black/20"
        }`}
        style={{
          borderColor: "#1b6cff33",
          boxShadow: scrolled ? "0 10px 40px rgba(27,108,255,0.12)" : "0 4px 20px rgba(0,0,0,0.2)",
        }}
      >
        <div className="max-w-7xl mx-auto px-6 py-3 flex flex-col gap-4">

          {/* موبایل */}
          <div className="flex items-center md:hidden justify-between w-full px-2">
            <button onClick={() => setOpenMobileMenu(true)} className="p-2 text-gray-200">
              <Menu size={24} />
            </button>

            <Link href="/" className="text-2xl font-extrabold bg-clip-text text-transparent bg-gradient-to-r from-blue-600 to-blue-400 mx-auto">
              BluZiperld
            </Link>

            <div className="flex items-center gap-2">
              <CartDropdown />
              <ProfileDropdown />
            </div>
          </div>

          {/* دسکتاپ */}
          <div className="hidden md:flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Link href="/" className="text-2xl font-extrabold bg-clip-text text-transparent bg-gradient-to-r from-blue-600 to-blue-400">
                BluZiperld
              </Link>
            </div>

            <nav className="flex items-center gap-10 text-sm font-medium text-gray-300">
              {menuItems.map((item) => {

                // ✅ اگر تماس با ما بود اسکرول کن
                if (item.label === "تماس با ما") {
                  return (
                    <button
                      key={item.href}
                      onClick={scrollToFooter}
                      className="relative group transition-colors hover:text-blue-400"
                    >
                      {item.label}
                      <span className="absolute left-0 -bottom-1 w-0 h-[2px] bg-blue-500 transition-all duration-300 group-hover:w-full"/>
                    </button>
                  )
                }

                return (
                  <Link key={item.href} href={item.href} className="relative group transition-colors hover:text-blue-400">
                    {item.label}
                    <span className="absolute left-0 -bottom-1 w-0 h-[2px] bg-blue-500 transition-all duration-300 group-hover:w-full"/>
                  </Link>
                )
              })}
            </nav>

            <div className="flex items-center gap-3">
              <CartDropdown />
              <ProfileDropdown />
            </div>
          </div>


          {/* سرچ */}
          <div ref={searchContainerRef} className="relative w-full max-w-md md:max-w-xl mx-auto">
            <form onSubmit={handleSearchSubmit} className="relative group">
              <input
  value={search}
  onChange={(e) => setSearch(e.target.value)}
  onFocus={() => {
    setSearchFocused(true)
    search.length > 2 && setShowResults(true)
  }}
  type="text"
  placeholder="جستجو کنید..."
  className="w-full pl-12 pr-12 py-2 md:py-2.5 rounded-2xl text-sm bg-[#0a0f1e]/90 text-white border border-[#001a4d] focus:border-blue-500 focus:ring-1 focus:ring-blue-500/50 outline-none transition-all placeholder:text-gray-500 shadow-inner"
/>


              <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-blue-500/70 group-focus-within:text-blue-400" size={18} />

              {loading && (
                <Loader2 className="absolute right-12 top-1/2 -translate-y-1/2 text-blue-500 animate-spin" size={16} />
              )}

              {search && (
                <button
                  type="button"
                  onClick={() => {setSearch(""); setResults(null)}}
                  className="absolute right-4 top-1/2 -translate-y-1/2 text-gray-500 hover:text-white transition"
                >
                  <X size={16} />
                </button>
              )}
            </form>

            {showResults && (results?.products.length || results?.letters.length) ? (
              <div className="absolute top-full mt-2 w-full bg-[#0d1425] border border-blue-500/20 rounded-2xl shadow-2xl overflow-hidden z-[100] backdrop-blur-2xl">

                {results?.products.length > 0 && (
                  <div className="p-3">
                    <p className="text-[10px] text-gray-500 font-bold mb-2 mr-2 uppercase tracking-widest">
                      محصولات
                    </p>

                    {results.products.map((p: any) => (
                      <Link
                        key={p._id}
                        href={`/products/${p._id}`}
                       onClick={() => {
  setShowResults(false)
  setSearchFocused(false)
  setSearch("")
}}

                        className="flex items-center gap-3 p-2 hover:bg-blue-500/10 rounded-xl transition group"
                      >
                        <img src={p.images?.[0] || "/no-img.png"} className="w-10 h-10 rounded-lg object-cover border border-white/5" alt="" />
                        <div className="flex-1">
                          <h4 className="text-sm text-gray-200 group-hover:text-blue-400 transition line-clamp-1">{p.title}</h4>
                          <p className="text-xs text-blue-500">{p.price?.toLocaleString()} تومان</p>
                        </div>
                      </Link>
                    ))}
                  </div>
                )}

                {results?.products.length > 0 && results?.letters.length > 0 && (
                  <div className="h-[1px] bg-white/5" />
                )}

                {results?.letters.length > 0 && (
                  <div className="p-3">
                    <p className="text-[10px] text-gray-500 font-bold mb-2 mr-2 uppercase tracking-widest">
                      پاکت نامه‌ها
                    </p>

                    {results.letters.map((l: any) => (
  <Link
    key={l._id}
    href={`/letters/${l.slug || l._id}`}
    onClick={() => {
  setShowResults(false)
  setSearchFocused(false)
  setSearch("")
}}

    className="flex items-center gap-3 p-2 hover:bg-blue-500/10 rounded-xl transition group"
  >

                        <div className="w-10 h-10 rounded-lg bg-blue-500/20 flex items-center justify-center text-blue-400">
                          <Mail size={18} />
                        </div>

                        <div className="flex-1">
                          <h4 className="text-sm text-gray-200 group-hover:text-blue-400 transition line-clamp-1">{l.title}</h4>
                          <p className="text-[10px] text-gray-500">{l.category}</p>
                        </div>
                      </Link>
                    ))}
                  </div>
                )}

                <button
                  onClick={handleSearchSubmit}
                  className="w-full p-3 bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold transition-all"
                >
                  مشاهده همه نتایج
                </button>
              </div>
            ) : showResults && search.length > 2 && !loading && (
              <div className="absolute top-full mt-2 w-full bg-[#0d1425] p-5 text-center text-sm text-gray-400 rounded-2xl border border-white/5 shadow-xl">
                نتیجه‌ای یافت نشد 😕
              </div>
            )}
          </div>
        </div>
      </header>

      {/* موبایل منو */}
      <div
        className={`fixed inset-0 bg-black/60 backdrop-blur-sm z-[60] transition-opacity duration-300 ${
          openMobileMenu ? "opacity-100 visible" : "opacity-0 invisible"
        }`}
        onClick={() => setOpenMobileMenu(false)}
      />

      <aside
        className={`fixed right-0 top-0 h-full w-72 bg-[#0b1120] border-l border-blue-500/20 shadow-2xl z-[70] transition-transform duration-300 ${
          openMobileMenu ? "translate-x-0" : "translate-x-full"
        }`}
      >
        <div className="flex flex-col h-full">
          <div className="flex items-center justify-between p-5 border-b border-white/5">
            <span className="text-white font-semibold">منو دسترسی</span>
            <button onClick={() => setOpenMobileMenu(false)}>
              <X className="text-gray-300" size={22}/>
            </button>
          </div>

          <nav className="flex flex-col p-4 gap-2">
           {menuItems.map((item) => {
  const Icon = item.icon


  return (
    <Link
      key={item.href}
      href={item.href}
      onClick={() => setOpenMobileMenu(false)}
      className="flex items-center gap-3 p-4 rounded-2xl text-gray-300 hover:bg-blue-500/10 hover:text-blue-400 transition-all"
    >
      <Icon size={20}/>
      {item.label}
    </Link>
  )
})}

          </nav>

          <div className="mt-auto p-6 border-t border-white/5 text-center text-[10px] text-gray-600 uppercase tracking-widest">
            BluZiperld © 2026
          </div>
        </div>
      </aside>
    </>
  )
}
