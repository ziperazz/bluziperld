"use client";

import { ShoppingCart, Plus, Eye, Star, Check } from "lucide-react"
import { useRef, useState } from "react"
import Link from "next/link"

export default function ProductCard({ product, mode = "products" }: any) {
  const imgRef = useRef<HTMLImageElement>(null)
  const [toast, setToast] = useState(false)

  // ۱. شناسه داخلی برای دیتابیس و سبد خرید
  const id = product._id || product.id

  // ۲. ساخت URL برای سئو (استفاده از slug برای محصولات و id برای نامه‌ها)
  const detailsUrl =
    mode === "letters"
      ? `/letters/${product.slug || id}`
      : `/products/${product.slug || id}` // اولویت با slug است برای سئو

  // -------------------------------------------------------
  // 🔥 ساخت URL صحیح برای تصاویر
  // -------------------------------------------------------
  const apiBase =
    (process.env.NEXT_PUBLIC_API_URL?.replace(/\/$/, "")) ||
    "http://localhost:5000"

  const rawImage =
    product.image ??
    product.images?.[0] ??
    "/placeholder.png"

  let finalImageUrl = "";

  if (!rawImage) {
    finalImageUrl = "/placeholder.png";
  } 
  else if (rawImage.startsWith("http")) {
    finalImageUrl = rawImage;
  } 
  else if (rawImage.startsWith("/uploads")) {
    finalImageUrl = `${apiBase}${rawImage}`;
  } 
  else if (rawImage.includes("uploads")) {
    finalImageUrl = `${apiBase}/${rawImage.replace(/^\//, "")}`;
  } 
  else if (rawImage.startsWith("/")) {
    finalImageUrl = rawImage;
  } 
  else {
    finalImageUrl = `${apiBase}/uploads/${rawImage}`;
  }

  // -------------------------------------------------------

  const handleAdd = () => {
    if (product.instock === 0) return

    if (mode === "letters") {
      window.location.href = detailsUrl
      return
    }

    const cart = JSON.parse(localStorage.getItem("cart") || "[]")
    // در سبد خرید حتماً از ID استفاده می‌کنیم نه slug
    const existing = cart.find((i: any) => i.productId === id)

    if (existing) {
      existing.quantity += 1
    } else {
      cart.push({
        productId: id, // آی‌دی دیتابیس
        title: product.title,
        price: product.priceAfterDiscount ?? product.price,
        image: finalImageUrl,
        quantity: 1
      })
    }

    localStorage.setItem("cart", JSON.stringify(cart))
    window.dispatchEvent(new Event("cart-updated"))

    setToast(true)
    setTimeout(() => setToast(false), 1800)
  }

  const finalPrice = product.priceAfterDiscount ?? (
    product.discount > 0
      ? product.price * (1 - product.discount / 100)
      : product.price
  )

  return (
    <>
      {/* Toast */}
      <div
        className={`fixed top-4 right-4 z-50 transition-all duration-300 ${
          toast
            ? "opacity-100 translate-y-0"
            : "opacity-0 -translate-y-3 pointer-events-none"
        }`}
      >
        <div className="flex items-center gap-1.5 text-[12px] text-white px-3 py-1.5 rounded-lg bg-black/70 backdrop-blur-md border border-white/10">
          <Check size={14} className="text-green-400" />
          به سبد خرید اضافه شد
        </div>
      </div>

      {/* Card */}
      <div className="group w-full rounded-2xl border border-white/10 bg-[#0a0f1e] overflow-hidden transition hover:-translate-y-1 hover:shadow-[0_0_25px_rgba(27,108,255,.35)] relative">

        <Link href={detailsUrl} className="block md:pointer-events-none">
          <div className="relative h-[170px] sm:h-[200px] overflow-hidden">
            <img
              ref={imgRef}
              src={finalImageUrl}
              alt={product.title} // بسیار مهم برای سئو تصاویر
              onError={(e) => {
                const target = e.currentTarget
                if (!target.dataset.errored) {
                  target.dataset.errored = "true"
                  target.src = "/placeholder.png"
                }
              }}
              className="w-full h-full object-cover transition duration-500 group-hover:scale-105"
            />

            {product.discount > 0 && (
              <span className="absolute top-2 right-2 bg-red-500 text-white text-[11px] font-bold px-2 py-[2px] rounded-md shadow-lg">
                %{product.discount}
              </span>
            )}
          </div>
        </Link>

        <div className="p-4 flex flex-col gap-3">
          <h3 className="text-sm text-white leading-5 line-clamp-2 min-h-[40px]">
            {product.title}
          </h3>

          <div className="flex items-center justify-between">
            <div className="flex items-center gap-[2px]">
              {[1, 2, 3, 4, 5].map((i) => (
                <Star
                  key={i}
                  size={12}
                  className={
                    i <= (product.ratingAverage || product.rating || 0)
                      ? "text-yellow-400 fill-yellow-400"
                      : "text-gray-600"
                  }
                />
              ))}
            </div>

            <span className="text-[11px] text-gray-400 whitespace-nowrap">
              {product.purchaseCount ?? 0} خرید
            </span>
          </div>

          <div className="flex items-start sm:items-center justify-between gap-1">
            <div className="flex flex-col">
              {product.discount > 0 ? (
                <>
                  <span className="text-slate-400 text-[10px] sm:text-[11px] line-through">
                    {Number(product.price).toLocaleString()}
                  </span>
                  <span className="text-white text-[13px] font-semibold whitespace-nowrap">
                    {Number(finalPrice).toLocaleString()}
                    <span className="text-[10px] text-gray-400 mr-1">تومان</span>
                  </span>
                </>
              ) : (
                <span className="text-white text-[13px] font-semibold whitespace-nowrap">
                  {Number(product.price).toLocaleString()}
                  <span className="text-[10px] text-gray-400 mr-1">تومان</span>
                </span>
              )}
            </div>

            <div className="text-right">
              {product.instock > 0 ? (
                <span className="text-green-400 text-[10px] sm:text-[11px] block">
                  موجودی: {product.instock}
                </span>
              ) : (
                <span className="text-red-400 text-[10px] sm:text-[11px] block">
                  ناموجود
                </span>
              )}
            </div>
          </div>

          <div className="hidden md:flex opacity-0 group-hover:opacity-100 transition gap-2 mt-1">
            {mode === "letters" ? (
              <Link
                href={detailsUrl}
                className="flex-1 flex items-center justify-center gap-1 py-2 text-[12px] rounded-lg bg-[#1b6cff] hover:bg-[#3b82f6] text-white"
              >
                <ShoppingCart size={14} />
                سفارش نامه
              </Link>
            ) : (
              <button
                onClick={handleAdd}
                disabled={product.instock === 0}
                className={`flex-1 flex items-center justify-center gap-1 py-2 text-[12px] rounded-lg transition text-white ${
                  product.instock > 0
                    ? "bg-[#1b6cff] hover:bg-[#3b82f6]"
                    : "bg-gray-500 cursor-not-allowed opacity-70"
                }`}
              >
                <ShoppingCart size={14} />
                {product.instock > 0 ? "افزودن" : "ناموجود"}
              </button>
            )}

            <Link
              href={detailsUrl}
              className="flex-1 flex items-center justify-center gap-1 py-2 text-[12px] rounded-lg border border-white/20 text-white hover:bg-white/10"
            >
              <Eye size={14} />
              مشاهده
            </Link>
          </div>
        </div>

        <button
          onClick={(e) => {
            e.preventDefault()
            e.stopPropagation()
            handleAdd()
          }}
          disabled={product.instock === 0}
          className={`absolute top-3 left-3 md:hidden w-9 h-9 rounded-full flex items-center justify-center border border-white/10 text-white backdrop-blur transition ${
            product.instock > 0
              ? "bg-black/40"
              : "bg-gray-700/40 cursor-not-allowed opacity-60"
          }`}
        >
          <Plus size={16} />
        </button>
      </div>
    </>
  )
}
