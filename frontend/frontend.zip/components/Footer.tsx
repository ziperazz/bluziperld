"use client";

import {
  Send,
  Globe,
  Briefcase,
  Mail,
  Phone,
} from "lucide-react";

export default function Footer() {
  return (
    <footer id="footer" className="mt-16 px-3 sm:px-4 select-none">

      <div
        className="
        max-w-6xl mx-auto
        p-4 sm:p-6 md:p-8
        rounded-2xl sm:rounded-3xl
        bg-[rgba(20,25,45,0.45)]
        backdrop-blur-xl sm:backdrop-blur-2xl
        border border-[rgba(255,255,255,0.06)]
        shadow-[0_10px_40px_rgba(0,0,0,0.55)]
        text-slate-200
      "
      >
        {/* GRID */}
        <div className="grid grid-cols-2 md:grid-cols-3 gap-6 md:gap-8 text-right">

          {/* درباره ما */}
          <div className="space-y-2 sm:space-y-3 col-span-2 md:col-span-1">
            <h3 className="text-[0.8rem] sm:text-sm font-semibold text-blue-300">
              درباره ما
            </h3>

            <p className="text-[0.7rem] sm:text-[0.78rem] leading-relaxed text-slate-300/80">
              نوشتن نامه هیچوقت قدیمی نمی‌شود.  
              ما برای شما متن‌هایی خاص، احساسی و ماندگار می‌نویسیم.
            </p>
          </div>

          {/* لینک‌های مفید */}
          <div className="space-y-2 sm:space-y-3">
            <h3 className="text-[0.8rem] sm:text-sm font-semibold text-blue-300">
              لینک‌های مفید
            </h3>

            <ul className="space-y-1 text-[0.7rem] sm:text-[0.78rem]">

              <li>
                <a
                  href="/rules"
                  className="block text-slate-300/80 hover:text-blue-400 transition hover:translate-x-1"
                >
                  قوانین و مقررات
                </a>
              </li>

              <li>
                <a
                  href="/support"
                  className="block text-slate-300/80 hover:text-blue-400 transition hover:translate-x-1"
                >
                  پشتیبانی
                </a>
              </li>

              <li>
                <a
                  href="/about-us"
                  className="block text-slate-300/80 hover:text-blue-400 transition hover:translate-x-1"
                >
                  درباره ما
                </a>
              </li>

              <li>
                <a
                  href="/"
                  className="block text-slate-300/80 hover:text-blue-400 transition hover:translate-x-1"
                >
                  تماس با ما
                </a>
              </li>

            </ul>
          </div>

          {/* ارتباط با ما */}
          <div className="space-y-2 sm:space-y-3">
            <h3 className="text-[0.8rem] sm:text-sm font-semibold text-blue-300 text-left md:text-right pr-4 md:pr-0">
              ارتباط با ما
            </h3>

            <div className="space-y-1 text-[0.7rem] sm:text-[0.78rem] text-slate-300/90">

              <div className="flex items-center gap-2 justify-end">
                <span>BluZiperLd@gmail.com</span>
                <Mail size={14} className="text-blue-400" />
              </div>

              <div className="flex items-center gap-2 justify-end">
                <span>BluZiperld@</span>
                <Send size={14} className="text-blue-400" />
              </div>

              <div className="flex items-center gap-2 justify-end">
                <span>09930810025</span>
                <Phone size={14} className="text-blue-400" />
              </div>

            </div>

            {/* Social */}
            <div className="flex gap-2 mt-2 justify-end">

              {[Send, Globe, Briefcase].map((Icon, i) => (
                <div
                  key={i}
                  className="
                  w-8 h-8 sm:w-9 sm:h-9
                  flex items-center justify-center
                  rounded-lg sm:rounded-xl
                  bg-[rgba(255,255,255,0.07)]
                  border border-[rgba(255,255,255,0.08)]
                  cursor-pointer
                  transition
                  hover:bg-[rgba(255,255,255,0.16)]
                  hover:scale-110
                  active:scale-95
                "
                >
                  <Icon size={16} className="text-slate-200" />
                </div>
              ))}

            </div>
          </div>
        </div>

        {/* Divider */}
        <div className="mt-6 border-t border-[rgba(255,255,255,0.07)] pt-4"></div>

        {/* Bottom */}
        <div className="flex flex-col md:flex-row items-center justify-between gap-3 text-[0.68rem] sm:text-[0.75rem] text-slate-400">

          <div className="text-center md:text-right">
            © 2026 — کلیه حقوق برای سایت بلو زیپر محفوظ است.
            <div className="opacity-60 text-[0.8rem] mt-1">
              Made with 💙 by Amirreza (ziper)
            </div>
          </div>

{/* Enamad + Zarinpal */}

<div className="flex items-center gap-3">

  {/* Enamad */}
  <div
    className="
      w-12 h-12 sm:w-14 sm:h-14
      rounded-xl
      bg-[rgba(255,255,255,0.06)]
      backdrop-blur-xl
      border border-[rgba(255,255,255,0.09)]
      flex items-center justify-center
      shadow-[0_4px_18px_rgba(0,0,0,0.55)]
      transition-all duration-300
      hover:scale-110
      hover:shadow-[0_0_25px_rgba(102,192,244,0.45)]
      hover:border-[rgba(102,192,244,0.4)]
      hover:bg-[rgba(255,255,255,0.15)]
    "
  >
    <svg viewBox="0 0 100 40" className="w-full h-full">
      <text
        x="50%"
        y="55%"
        dominantBaseline="middle"
        textAnchor="middle"
        fontSize="22"
        fontWeight="800"
        fill="#66c0f4"
        fontFamily="Vazirmatn, sans-serif"
      >
        اینماد
      </text>
    </svg>
  </div>

  {/* Zarinpal */}
  <div
    className="
      w-12 h-12 sm:w-14 sm:h-14
      rounded-xl
      bg-[rgba(255,255,255,0.06)]
      backdrop-blur-xl
      border border-[rgba(255,255,255,0.09)]
      flex items-center justify-center
      shadow-[0_4px_18px_rgba(0,0,0,0.55)]
      transition-all duration-300
      hover:scale-110
      hover:shadow-[0_0_25px_rgba(255,212,71,0.45)]
      hover:border-[rgba(255,212,71,0.4)]
      hover:bg-[rgba(255,255,255,0.15)]
    "
  >
    <svg viewBox="0 0 100 40" className="w-full h-full">
      <text
        x="50%"
        y="55%"
        dominantBaseline="middle"
        textAnchor="middle"
        fontSize="22"
        fontWeight="800"
        fill="#ffd447"
        fontFamily="Vazirmatn, sans-serif"
      >
        زرین‌پال
      </text>
    </svg>
  </div>

</div>


        </div>
      </div>
    </footer>
  );
}
