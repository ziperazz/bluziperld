"use client"

import { useEffect, useRef, useState } from "react"
import { Send, Loader2, Wifi, WifiOff } from "lucide-react"

const api =
  process.env.NEXT_PUBLIC_API_URL?.replace(/\/+$/, "") ||
  "http://localhost:5000"


type Sender = "user" | "admin"

interface Message {
  _id?: string
  sender: Sender
  message: string
  createdAt: string
}

interface Props {
  ticketId: string
  status: string
  token: string
  role: Sender
  adminOnline?: boolean
  refreshInterval?: number
}

export default function TicketChatUltra({
  ticketId,
  status,
  token,
  role,
  adminOnline = false,
  refreshInterval = 3000,
}: Props) {
  const [messages, setMessages] = useState<Message[]>([])
  const [text, setText] = useState("")
  const [loading, setLoading] = useState(true)
  const [sending, setSending] = useState(false)
  const [typing, setTyping] = useState(false)
  const [connectionOK, setConnectionOK] = useState(true)

  const bottomRef = useRef<HTMLDivElement | null>(null)

  useEffect(() => {
    let isMounted = true

    async function loadMessages() {
      try {
        const res = await fetch(`${api}/api/tickets/${ticketId}`, {
          headers: { Authorization: `Bearer ${token}` },
          cache: "no-store",
        })

        const data = await res.json()

        if (isMounted) {
          if (data.success) {
            setMessages(data.ticket.messages)
            setConnectionOK(true)
          } else {
            setConnectionOK(false)
          }
          setLoading(false)
          scrollToBottom()
        }
      } catch {
        if (isMounted) {
          setConnectionOK(false)
          setLoading(false)
        }
      }
    }

    // first load
    loadMessages()

    // auto refresh
    const intervalId = setInterval(loadMessages, refreshInterval)

    return () => {
      isMounted = false
      clearInterval(intervalId)
    }
  }, [ticketId, token, refreshInterval])

  function scrollToBottom() {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" })
  }

  async function sendMessage() {
    if (!text.trim() || sending) return

    setSending(true)
    setTyping(true)

    try {
      const res = await fetch(
  `${api}/api/tickets/${ticketId}/messages`,

        {
          method: "POST",
          headers: {
            Authorization: `Bearer ${token}`,
            "Content-Type": "application/json",
          },
          body: JSON.stringify({ message: text }),
        }
      )

      const data = await res.json()

      if (data.success) {
        setMessages(data.ticket.messages)
        setText("")
        scrollToBottom()
      }
    } catch {
      // می‌تونی اینجا نوتیف خطا اضافه کنی
    } finally {
      setSending(false)
      setTimeout(() => setTyping(false), 1500)
    }
  }

  return (
    <div className="h-full flex flex-col bg-[#0a0f1f]">

      {/* HEADER */}
      <div className="p-4 border-b border-white/10 flex items-center justify-between bg-[#0f152a]">
        <div className="flex items-center gap-2 text-sm text-white">
          <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse" />
          گفت‌وگو با پشتیبانی
        </div>

        <div className="text-xs text-gray-400 flex items-center gap-1">
          {adminOnline ? (
            <>
              <Wifi size={14} className="text-green-400" />
              پشتیبان آنلاین
            </>
          ) : (
            <>
              <WifiOff size={14} className="text-red-400" />
              پشتیبان 17 الی 20 آنلاین است
            </>
          )}
        </div>
      </div>

      {/* MESSAGES */}
      <div className="flex-1 overflow-y-auto p-6 space-y-4">
        {loading && (
          <div className="text-gray-400 text-center">در حال بارگذاری…</div>
        )}

        {messages.map((msg, i) => {
          const mine = msg.sender === role

          return (
            <div
              key={msg._id || i}
              className={`flex ${mine ? "justify-end" : "justify-start"} animate-fadeIn`}
            >
              <div
                className={`max-w-[70%] px-4 py-3 rounded-2xl backdrop-blur shadow-md
                  ${
                    mine
                      ? "bg-gradient-to-l from-blue-600 to-blue-500 text-white"
                      : "bg-white/10 text-gray-200 border border-white/10"
                  }
                `}
              >
                <div className="text-sm leading-relaxed">{msg.message}</div>
                <div className="text-[10px] opacity-50 text-right mt-1">
                  {new Date(msg.createdAt).toLocaleTimeString("fa-IR")}
                </div>
              </div>
            </div>
          )
        })}

        {typing && (
          <div className="flex justify-start">
            <div className="px-4 py-2 bg-white/10 text-gray-300 rounded-xl text-xs animate-pulse">
              در حال نوشتن...
            </div>
          </div>
        )}

        <div ref={bottomRef} />
      </div>

      {!connectionOK && (
        <div className="bg-red-500/20 text-red-300 text-xs text-center py-2">
          ارتباط با سرور ضعیف است…
        </div>
      )}

      {/* INPUT */}
      {status !== "CLOSED" && (
        <div className="p-4 border-t border-white/10 flex items-center gap-3 bg-[#0f1425] shadow-xl">
          <button
            className="w-12 h-12 flex items-center justify-center bg-blue-600 hover:bg-blue-500 text-white rounded-xl shadow-lg"
            onClick={sendMessage}
          >
            {sending ? (
              <Loader2 size={20} className="animate-spin" />
            ) : (
              <Send size={20} />
            )}
          </button>

          <textarea
            value={text}
            onChange={(e) => setText(e.target.value)}
            placeholder="پیام خود را بنویسید…"
            className="flex-1 bg-white/5 border border-white/10 rounded-xl p-3 text-sm text-white focus:outline-none shadow-inner resize-none"
            rows={1}
            onKeyDown={(e) => {
              if (e.key === "Enter" && !e.shiftKey) {
                e.preventDefault()
                sendMessage()
              }
            }}
          />
        </div>
      )}
    </div>
  )
}
