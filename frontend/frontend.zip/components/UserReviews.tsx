"use client";

import { useEffect, useState, useRef } from "react";
import dayjs from "dayjs";
import jalaliday from "jalaliday";
import "dayjs/locale/fa";
import { ChevronLeft, ChevronRight, Quote } from "lucide-react";

dayjs.extend(jalaliday);
dayjs.locale("fa");

const API = process.env.NEXT_PUBLIC_API_URL || "http://localhost:5000";

export default function UserReviews() {
  const [reviews, setReviews] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const sliderRef = useRef<HTMLDivElement | null>(null);
  const directionRef = useRef<"left" | "right">("right");

  useEffect(() => {
    fetch(`${API}/api/comments/latest?limit=10`)
      .then((res) => res.json())
      .then((data) => {
        setReviews(Array.isArray(data) ? data : []);
        setLoading(false);
      })
      .catch(() => setLoading(false));
  }, []);

  const scroll = (dir: "left" | "right") => {
    if (!sliderRef.current) return;

    sliderRef.current.scrollBy({
      left: dir === "left" ? -320 : 320,
      behavior: "smooth",
    });
  };

  // ✅ اسکرول اتومات رفت و برگشتی واقعی
useEffect(() => {
  const interval = setInterval(() => {
    const el = sliderRef.current;
    if (!el) return;

    const maxScroll = el.scrollWidth - el.clientWidth;

    if (el.scrollLeft >= maxScroll - 10) {
      el.scrollTo({ left: 0, behavior: "smooth" });
    } else {
      el.scrollBy({ left: 320, behavior: "smooth" });
    }
  }, 5000);

  return () => clearInterval(interval);
}, []);


  return (
    <section className="relative py-14">
      <div className="absolute left-1/2 -translate-x-1/2 -top-10 w-[420px] h-[420px] bg-[#66c0f4]/10 blur-[120px] rounded-full -z-10" />

      <div className="text-center mb-12">
        <Quote size={40} className="mx-auto text-[#66c0f4]/25 mb-4" />
        <h2 className="text-2xl sm:text-3xl font-bold text-white mb-3">
          تجربه کاربران
        </h2>
        <div className="h-[2px] w-16 mx-auto bg-gradient-to-r from-[#66c0f4] to-[#c186ff] rounded-full" />
      </div>

      {loading ? (
        <div className="flex gap-6 overflow-x-auto px-4 sm:px-2">
          {[...Array(5)].map((_, i) => (
            <div
              key={i}
              className="w-[85%] sm:w-[320px] lg:w-[340px] h-44 rounded-2xl bg-white/5 border border-white/10 animate-pulse flex-shrink-0"
            />
          ))}
        </div>
      ) : reviews.length === 0 ? (
        <p className="text-center text-[#8f98a0]">
          هنوز نظری ثبت نشده است
        </p>
      ) : (
        <div className="relative px-4 sm:px-2">

          

          {/* ✅ دسکتاپ */}
          <button
            onClick={() => scroll("left")}
            className="
              hidden sm:block
              absolute left-4 top-1/2 -translate-y-1/2 z-20
              p-3 rounded-xl
              bg-[#14192D]/80
              border border-white/10
              backdrop-blur
              hover:border-[#66c0f4]
              hover:bg-[#66c0f4]
              hover:text-[#0b141c]
              text-white
              transition-all
              shadow-lg
            "
          >
            <ChevronLeft size={20} />
          </button>

          <button
            onClick={() => scroll("right")}
            className="
              hidden sm:block
              absolute right-4 top-1/2 -translate-y-1/2 z-20
              p-3 rounded-xl
              bg-[#14192D]/80
              border border-white/10
              backdrop-blur
              hover:border-[#66c0f4]
              hover:bg-[#66c0f4]
              hover:text-[#0b141c]
              text-white
              transition-all
              shadow-lg
            "
          >
            <ChevronRight size={20} />
          </button>

          <div
            ref={sliderRef}
            className="flex gap-6 overflow-x-auto scroll-smooth snap-x snap-mandatory pb-6 pt-10 sm:pt-0 no-scrollbar"
          >
            {reviews.map((review) => (
              <div
                key={review._id}
                className="
                  relative flex-shrink-0
                  w-[85%] sm:w-[320px] lg:w-[340px]
                  snap-start
                  p-6 rounded-2xl
                  border border-white/10
                  bg-gradient-to-b from-white/[0.05] to-transparent
                  backdrop-blur-xl
                  shadow-[0_10px_30px_rgba(0,0,0,0.4)]
                  hover:shadow-[0_0_35px_rgba(102,192,244,0.25)]
                  hover:border-[#66c0f4]/40
                  transition-all duration-300 group
                "
              >
                <div className="absolute inset-0 rounded-2xl opacity-0 group-hover:opacity-100 transition duration-500 bg-[radial-gradient(circle_at_top_right,rgba(102,192,244,0.18),transparent_60%)]" />

                <div className="relative z-10">
                  <div className="flex items-center justify-between mb-4">
                    <div>
                      <p className="text-white font-semibold text-sm">
                        {review.user?.name || "کاربر"}
                      </p>
                      <p className="text-xs text-[#8f98a0]">
                        {dayjs(review.createdAt)
                          .calendar("jalali")
                          .format("YYYY/MM/DD")}
                      </p>
                    </div>

                    {review.isBuyer && (
                      <span className="text-xs px-2 py-1 bg-[#66c0f4]/20 text-[#66c0f4] rounded-lg">
                        خریدار
                      </span>
                    )}
                  </div>

                  <div className="text-[#66c0f4] text-sm mb-3 tracking-wide">
                    {"★".repeat(review.rating || 5)}
                    {"☆".repeat(5 - (review.rating || 5))}
                  </div>

                  <p className="text-[#c7d5e0] text-sm leading-relaxed line-clamp-4">
                    {review.content}
                  </p>
                </div>
              </div>
            ))}
          </div>

        </div>
      )}
    </section>
  );
}
