"use client";

import { useSearchParams } from "next/navigation";
import Link from "next/link";
import { useEffect, useRef, useState } from "react";
export const dynamic = "force-dynamic";

export default function PaymentVerifyPage() {
  const searchParams = useSearchParams();

  const status = searchParams.get("status");
  const subtotal = Number(searchParams.get("subtotal") || 0);
  const shippingCost = Number(searchParams.get("shipping") || 0);
  const total = Number(searchParams.get("total") || 0);

  const [loading, setLoading] = useState(true);
  const [order, setOrder] = useState<any>(null);
  const [error, setError] = useState(false);
  const [copied, setCopied] = useState(false);

  const calledRef = useRef(false);

  const isSuccess = status === "success";

  const API = process.env.NEXT_PUBLIC_API_URL || "http://localhost:5000";

  useEffect(() => {
    const finalizeOrder = async () => {
      if (calledRef.current) return;
      calledRef.current = true;

      if (!isSuccess) {
        setLoading(false);
        return;
      }

      try {
        const rawCart = JSON.parse(localStorage.getItem("cart") || "[]");
        const shippingInfo = JSON.parse(
          localStorage.getItem("shippingInfo") || "{}"
        );

        const token = localStorage.getItem("accessToken");

        const safeCart = rawCart.map((item: any) => ({
          ...item,
          productType: item.productType || "product",
        }));

        if (!safeCart.length || !token) {
          setError(true);
          setLoading(false);
          return;
        }

        const response = await fetch(`${API}/api/orders`, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${token}`,
          },
          credentials: "include",
          body: JSON.stringify({
            cart: safeCart,
            shipping: shippingInfo,
            subtotal,
            shippingCost,
            total,
          }),
        });

        const data = await response.json();

        if (response.ok && data.success) {
          setOrder(data.order);
          localStorage.removeItem("cart");
          localStorage.removeItem("shippingInfo");
        } else {
          if (
            data.message === "محصول پیدا نشد" ||
            data.message === "محصول (یا نامه) پیدا نشد"
          ) {
            localStorage.removeItem("cart");
          }
          setError(true);
        }
      } catch (err) {
        setError(true);
      } finally {
        setLoading(false);
      }
    };

    finalizeOrder();
  }, [isSuccess, subtotal, shippingCost, total, API]);

  const copyCode = () => {
    if (!order?.trackingCode) return;
    navigator.clipboard.writeText(order.trackingCode);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  if (loading) return <LoadingUI />;

  if (!isSuccess || error) return <FailedPaymentUI />;

  return <SuccessAwaitingReviewUI order={order} copyCode={copyCode} copied={copied} />;
}

/* ---------------------- LOADING ---------------------- */

function LoadingUI() {
  return (
    <div className="relative min-h-screen flex items-center justify-center bg-[#030617] text-white overflow-hidden">

      <div className="absolute w-[700px] h-[700px] bg-blue-500/10 blur-[220px] rounded-full -top-40 -left-40" />
      <div className="absolute w-[700px] h-[700px] bg-emerald-500/10 blur-[220px] rounded-full bottom-0 right-0" />

      <div className="relative flex flex-col items-center gap-8">

        <div className="relative">
          <div className="w-20 h-20 border-4 border-emerald-500/20 rounded-full"></div>
          <div className="absolute inset-0 border-4 border-transparent border-t-emerald-400 rounded-full animate-spin"></div>
        </div>

        <div className="text-sm text-slate-300 animate-pulse">
          در حال تایید پرداخت و ثبت سفارش...
        </div>

      </div>
    </div>
  );
}

/* ---------------------- SUCCESS ---------------------- */

function SuccessAwaitingReviewUI({
  order,
  copyCode,
  copied
}: {
  order: any;
  copyCode: () => void;
  copied: boolean;
}) {
  return (
    <div className="relative min-h-screen flex items-center justify-center bg-[#030617] px-4 overflow-hidden">

      <div className="absolute w-[800px] h-[800px] bg-blue-500/10 blur-[260px] rounded-full -top-40 -left-40" />
      <div className="absolute w-[800px] h-[800px] bg-emerald-500/10 blur-[260px] rounded-full bottom-0 right-0" />

      <div className="relative max-w-xl w-full p-[1px] rounded-[28px] bg-gradient-to-r from-emerald-500/30 via-blue-500/30 to-purple-500/30">

        <div className="rounded-[28px] bg-[#0b0f1c]/90 backdrop-blur-2xl px-8 py-10 border border-white/10 shadow-[0_30px_80px_rgba(0,0,0,0.8)]">

          {/* success icon */}

          <div className="flex flex-col items-center text-center">

            <div className="relative">

              <div className="absolute inset-0 rounded-full blur-xl bg-emerald-400/40"></div>

              <div className="relative w-20 h-20 rounded-full bg-emerald-500/10 border border-emerald-400/40 flex items-center justify-center text-emerald-400">

                <svg className="w-10 h-10" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7"/>
                </svg>

              </div>

            </div>

            <h1 className="mt-6 text-2xl font-bold text-white">
              پرداخت با موفقیت انجام شد
            </h1>

            <p className="mt-2 text-sm text-slate-400 max-w-md leading-relaxed">
              سفارش شما ثبت شد و در صف بررسی تیم پشتیبانی قرار گرفت.
              پس از بررسی، فرآیند آماده‌سازی و ارسال آغاز می‌شود از پنل وضعیت سفارش خود را ببنید.
            </p>

          </div>

          {/* tracking code */}

          {order?.trackingCode && (
            <div className="mt-8 p-6 rounded-2xl bg-black/40 border border-white/10 text-center">

              <p className="text-xs text-slate-400">
                کد پیگیری سفارش
              </p>

              <div className="flex items-center justify-center gap-3 mt-3">

                <p className="font-mono text-2xl tracking-[0.3em] text-emerald-400 select-all">
                  {order.trackingCode}
                </p>

                <button
                  onClick={copyCode}
                  className="text-xs px-3 py-1 rounded-lg bg-white/10 border border-white/10 hover:bg-white/20 transition"
                >
                  {copied ? "کپی شد" : "کپی"}
                </button>

              </div>

            </div>
          )}

          {/* order steps */}

          <div className="mt-8">

            <p className="text-sm font-semibold text-slate-200 mb-4">
              مراحل بعدی سفارش
            </p>

            <div className="space-y-4">

              {[
                "بررسی سفارش توسط تیم پشتیبانی (حداکثر 12 ساعت)",
                "آماده‌سازی و بسته‌بندی مرسوله",
                "ارسال و ثبت کد رهگیری پستی"
              ].map((step, i) => (
                <div key={i} className="flex items-center gap-3 text-sm text-slate-400">

                  <div className="w-6 h-6 rounded-full border border-emerald-400/40 bg-emerald-400/10 flex items-center justify-center text-[11px] text-emerald-400">
                    {i + 1}
                  </div>

                  {step}

                </div>
              ))}

            </div>

          </div>

          {/* CTA */}

          <div className="mt-10 flex flex-col md:flex-row gap-3">

            <Link href="/" className="flex-1">

              <button className="w-full px-4 py-3 rounded-xl bg-gradient-to-r from-emerald-400 to-emerald-500 text-black font-bold text-sm hover:scale-[1.02] active:scale-[0.97] transition shadow-xl shadow-emerald-500/30">

                بازگشت به صفحه اصلی

              </button>

            </Link>

          </div>

        </div>
      </div>
    </div>
  );
}

/* ---------------------- FAILED ---------------------- */

function FailedPaymentUI() {
  return (
    <div className="relative min-h-screen flex items-center justify-center bg-[#030617] px-4 overflow-hidden">

      <div className="absolute w-[600px] h-[600px] bg-red-500/10 blur-[200px] rounded-full -top-40 -left-40" />
      <div className="absolute w-[600px] h-[600px] bg-purple-500/10 blur-[200px] rounded-full bottom-0 right-0" />

      <div className="relative max-w-md w-full p-[1px] rounded-[28px] bg-gradient-to-r from-red-500/40 to-purple-500/40">

        <div className="rounded-[28px] bg-[#0b0f1c]/90 backdrop-blur-2xl px-8 py-10 border border-red-500/20 shadow-2xl text-center">

          <div className="mx-auto h-16 w-16 rounded-full bg-red-500/20 border border-red-400/40 flex items-center justify-center text-red-400">

            <svg className="w-10 h-10" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12"/>
            </svg>

          </div>

          <h1 className="text-xl font-semibold text-white mt-5">
            پرداخت ناموفق بود
          </h1>

          <p className="text-sm text-slate-400 mt-3 leading-relaxed">
            پرداخت تایید نشد یا خطایی در ثبت سفارش رخ داد.
            لطفاً سبد خرید خود را بررسی کرده و دوباره تلاش کنید اگر پول از حساب کم شد تیکت برای پشتیبانی ثبت کنید تا در سریع ترین زمان مشکل را حل کند.
          </p>

          <Link href="/cart">

            <button className="mt-7 w-full px-4 py-3 rounded-xl bg-white/10 text-white border border-white/10 hover:bg-white/20 transition">

              بازگشت به سبد خرید

            </button>

          </Link>

        </div>
      </div>
    </div>
  );
}
