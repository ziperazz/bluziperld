"use client";

import { useState, useEffect } from "react";
import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import {
  ShoppingCart,
  Truck,
  CreditCard,
  CheckCircle2,
  ChevronRight,
  Loader2,
} from "lucide-react";

/* ----- درگاه‌های نمونه برای UI ----- */
const gateways = [
  {
    id: "zarinpal",
    name: "زرین پال",
    logo: "/images/gateways/zarinpal.svg",
    active: true,
    description: "پرداخت اینترنتی امن با زرین پال",
  },
  {
    id: "mellat",
    name: "بانک ملت",
    logo: "/images/gateways/mellat.svg",
    active: false,
    description: "در حال بروزرسانی",
  },
  {
    id: "saman",
    name: "بانک سامان",
    logo: "/images/gateways/saman.svg",
    active: false,
    description: "در حال بروزرسانی",
  },
];

export default function PaymentPage() {
  const pathname = usePathname();
  const router = useRouter();

  const [selectedGateway, setSelectedGateway] = useState("zarinpal");
  const [loading, setLoading] = useState(false);

  const [summary, setSummary] = useState({
    subtotal: 0,
    shipping: 0,
    discount: 0,
  });

  useEffect(() => {
    try {
      const cartRaw = localStorage.getItem("cart") || "[]";
      const cart = JSON.parse(cartRaw);

      const subtotal = cart.reduce((total: number, item: any) => {
        const price = item.priceAfterDiscount ?? item.price ?? 0;
        const quantity = item.quantity ?? 1;
        return total + price * quantity;
      }, 0);

      let shipping = 0;
      const shippingInfoRaw = localStorage.getItem("shippingInfo");
      if (shippingInfoRaw) {
        const shippingInfo = JSON.parse(shippingInfoRaw);
        if (
          shippingInfo &&
          typeof shippingInfo.shippingPrice === "number" &&
          !isNaN(shippingInfo.shippingPrice)
        ) {
          shipping = shippingInfo.shippingPrice;
        }
      }

      setSummary({
        subtotal,
        shipping,
        discount: 0,
      });
    } catch (err) {
      console.error("Error reading cart or shippingInfo from localStorage:", err);
      setSummary({
        subtotal: 0,
        shipping: 0,
        discount: 0,
      });
    }
  }, [pathname]);

  const total = summary.subtotal + summary.shipping - summary.discount;

const handlePayment = async () => {
  if (summary.subtotal <= 0) {
    alert("سبد خرید خالی است");
    router.push("/cart");
    return;
  }

  try {
    setLoading(true);

    const API =
      process.env.NEXT_PUBLIC_API_URL || "http://localhost:5000";

    const res = await fetch(`${API}/api/payment/request`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        amount: total,
      }),
    });

    const data = await res.json();

    if (data.success && data.url) {
      window.location.href = data.url;
    } else {
      alert("خطا در اتصال به درگاه پرداخت");
      setLoading(false);
    }
  } catch (error) {
    console.error("Payment Error:", error);
    alert("خطا در برقراری ارتباط با درگاه");
    setLoading(false);
  }
};


  return (
    <div className="min-h-screen bg-[#050A18] text-gray-100 p-3 md:p-6 pb-20">
      <div className="max-w-5xl mx-auto">
        {/* ---------- STEPper ---------- */}
        <div className="flex items-center justify-center mb-8 gap-2 md:gap-3">
          <StepItem icon={<ShoppingCart size={18} />} label="سبد خرید" />
          <StepLine />
          <StepItem icon={<Truck size={18} />} label="اطلاعات ارسال" />
          <StepLine />
          <StepItem icon={<CreditCard size={18} />} label="پرداخت" active />
          <StepLine />
          <StepItem icon={<CheckCircle2 size={18} />} label="پایان" />
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* ---------- خلاصه فاکتور در موبایل بالای اطلاعات پرداخت ---------- */}
          <div className="block lg:hidden mb-6">
            <div
              className="p-4 rounded-2xl border border-white/10"
              style={{
                background: "rgba(15,16,22,0.75)",
                backdropFilter: "blur(30px)",
                boxShadow: "0 12px 35px rgba(0,0,0,0.35)",
              }}
            >
              <h3 className="text-base font-bold mb-4 text-white border-b border-white/5 pb-3">
                خلاصه صورتحساب
              </h3>

              <div className="space-y-3 text-sm">
                <Row label="جمع محصولات" value={`${summary.subtotal.toLocaleString()} تومان`} />
                <Row label="هزینه ارسال" value={`${summary.shipping.toLocaleString()} تومان`} />
                <Row label="تخفیف" value={`-${summary.discount.toLocaleString()} تومان`} />
                <div className="border-t border-white/5 pt-3">
                  <Row label="مبلغ نهایی قابل پرداخت">
                    <span className="text-blue-400 font-bold text-sm">{total.toLocaleString()} تومان</span>
                  </Row>
                </div>
              </div>
            </div>
          </div>

          {/* ---------- انتخاب درگاه و اطلاعات پرداخت ---------- */}
          <div className="lg:col-span-2 space-y-5">
            <SectionTitle title="انتخاب درگاه پرداخت" />

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {gateways.map((g) => {
                const selected = g.id === selectedGateway;
                const disabled = !g.active;

                return (
                  <button
                    key={g.id}
                    onClick={() => !disabled && setSelectedGateway(g.id)}
                    disabled={disabled}
                    className={`
                      flex flex-col p-3 rounded-2xl border transition backdrop-blur-md
                      text-right relative
                      ${
                        selected && !disabled
                          ? "border-blue-500/40 bg-blue-500/10 shadow-[0_0_0_1px_rgba(59,130,246,0.20)]"
                          : "border-white/10 bg-white/5 hover:bg-white/7"
                      }
                      ${disabled ? "opacity-40 grayscale cursor-not-allowed" : ""}
                    `}
                  >
                    <div className="flex items-center justify-between mb-2">
                      <span className="font-semibold text-sm">{g.name}</span>
                      {!disabled && (
                        <span
                          className={`w-2.5 h-2.5 rounded-full ${
                            selected
                              ? "bg-blue-400 shadow-[0_0_14px_rgba(59,130,246,0.45)]"
                              : "bg-white/20"
                          }`}
                        />
                      )}
                    </div>
                    <p className="text-[11px] text-gray-400 leading-5">{g.description}</p>
                  </button>
                );
              })}
            </div>

            <SectionTitle title="اطلاعات پرداخت" />
            <div className="p-4 rounded-2xl border border-white/10 bg-white/5 backdrop-blur-md text-xs text-gray-400 leading-6">
              برای تست سیستم پرداخت، درگاه فیک فعال شده است.
              با کلیک روی «پرداخت و ادامه» عملیات پرداخت شبیه‌سازی شده و به صفحه‌ی verify هدایت می‌شوید.
            </div>

            <div className="mt-6 flex flex-col sm:flex-row gap-3 sm:items-center sm:justify-between">
              <button
                disabled={loading}
                onClick={handlePayment}
                className="w-full sm:w-auto flex-1 py-3 rounded-xl text-white font-semibold text-sm transition hover:scale-[1.02] active:scale-95 flex items-center justify-center gap-2"
                style={{ background: "linear-gradient(135deg,#2563eb,#3b82f6)" }}
              >
                {loading ? (
                  <>
                    <Loader2 size={20} className="animate-spin" />
                    در حال اتصال به درگاه...
                  </>
                ) : (
                  <>
                    پرداخت و ادامه
                    <ChevronRight size={18} className="rotate-180" />
                  </>
                )}
              </button>

              <Link
                href="/shipping"
                className="text-center sm:w-auto py-2 px-3 rounded-xl border border-white/10 bg-white/5 hover:bg-white/7 transition text-sm text-gray-200"
              >
                ← بازگشت به اطلاعات ارسال
              </Link>
            </div>
          </div>

          {/* ---------- خلاصه فاکتور در دسکتاپ به صورت aside ---------- */}
          <aside className="hidden lg:block lg:col-span-1">
            <div
              className="sticky top-24 p-4 rounded-2xl border border-white/10"
              style={{
                background: "rgba(15,16,22,0.75)",
                backdropFilter: "blur(30px)",
                boxShadow: "0 12px 35px rgba(0,0,0,0.35)",
              }}
            >
              <h3 className="text-base font-bold mb-4 text-white border-b border-white/5 pb-3">
                خلاصه صورتحساب
              </h3>

              <div className="space-y-3 text-sm">
                <Row label="جمع محصولات" value={`${summary.subtotal.toLocaleString()} تومان`} />
                <Row label="هزینه ارسال" value={`${summary.shipping.toLocaleString()} تومان`} />
                <Row label="تخفیف" value={`-${summary.discount.toLocaleString()} تومان`} />
                <div className="border-t border-white/5 pt-3">
                  <Row label="مبلغ نهایی قابل پرداخت">
                    <span className="text-blue-400 font-bold text-sm">{total.toLocaleString()} تومان</span>
                  </Row>
                </div>
              </div>
            </div>
          </aside>
        </div>
      </div>
    </div>
  );
}

/* ---------- کامپوننت‌ها ---------- */
function SectionTitle({ title }: { title: string }) {
  return (
    <div className="flex items-center justify-between">
      <h3 className="text-sm font-semibold text-white">{title}</h3>
      <span className="text-[11px] text-gray-500">—</span>
    </div>
  );
}

function Row({ label, value, children }: any) {
  return (
    <div className="flex items-center justify-between gap-3">
      <span className="text-gray-400 text-xs">{label}</span>

      {children ? (
        children
      ) : (
        <span className="text-gray-200 text-xs font-medium">{value}</span>
      )}
    </div>
  );
}

function StepItem({ icon, label, active = false }: any) {
  return (
    <div className="flex flex-col items-center gap-1.5">
      <div
        className={`w-10 h-10 rounded-xl flex items-center justify-center transition
          ${
            active
              ? "bg-blue-600 text-white shadow-[0_0_14px_rgba(37,99,235,0.45)]"
              : "bg-white/5 text-gray-500 border border-white/5"
          }`}
      >
        {icon}
      </div>
      <span
        className={`text-[10px] md:text-[11px] whitespace-nowrap ${
          active ? "text-white" : "text-gray-500"
        }`}
      >
        {label}
      </span>
    </div>
  );
}

function StepLine() {
  return <div className="w-6 md:w-10 h-[2px] bg-white/5 mb-5" />;
}
