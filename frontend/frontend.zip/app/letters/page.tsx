"use client";

export const dynamic = "force-dynamic";
export const fetchCache = "force-no-store";

import { Suspense, useEffect, useRef, useState } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import ProductCard from "@/components/ProductCard";
import Filters from "@/components/Filters";
import SkeletonCard from "@/components/SkeletonCard";
import { SlidersHorizontal } from "lucide-react";

const api =
  process.env.NEXT_PUBLIC_API_URL?.replace(/\/+$/, "") ||
  "http://localhost:5000";

type Letter = {
  _id: string;
  title: string;
  description: string;
  category: string;
  price: number;
  discount: number;
  instock: number;
  images: string[];
  priceAfterDiscount: number;

  printingExtraPrice?: number;
  handwritingExtraPrice?: number;
  visits?: number;
  purchaseCount?: number;
  ratingAverage?: number;
  rating?: number;
  specs?: { label: string; value: string }[];
  isActive?: boolean;

  createdAt?: string;
};

export default function LettersPage() {
  return (
    <Suspense fallback={null}>
      <LettersPageInner />
    </Suspense>
  );
}

function LettersPageInner() {
  const router = useRouter();
  const search = useSearchParams();

  const [letters, setLetters] = useState<Letter[]>([]);
  const [loading, setLoading] = useState(true);

  const [category, setCategory] = useState(search.get("category") || "");
  const [price, setPrice] = useState(Number(search.get("price") || 500000));
  const [sort, setSort] = useState(search.get("sort") || "new");

  const [filterOpen, setFilterOpen] = useState(false);

  // 🔥 اضافه‌شده (بدون تغییر هیچ چیز دیگر)
  const [onlyAvailable, setOnlyAvailable] = useState(false);
  const [onlyDiscounted, setOnlyDiscounted] = useState(false);

  // =======================
  // Fetch Letters
  // =======================
  useEffect(() => {
    const fetchLetters = async () => {
      try {
        setLoading(true);

        const query = new URLSearchParams();

        if (category) query.set("category", category);
        if (price < 500000) query.set("price", String(price));
        if (sort !== "new") query.set("sort", sort);

        if (onlyAvailable) query.set("onlyAvailable", "1");
        if (onlyDiscounted) query.set("onlyDiscounted", "1");

        const res = await fetch(`${api}/api/letters?${query.toString()}`);

        if (!res.ok) throw new Error("Failed to fetch letters");

        const data: Letter[] = await res.json();
        setLetters(data);
      } catch (error) {
        console.error("Fetch Error:", error);
      } finally {
        setLoading(false);
      }
    };

    fetchLetters();
  }, [category, price, sort, onlyAvailable, onlyDiscounted]);

  // =======================
  // Sync URL
  // =======================
  useEffect(() => {
    const params = new URLSearchParams();

    if (category) params.set("category", category);
    if (price < 500000) params.set("price", String(price));
    if (sort !== "new") params.set("sort", sort);

    if (onlyAvailable) params.set("onlyAvailable", "1");
    if (onlyDiscounted) params.set("onlyDiscounted", "1");

    const queryString = params.toString();

    router.replace(queryString ? `/letters?${queryString}` : "/letters", {
      scroll: false,
    });
  }, [category, price, sort, onlyAvailable, onlyDiscounted, router]);

  // =======================
  // Infinite Scroll
  // =======================
  const [visibleCount, setVisibleCount] = useState(12);
  const loaderRef = useRef<HTMLDivElement | null>(null);
  const [isLoadingMore, setIsLoadingMore] = useState(false);

  useEffect(() => {
    setVisibleCount(12);
  }, [letters]);

  useEffect(() => {
    const currentLoaderRef = loaderRef.current;
    if (!currentLoaderRef) return;

    const observer = new IntersectionObserver(
      (entries) => {
        if (
          entries[0].isIntersecting &&
          !isLoadingMore &&
          visibleCount < letters.length
        ) {
          setIsLoadingMore(true);

          setTimeout(() => {
            setVisibleCount((v) => v + 12);
            setIsLoadingMore(false);
          }, 600);
        }
      },
      { threshold: 0.5 }
    );

    observer.observe(currentLoaderRef);

    return () => {
      observer.disconnect();
    };
  }, [letters.length, visibleCount, isLoadingMore, letters]);

  const visibleLetters = letters.slice(0, visibleCount);

  // =======================
  // Loading
  // =======================
  if (loading) {
    return (
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 md:gap-8 p-8">
        {Array.from({ length: 8 }).map((_, i) => (
          <SkeletonCard key={i} />
        ))}
      </div>
    );
  }

  // =======================
  // Render
  // =======================
  return (
    <div className="min-h-screen px-4 md:px-8 py-10">
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="text-2xl font-bold mb-1">پاکت نامه‌ها</h1>
          <p className="text-xs text-gray-400">{letters.length} مورد یافت شد</p>
        </div>

        <button
          onClick={() => setFilterOpen(true)}
          className="
            lg:hidden flex items-center gap-2
            bg-[#0a0f1e]
            text-white/90
            border border-white/10
            px-4 py-2
            rounded-xl
            shadow-lg
            shadow-blue-500/10
          "
        >
          <SlidersHorizontal size={18} strokeWidth={1.5} />
          <span className="text-sm">فیلتر</span>
        </button>
      </div>

      <div className="lg:sticky lg:top-4 lg:z-40 mb-10">
        <Filters
          price={price}
          setPrice={setPrice}
          sort={sort}
          setSort={setSort}
          filterOpen={filterOpen}
          setFilterOpen={setFilterOpen}
          category={category}
          setCategory={setCategory}
          onlyAvailable={onlyAvailable}
          setOnlyAvailable={setOnlyAvailable}
          onlyDiscounted={onlyDiscounted}
          setOnlyDiscounted={setOnlyDiscounted}
        />
      </div>

      {letters.length > 0 ? (
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 md:gap-8">
          {visibleLetters.map((p) => (
            <ProductCard
              key={p._id}
              mode="letters"
              product={{
                id: p._id,
                slug: p.slug,
                title: p.title,
                price: p.price,
                image: p.images?.[0],
                desc: p.description,
                discount: p.discount,
                instock: p.instock,
                priceAfterDiscount: p.priceAfterDiscount,
                purchaseCount: p.purchaseCount || 0,
                ratingAverage: p.ratingAverage || 0,
              }}
            />
          ))}

          {isLoadingMore &&
            Array.from({ length: 4 }).map((_, i) => <SkeletonCard key={i} />)}
        </div>
      ) : (
        <div className="py-20 text-center text-gray-300">
          <h3 className="text-lg font-medium">پاکت نامه‌ای یافت نشد!</h3>
          <p className="text-sm text-gray-500 mt-2">
            لطفاً فیلترها را تغییر دهید.
          </p>
        </div>
      )}

      {visibleCount < letters.length && (
        <div ref={loaderRef} className="h-20 flex items-center justify-center">
          <div className="w-6 h-6 border-2 border-blue-500 border-t-transparent rounded-full animate-spin"></div>
        </div>
      )}
    </div>
  );
}
