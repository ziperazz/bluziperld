"use client"

import React, { useEffect, useMemo, useState } from "react"
import { useParams } from "next/navigation"
import CommentsSection from "@/components/CommentsSection"

type Letter = {
  _id: string
  title: string
  price: number
  discount?: number
  priceAfterDiscount?: number
  instock?: number
  images?: string[]
  image?: string
  description?: string
  specs?: { label: string; value: string }[]
  handwritingExtraPrice?: number
  printingExtraPrice?: number
  purchaseCount?: number
  visits?: number
}

type WritingType = "HAND" | "PRINT"

const API_BASE =
  process.env.NEXT_PUBLIC_API_URL?.replace(/\/$/, "") ||
  "http://localhost:5000"


export default function LetterDetailsPage() {
  const params = useParams()
  const slug = params?.slug as string

  const [product, setProduct] = useState<Letter | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState("")
  const [activeImage, setActiveImage] = useState(0)
  const [addLoading, setAddLoading] = useState(false)
  const [showToast, setShowToast] = useState(false)

  // مخصوص نامه
  const [letterText, setLetterText] = useState("")
  const [writingType, setWritingType] = useState<WritingType>("HAND")
  const maxChars = 350

  // -------------------------
  // فقط این برای کامنت‌ها اضافه شد
  // -------------------------
  const [token, setToken] = useState<string | undefined>(undefined)

  useEffect(() => {
    if (typeof window !== "undefined") {
      const t = localStorage.getItem("accessToken")
      if (t) setToken(t)
    }
  }, [])
  // -------------------------

  const fixImageUrl = (url?: string) => {
    if (!url) return "/placeholder.png"
    if (url.startsWith("http://") || url.startsWith("https://")) return url
    if (url.startsWith("/uploads")) return `${API_BASE}${url}`
    if (url.startsWith("uploads/")) return `${API_BASE}/${url}`
    return url
  }

  // دریافت اطلاعات پاکت از بک‌اند
useEffect(() => {
  if (!slug) return

  const fetchLetter = async () => {
    try {
      const res = await fetch(`${API_BASE}/api/letters/slug/${slug}`)

      if (!res.ok) throw new Error("پاکت نامه یافت نشد")

      const data = await res.json()

      data.specs = Array.isArray(data.specs) ? data.specs : []
      data.images = Array.isArray(data.images) ? data.images : []

      setProduct(data)
    } catch (err) {
      console.error(err)
      setError("خطا در دریافت اطلاعات پاکت نامه")
    } finally {
      setLoading(false)
    }
  }

  fetchLetter()
}, [slug])



  const normalizedImages = useMemo(() => {
    if (!product) return []

    const imgs =
      product.images && product.images.length > 0
        ? product.images
        : product.image
        ? [product.image]
        : []

    return imgs.map((img) => fixImageUrl(img))
  }, [product])

  const mainImage =
    normalizedImages[activeImage] || "/placeholder.png"

  if (loading)
    return (
      <div className="text-center text-gray-400 mt-10">
        در حال دریافت اطلاعات...
      </div>
    )

  if (error || !product)
    return (
      <div className="text-center text-red-400 mt-10">
        {error || "پاکت نامه یافت نشد"}
      </div>
    )

  // قیمت پایه با تخفیف
  const basePrice =
    product.discount && product.discount > 0
      ? product.priceAfterDiscount ||
        product.price * (1 - product.discount / 100)
      : product.price

  // قیمت اضافه نوشتن
  const handwritingExtra = product.handwritingExtraPrice || 0
  const printingExtra = product.printingExtraPrice || 0

  const writingPrice =
    writingType === "HAND" ? handwritingExtra : printingExtra

  // قیمت نهایی
  const finalPrice = basePrice + writingPrice

  // افزودن به سبد خرید
  const addToCart = () => {
    if (product.instock === 0) return

    if (!letterText.trim()) {
      alert("لطفاً متن نامه را وارد کنید.")
      return
    }

    setAddLoading(true)
    try {
      const cart = JSON.parse(localStorage.getItem("cart") || "[]")

      const newItem = {
        productId: product._id,
        title: product.title,
        price: finalPrice,
        basePrice: basePrice,
        writingPrice,
        writingType,
        letterText,
        image: mainImage,
        quantity: 1,
        productType: "letter",
      }

      const existing = cart.find(
        (i: any) =>
          i.productId === product._id &&
          i.writingType === writingType &&
          i.letterText === letterText
      )

      if (existing) {
        existing.quantity += 1
      } else {
        cart.push(newItem)
      }

      localStorage.setItem("cart", JSON.stringify(cart))
      window.dispatchEvent(new Event("cart-updated"))

      setShowToast(true)
      setTimeout(() => setShowToast(false), 2500)
    } catch (err) {
      console.error("cart error", err)
    }
    setAddLoading(false)
  }

  return (
    <div className="min-h-screen text-slate-100 px-4 md:px-6 py-6 md:py-10">
      <div className="max-w-6xl mx-auto space-y-16">
        <div className="grid md:grid-cols-2 gap-10">
          {/* ستون چپ - تصاویر و مشخصات */}
          <div className="space-y-3">
            <div className="relative aspect-[5/3] rounded-2xl overflow-hidden bg-[#0f172a] border border-[#1f2a44]">
              <img
                src={mainImage}
                alt={product.title}
                className="w-full h-full object-cover"
              />
              {product.discount && product.discount > 0 && (
                <div className="absolute top-3 left-3 bg-red-500/90 text-white px-3 py-1 rounded-xl text-xs font-semibold animate-pulse">
                  %{product.discount} تخفیف
                </div>
              )}
            </div>

            {normalizedImages.length > 1 && (
              <div className="grid grid-cols-4 gap-2">
                {normalizedImages.map((img, i) => (
                  <button
                    key={i}
                    onClick={() => setActiveImage(i)}
                    className={`
                      aspect-[1/1] rounded-lg overflow-hidden border transition
                      ${
                        activeImage === i
                          ? "border-blue-500 scale-105"
                          : "border-[#1f2a44] hover:border-blue-400"
                      }
                    `}
                    style={{ maxHeight: "70px" }}
                    type="button"
                  >
                    <img
                      src={img}
                      alt={`${product.title}-${i + 1}`}
                      className="w-full h-full object-cover"
                    />
                  </button>
                ))}
              </div>
            )}

            {/* مشخصات نامه */}
            <div className="bg-[#0f172a]/60 border border-[#1e293b] rounded-2xl p-4">
              <h3 className="text-sm font-semibold mb-2 text-slate-300">
                مشخصات محصول
              </h3>
              <ul className="space-y-1 text-sm text-slate-400">
                {product.specs && product.specs.length > 0 ? (
                  product.specs.map((item, idx) => (
                    <li key={idx} className="flex justify-between">
                      <span>{item.label}</span>
                      <span className="text-slate-300">
                        {item.value}
                      </span>
                    </li>
                  ))
                ) : (
                  <li className="text-slate-500 text-xs">
                    مشخصاتی ثبت نشده است
                  </li>
                )}
              </ul>
            </div>
          </div>

          {/* ستون راست - اطلاعات و باکس نامه */}
          <div className="space-y-6">
            <div>
              <h1 className="text-2xl md:text-3xl font-semibold">
                {product.title}
              </h1>

              <p className="text-slate-400 text-sm mt-2 leading-relaxed">
                {product.description ||
                  "توضیحاتی برای این پاکت نامه ثبت نشده است."}
              </p>

              {typeof product.instock === "number" && (
                <div className="mt-4 text-sm">
                  {product.instock > 0 ? (
                    <span className="text-green-400">
                      موجودی: {product.instock} عدد
                    </span>
                  ) : (
                    <span className="text-red-400">
                      ❌ ناموجود در انبار
                    </span>
                  )}
                </div>
              )}

              <div className="mt-4 space-y-2">
                <div className="text-xl font-semibold">
                  {finalPrice.toLocaleString()}
                  <span className="text-sm text-slate-400 mr-2">
                    تومان
                  </span>
                </div>

                {product.discount && product.discount > 0 && (
                  <div className="text-xs space-y-1 text-slate-400">
                    <div className="line-through">
                      قیمت اولیه:{" "}
                      {product.price.toLocaleString()} تومان
                    </div>
                    <div>
                      قیمت بعد از تخفیف (بدون هزینه نوشتن):{" "}
                      {basePrice.toLocaleString()} تومان
                    </div>
                  </div>
                )}
              </div>
            </div>

            {/* باکس نوشتن نامه */}
            <div className="bg-[#0f172a] border border-[#1e293b] rounded-3xl p-5 space-y-4">
              <div className="flex justify-between text-sm">
                <span>متن نامه</span>
                <span className="text-slate-400">
                  {letterText.length}/{maxChars}
                </span>
              </div>

              <div className="h-1 bg-[#111827] rounded-full overflow-hidden">
                <div
                  className="h-full bg-blue-600 transition-all"
                  style={{
                    width: `${Math.min(
                      (letterText.length / maxChars) * 100,
                      100
                    )}%`,
                  }}
                />
              </div>

              <textarea
                value={letterText}
                maxLength={maxChars}
                onChange={(e) => setLetterText(e.target.value)}
                placeholder="متن نامه را بنویسید..."
                className="w-full min-h-[160px] resize-none bg-[#0b1220] border border-[#1f2a44] rounded-2xl px-3 py-2 text-sm outline-none focus:border-blue-500 leading-relaxed"
              />

              <div className="grid grid-cols-2 gap-3 text-sm">
                <button
                  onClick={() => setWritingType("HAND")}
                  className={`py-2 rounded-xl border transition ${
                    writingType === "HAND"
                      ? "bg-blue-600 border-blue-600 text-white"
                      : "bg-[#0b1220] border-[#1f2a44] text-slate-300"
                  }`}
                  type="button"
                >
                  دست خط واقعی
                  (کاغذ کرافت)
                  <div className="text-[11px] opacity-70 mt-0.5">
                    +{handwritingExtra.toLocaleString()}{" "}
                    <span className="text-[10px]">تومان</span>
                  </div>
                </button>

                <button
                  onClick={() => setWritingType("PRINT")}
                  className={`py-2 rounded-xl border transition ${
                    writingType === "PRINT"
                      ? "bg-blue-600 border-blue-600 text-white"
                      : "bg-[#0b1220] border-[#1f2a44] text-slate-300"
                  }`}
                  type="button"
                >
                  چاپ
                  (کاغذ معمولی)
                  <div className="text-[11px] opacity-70 mt-0.5">
                    +{printingExtra.toLocaleString()}{" "}
                    <span className="text-[10px]">تومان</span>
                  </div>
                </button>
              </div>
            </div>

            <button
              onClick={addToCart}
              disabled={addLoading || product.instock === 0}
              className={`w-full py-3 rounded-2xl transition-all ${
                product.instock === 0
                  ? "bg-gray-700 cursor-not-allowed opacity-50"
                  : "bg-blue-600 hover:bg-blue-700"
              }`}
            >
              {product.instock === 0
                ? "ناموجود"
                : addLoading
                ? "در حال افزودن..."
                : "افزودن به سبد خرید"}
            </button>
          </div>
        </div>

        {/* ----------------------------------------------------- */}
        {/* فقط همین بخش کامنت اصلاح شده و mt-24 اضافه شده       */}
        {/* ----------------------------------------------------- */}
        <div className="mt-64">
          {token !== null && (
  <CommentsSection
  productId={product._id}
  token={token}
  targetType="letter"
/>

)}

        </div>
        {/* ----------------------------------------------------- */}

      </div>

      <div
  className={`fixed top-6 right-6 z-50 transition-all duration-500 ${
    showToast ? "opacity-100 translate-y-0" : "opacity-0 -translate-y-4 pointer-events-none"
  }`}
>
  <div className="bg-[#0f172a]/95 backdrop-blur-md border border-[#1e293b] text-slate-200 px-5 py-3 rounded-xl shadow-xl text-sm">
    ✔ به سبد خرید اضافه شد
  </div>
</div>

    </div>
  )
}
