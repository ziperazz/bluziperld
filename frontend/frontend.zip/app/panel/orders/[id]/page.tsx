"use client";

import { useEffect, useState } from "react";
import { useParams, useRouter } from "next/navigation";
import { Clock, MapPin, Copy, Check } from "lucide-react";

/* ================= TYPES ================= */

type CartItem = {
  productId: string;
  productType: string;
  title?: string;
  image?: string;
  price: number;
  quantity: number;
  letterText?: string | null;
};

type Order = {
  _id: string;
  trackingCode: string;
  status: string;
  cart: CartItem[];

  shipping: {
    fullName: string;
    phone: string;
    address: string;
    postalCode: string;
    city: string;
  };

  subtotal: number;
  shippingCost: number;
  total: number;
  createdAt: string;
};

/* ================= API ================= */

const API =
  process.env.NEXT_PUBLIC_API_URL || "http://localhost:5000";

/* ================= HELPERS ================= */

function price(v: number) {
  return new Intl.NumberFormat("fa-IR").format(v) + " تومان";
}

function date(d: string) {
  return new Intl.DateTimeFormat("fa-IR", {
    year: "numeric",
    month: "long",
    day: "numeric",
  }).format(new Date(d));
}

const STATUS_LABELS: Record<string, string> = {
  PENDING_PAYMENT: "در انتظار پرداخت",
  PAID: "پرداخت شده",
  PROCESSING: "در حال پردازش",
  AWAITING_ADMIN_REVIEW: "در انتظار بررسی",
  SHIPPED: "ارسال شده",
  DELIVERED: "تحویل شده",
  CANCELLED: "لغو شده",
  FAILED: "ناموفق",
};

/* ================= PAGE ================= */

export default function OrderDetailsPage() {
  const { id } = useParams();
  const router = useRouter();

  const [order, setOrder] = useState<Order | null>(null);
  const [loading, setLoading] = useState(true);
  const [copied, setCopied] = useState(false);

  async function fetchOrder() {
    try {
      const token = localStorage.getItem("accessToken");

      if (!token) {
        router.push("/auth");
        return;
      }

      const res = await fetch(`${API}/api/orders/${id}`, {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });

      const data = await res.json();

      if (data.success) setOrder(data.order);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    fetchOrder();
  }, [id]);

  const getImage = (path?: string) => {
    if (!path) return "/placeholder.png";
    if (path.startsWith("http")) return path;
    return `${API}/${path.replace(/^\/+/, "")}`;
  };

  const copyTracking = async () => {
    await navigator.clipboard.writeText(order?.trackingCode || "");
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  if (loading)
    return (
      <div className="min-h-screen flex items-center justify-center text-white/60">
        در حال بارگذاری...
      </div>
    );

  if (!order) return null;

  return (
    <main className="min-h-screen text-white pb-28">

      <div className="max-w-2xl mx-auto px-4 py-10 space-y-6">

        {/* STATUS */}

        <div className="rounded-3xl border border-white/5 bg-black/60 backdrop-blur-xl shadow-xl p-6">

          <div className="flex items-center justify-between">

            <div className="flex items-center gap-3">

              <div className="w-11 h-11 rounded-xl bg-cyan-400/10 flex items-center justify-center">
                <Clock className="w-5 h-5 text-cyan-300" />
              </div>

              <div>
                <p className="text-xs text-white/40">وضعیت سفارش</p>
                <p className="text-lg font-semibold text-cyan-300">
                  {STATUS_LABELS[order.status] || order.status}
                </p>
              </div>

            </div>

            <p className="text-xs text-white/40">
              {date(order.createdAt)}
            </p>

          </div>

          {/* TRACKING */}

          <div className="mt-5 flex items-center justify-between bg-black/80 border border-white/10 rounded-xl px-4 py-3">

            <div>
              <p className="text-xs text-white/40">
                کد رهگیری سفارش
              </p>

              <p className="font-mono text-emerald-400 text-sm tracking-wider">
                {order.trackingCode}
              </p>
            </div>

            <button
              onClick={copyTracking}
              className="flex items-center gap-1 text-xs text-white/60 hover:text-white transition"
            >
              {copied ? <Check size={16} /> : <Copy size={16} />}
              {copied ? "کپی شد" : "کپی"}
            </button>

          </div>

        </div>

        {/* PRODUCTS */}

        <div className="space-y-4">

          {order.cart.map((item, i) => (

            <div
              key={i}
              className="flex gap-4 rounded-2xl border border-white/5 bg-black/60 backdrop-blur-xl shadow-lg p-4"
            >

              <img
                src={getImage(item.image)}
                className="w-20 h-20 rounded-xl object-cover border border-white/10"
              />

              <div className="flex-1">

                <p className="text-sm font-medium text-white">
                  {item.title || "محصول"}
                </p>

                <div className="flex justify-between mt-2 text-sm">

                  <span className="text-white/50">
                    تعداد {item.quantity}
                  </span>

                  <span className="text-cyan-300 font-semibold">
                    {price(item.price)}
                  </span>

                </div>

                {item.productType === "letter" && item.letterText && (
  <div className="mt-3 relative w-full min-w-0 overflow-hidden">
    {/* دکمه کپی */}
    <button
      onClick={() => {
        navigator.clipboard.writeText(item.letterText || "");
        setCopied(true);
        setTimeout(() => setCopied(false), 1500);
      }}
      className="absolute top-2 right-2 z-10 flex items-center gap-1 text-[10px] px-2 py-1 rounded-lg bg-white/10 hover:bg-white/20 transition text-white/70"
    >
      {copied ? <Check size={12} /> : <Copy size={12} />}
      {copied ? "کپی شد" : "کپی"}
    </button>

    {/* متن نامه */}
    <div
      className="
        max-h-40
        w-full
        min-w-0
        overflow-y-auto
        overflow-x-hidden
        bg-black/80
        border
        border-white/10
        rounded-lg
        p-3
        pt-8
        text-xs
        leading-6
        text-white/80
        whitespace-pre-wrap
        break-all
        [word-break:break-word]
        [overflow-wrap:anywhere]
        scrollbar-thin
        scrollbar-thumb-white/20
      "
    >
      {item.letterText}
    </div>
  </div>
)}



                

              </div>

            </div>

          ))}

        </div>

        {/* ADDRESS */}

        <div className="rounded-3xl border border-white/5 bg-black/60 backdrop-blur-xl shadow-xl p-6">

          <div className="flex items-center gap-2 text-white/60 text-sm">
            <MapPin className="w-4 h-4" />
            آدرس ارسال
          </div>

          <div className="mt-3 text-sm leading-7 text-white/80">

            <p>
              {order.shipping.fullName} — {order.shipping.phone}
            </p>

            <p>
              {order.shipping.city} ، {order.shipping.address}
            </p>

            <p className="text-white/50">
              کد پستی: {order.shipping.postalCode}
            </p>

          </div>

        </div>

        {/* PAYMENT */}

        <div className="rounded-3xl border border-white/5 bg-black/60 backdrop-blur-xl shadow-xl p-6 space-y-4">

          <div className="flex justify-between text-sm">

            <span className="text-white/50">جمع کالاها</span>
            <span>{price(order.subtotal)}</span>

          </div>

          <div className="flex justify-between text-sm">

            <span className="text-white/50">هزینه ارسال</span>
            <span>{price(order.shippingCost)}</span>

          </div>

          <div className="border-t border-white/10 pt-4 flex justify-between items-center">

            <span className="text-white/80">مبلغ نهایی</span>

            <span className="text-2xl font-bold text-emerald-400">
              {price(order.total)}
            </span>

          </div>

        </div>

      </div>

    </main>
  );
}
