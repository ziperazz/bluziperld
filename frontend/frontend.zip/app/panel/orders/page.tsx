"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import {
  BadgeDollarSign,
  CalendarClock,
  Clock4,
} from "lucide-react";

/* ============================
   Types
=============================*/

type OrderStatus =
  | "PENDING_PAYMENT"
  | "PAID"
  | "PROCESSING"
  | "AWAITING_ADMIN_REVIEW"
  | "SHIPPED"
  | "DELIVERED"
  | "CANCELLED"
  | "FAILED";

type Order = {
  _id: string;
  trackingCode: string;
  total: number;
  status: OrderStatus;
  createdAt: string;
};

/* ============================
   Labels
=============================*/

const STATUS_LABELS: Record<OrderStatus, string> = {
  PENDING_PAYMENT: "در انتظار پرداخت",
  PAID: "پرداخت شده",
  PROCESSING: "در حال پردازش",
  AWAITING_ADMIN_REVIEW: "در انتظار بررسی ادمین",
  SHIPPED: "ارسال شده",
  DELIVERED: "تحویل شده",
  CANCELLED: "لغو شده",
  FAILED: "ناموفق",
};

const STATUS_COLORS: Record<OrderStatus, string> = {
  PENDING_PAYMENT: "bg-amber-500/10 text-amber-300 border-amber-500/30",
  PAID: "bg-emerald-500/10 text-emerald-300 border-emerald-500/30",
  PROCESSING: "bg-sky-500/10 text-sky-300 border-sky-500/30",
  AWAITING_ADMIN_REVIEW:
    "bg-violet-500/10 text-violet-300 border-violet-500/30",
  SHIPPED: "bg-cyan-500/10 text-cyan-300 border-cyan-500/30",
  DELIVERED: "bg-green-500/10 text-green-300 border-green-500/30",
  CANCELLED: "bg-rose-500/10 text-rose-300 border-rose-500/30",
  FAILED: "bg-red-500/10 text-red-300 border-red-500/30",
};

/* ============================
   Component
=============================*/

export default function UserOrdersPage() {
  const router = useRouter();

  const [orders, setOrders] = useState<Order[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(false);

  const API =
    process.env.NEXT_PUBLIC_API_URL || "http://localhost:5000";

  useEffect(() => {
    const getOrders = async () => {
      try {
        const accessToken = localStorage.getItem("accessToken");

        if (!accessToken) {
          router.push("/auth");
          return;
        }

        const response = await fetch(`${API}/api/orders/my`, {
          method: "GET",
          credentials: "include",
          headers: {
            Authorization: `Bearer ${accessToken}`,
          },
        });

        if (response.status === 401) {
          router.push("/auth");
          return;
        }

        const data = await response.json();

        if (data.success && Array.isArray(data.orders)) {
          setOrders(data.orders);
        } else {
          setError(true);
        }
      } catch (err) {
        console.error("Error loading orders:", err);
        setError(true);
      } finally {
        setLoading(false);
      }
    };

    getOrders();
  }, [router]); // ⇦ API حذف شد

  /* ============================
     Loading View
  =============================*/

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-[#050814] text-white">
        <div className="animate-pulse text-sm text-white/70">
          در حال بارگیری سفارش‌ها...
        </div>
      </div>
    );
  }

  /* ============================
     Error View
  =============================*/

  if (error) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center bg-[#050814] text-white text-center px-4">
        <p className="text-slate-300">
          خطایی در دریافت اطلاعات سفارش‌ها رخ داد.
        </p>

        <Link href="/">
          <button className="mt-6 px-4 py-2.5 rounded-lg bg-white text-slate-900 font-medium text-sm hover:bg-slate-200 transition">
            بازگشت به صفحه اصلی
          </button>
        </Link>
      </div>
    );
  }

  /* ============================
     Main UI
  =============================*/

  return (
    <div className="min-h-screen bg-[radial-gradient(circle_at_top,rgba(34,211,238,0.12),transparent_25%),linear-gradient(180deg,#050814_0%,#050814_40%,#02040a_100%)] px-4 py-12 text-white">
      <div className="max-w-4xl mx-auto">

        <div className="flex items-center justify-between mb-8">
          <h1 className="text-xl font-semibold">سفارش‌های من</h1>

          <Link
            href="/letters"
            className="text-xs border border-white/10 bg-white/10 px-3 py-2 rounded-xl hover:bg-white/20 transition"
          >
            بریم برای ایجاد سفارش؟!
          </Link>
        </div>

        {orders.length === 0 ? (
          <div className="text-center text-slate-400 mt-12">
            هنوز سفارشی ثبت نکرده‌اید.
          </div>
        ) : (
          <div className="space-y-4">
            {orders.map((order) => (
              <OrderCard key={order._id} order={order} />
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

/* ============================
   Order Card
=============================*/

function OrderCard({ order }: { order: Order }) {
  return (
    <div className="p-5 rounded-2xl bg-white/5 border border-white/10 backdrop-blur-2xl shadow-[0_10px_30px_rgba(0,0,0,0.25)] transition hover:border-cyan-400/40 hover:bg-cyan-400/10">

      <div className="flex justify-between items-center">
        <p className="text-sm text-slate-400">
          کد پیگیری:
          <span className="mr-2 font-mono text-emerald-400">
            {order.trackingCode}
          </span>
        </p>

        <StatusBadge status={order.status} />
      </div>

      <div className="flex justify-between items-center mt-3 text-xs">
        <div className="flex items-center gap-1 text-cyan-300">
          <BadgeDollarSign className="h-4 w-4" />
          <span>{order.total.toLocaleString()} تومان</span>
        </div>

        <div className="flex items-center gap-1 text-white/60">
          <CalendarClock className="h-4 w-4" />
          <span>
            {new Date(order.createdAt).toLocaleDateString("fa-IR")}
          </span>
        </div>
      </div>

      <OrderProgress status={order.status} />

      <div className="mt-4">
        <Link href={`/panel/orders/${order._id}`}>
          <button className="px-4 py-2 w-full rounded-xl bg-white/10 text-white text-sm border border-white/10 hover:bg-white/20 transition">
            مشاهده جزئیات
          </button>
        </Link>
      </div>
    </div>
  );
}

/* ============================
   Status Badge
=============================*/

function StatusBadge({ status }: { status: OrderStatus }) {
  return (
    <span
      className={`px-3 py-1 text-xs rounded-full border ${STATUS_COLORS[status]}`}
    >
      {STATUS_LABELS[status]}
    </span>
  );
}

/* ============================
   Order Progress
=============================*/

function OrderProgress({ status }: { status: OrderStatus }) {
  const steps: OrderStatus[] = [
    "PENDING_PAYMENT",
    "AWAITING_ADMIN_REVIEW",
    "PROCESSING",
    "SHIPPED",
    "DELIVERED",
  ];

  const currentIndex = steps.indexOf(status);

  return (
    <div className="flex items-center gap-2 mt-4">
      {steps.map((step, idx) => {
        const isDone = idx < currentIndex;
        const isCurrent = idx === currentIndex;

        return (
          <div key={step} className="flex-1">
            <div
              className={`h-1.5 rounded-full transition ${
                isDone
                  ? "bg-emerald-400"
                  : isCurrent
                  ? "bg-emerald-300"
                  : "bg-white/10"
              }`}
            />
          </div>
        );
      })}

      <Clock4 className="h-4 w-4 text-white/50" />
    </div>
  );
}
