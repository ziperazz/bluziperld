"use client"

import { useEffect, useState } from "react"
import Link from "next/link"

const sections = [
  { id: "intro", title: "مقدمه" },
  { id: "account", title: "حساب کاربری" },
  { id: "orders", title: "ثبت سفارش" },
  { id: "letters", title: "متن نامه‌ها" },
  { id: "payment", title: "پرداخت" },
  { id: "shipping", title: "ارسال" },
  { id: "returns", title: "مرجوعی و استرداد" },
  { id: "privacy", title: "حریم خصوصی" },
  { id: "intellectual", title: "مالکیت معنوی" },
]

const content = {
  intro: [
    "به BluZiperld خوش آمدید. استفاده از خدمات این وب‌سایت به این معناست که شما با قوانین و مقررات آن موافقت می‌کنید.",
    "ما تلاش کرده‌ایم قوانین را ساده و شفاف بنویسیم تا بدانید هنگام استفاده از سایت دقیقاً چه انتظاری داشته باشید.",
    "به طور خلاصه: از خدمات سایت درست استفاده کنید، اطلاعات واقعی وارد کنید و اجازه بدهید ما هم کارمان را درست انجام دهیم."
  ],

  account: [
    "برای استفاده از برخی خدمات سایت ممکن است نیاز به ایجاد حساب کاربری داشته باشید.",
    "لطفاً اطلاعات صحیح وارد کنید. اگر نام کاربری شما «بتمن واقعی» باشد ما قضاوت نمی‌کنیم، اما اطلاعات تماس بهتر است واقعی باشد.",
    "مسئولیت حفظ اطلاعات حساب کاربری بر عهده شماست."
  ],

  orders: [
    "ثبت سفارش در سایت به معنی درخواست رسمی شما برای دریافت محصول یا خدمات است.",
    "پس از ثبت سفارش، اطلاعات آن بررسی شده و در صورت تأیید وارد مرحله پردازش می‌شود.",
    "در صورت وجود مشکل در اطلاعات سفارش، تیم پشتیبانی ممکن است برای هماهنگی با شما تماس بگیرد."
  ],

  letters: [
    "متنی که برای نامه خود ثبت می‌کنید قبل از ارسال توسط ادمین بررسی می‌شود.",
    "هدف از این بررسی فقط این است که مطمئن شویم متن شامل تهدید، خشونت یا محتوای نامناسب نباشد.",
    "در غیر این صورت تقریباً هر نوع متنی با هر لحن و سبکی قابل قبول است؛ چه نامه عاشقانه باشد چه یک دل‌نوشته ساده.",
    "نگران حریم خصوصی نباشید. ادمین فقط متن را می‌بیند و نمی‌تواند تشخیص دهد این متن متعلق به چه کسی است.",
    "پس از تأیید متن، سفارش شما وارد مرحله پردازش خواهد شد."
  ],

  payment: [
    "پرداخت سفارش‌ها از طریق درگاه‌های امن انجام می‌شود.",
    "پس از تکمیل پرداخت، سفارش شما در سیستم ثبت شده و فرآیند پردازش آغاز خواهد شد.",
    "در صورت بروز خطا در پرداخت، مبلغ طبق قوانین درگاه بانکی به حساب شما بازگردانده خواهد شد."
  ],

  shipping: [
    "سفارش‌ها پس از آماده‌سازی از طریق روش‌های ارسال مشخص‌شده در سایت ارسال می‌شوند.",
    "زمان تحویل بسته به شهر مقصد و شرایط ارسال ممکن است متفاوت باشد.",
    "ما تلاش می‌کنیم سفارش شما در سریع‌ترین زمان ممکن به دستتان برسد."
  ],

  returns: [
    "در صورت وجود مشکل در سفارش می‌توانید از طریق پشتیبانی با ما در تماس باشید.",
    "هر درخواست بررسی یا مرجوعی بر اساس شرایط اعلام‌شده در سایت بررسی خواهد شد.",
    "هدف ما حل سریع و منصفانه مشکلات احتمالی است."
  ],

  privacy: [
    "حفظ حریم خصوصی کاربران برای ما بسیار مهم است.",
    "اطلاعات کاربران فقط برای ارائه خدمات سایت استفاده می‌شود و در اختیار شخص دیگری قرار نمی‌گیرد مگر در موارد قانونی.",
    "ما تلاش می‌کنیم از اطلاعات شما با استانداردهای امنیتی مناسب محافظت کنیم."
  ],

  intellectual: [
    "تمامی محتوای این وب‌سایت شامل طراحی، متن‌ها و تصاویر متعلق به BluZiperld است.",
    "استفاده یا کپی‌برداری از محتوای سایت بدون اجازه ممکن است پیگیری قانونی داشته باشد."
  ]
}

export default function TermsPage() {

  const [active, setActive] = useState("intro")

  useEffect(() => {

    const handleScroll = () => {

      const scrollPosition = window.scrollY + 200

      for (const section of sections) {

        const el = document.getElementById(section.id)

        if (el) {
          if (
            scrollPosition >= el.offsetTop &&
            scrollPosition < el.offsetTop + el.offsetHeight
          ) {
            setActive(section.id)
          }
        }

      }

    }

    window.addEventListener("scroll", handleScroll)

    return () => window.removeEventListener("scroll", handleScroll)

  }, [])

  const scrollToSection = (id) => {

    const el = document.getElementById(id)

    if (el) {
      el.scrollIntoView({ behavior: "smooth" })
    }

  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#0b1120] via-[#0d1425] to-[#0b1120] text-gray-200">

      {/* Hero */}
      <div className="relative py-24 text-center border-b border-blue-500/10">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,rgba(27,108,255,0.15),transparent_70%)]"/>
<h1 className="font-vazir relative text-4xl md:text-5xl font-extrabold tracking-tight bg-clip-text text-transparent bg-gradient-to-r from-blue-500 to-blue-300">
          قوانین و مقررات
        </h1>
        <p className="relative mt-4 text-gray-400 max-w-2xl mx-auto text-sm md:text-base">
          لطفاً پیش از استفاده از خدمات BluZiperld، این قوانین را مطالعه نمایید.
        </p>
      </div>

      <div className="max-w-7xl mx-auto px-6 py-16 grid grid-cols-1 md:grid-cols-4 gap-10">

        {/* Mobile dropdown */}
        <div className="md:hidden mb-8">
          <select
            onChange={(e)=>scrollToSection(e.target.value)}
            className="w-full bg-[#0f172a] border border-blue-500/20 rounded-xl p-3 text-sm"
          >
            {sections.map((s)=>(
              <option key={s.id} value={s.id}>
                {s.title}
              </option>
            ))}
          </select>
        </div>

        {/* Sidebar */}
        <aside className="hidden md:block sticky top-28 h-fit">

          <div className="bg-[#0f172a]/60 backdrop-blur-xl border border-blue-500/10 rounded-2xl p-6 shadow-xl">

            <h3 className="text-xs uppercase tracking-widest text-gray-500 mb-4">
              فهرست مطالب
            </h3>

            <nav className="flex flex-col gap-2">

              {sections.map((section) => (

                <button
                  key={section.id}
                  onClick={()=>scrollToSection(section.id)}
                  className={`text-right text-sm px-3 py-2 rounded-lg transition flex items-center justify-between ${
                    active === section.id
                      ? "text-blue-400 bg-blue-500/10 border-r-2 border-blue-400"
                      : "text-gray-400 hover:text-white"
                  }`}
                >
                  {section.title}
                </button>

              ))}

            </nav>

          </div>

        </aside>

        {/* Content */}
        <div className="md:col-span-3 space-y-16">

          {sections.map((section) => (

            <section
              key={section.id}
              id={section.id}
              className="scroll-mt-28"
            >

              <div className="bg-[#0f172a]/50 backdrop-blur-xl border border-blue-500/10 rounded-3xl p-8 md:p-10 shadow-xl transition hover:border-blue-500/30">

                <h2 className="text-2xl font-bold mb-6 text-blue-400">
                  {section.title}
                </h2>

                <div className="space-y-5 text-gray-300 leading-8 text-sm md:text-base">

                  {content[section.id].map((text, i) => (
                    <p key={i}>{text}</p>
                  ))}

                </div>

              </div>

            </section>

          ))}

          {/* CTA */}
          <div className="mt-20 bg-gradient-to-r from-blue-600/20 to-blue-500/10 border border-blue-500/20 backdrop-blur-xl rounded-3xl p-10 text-center shadow-2xl">

            <h3 className="text-2xl font-bold text-white mb-4">
              سوالی درباره قوانین دارید؟
            </h3>

            <p className="text-gray-400 mb-6 text-sm md:text-base">
              تیم پشتیبانی ما آماده پاسخگویی به سوالات شماست.
            </p>

            <Link
              href="/support"
              className="inline-block px-8 py-3 rounded-2xl bg-blue-600 hover:bg-blue-700 transition text-white font-semibold shadow-lg"
            >
              تماس با پشتیبانی
            </Link>

          </div>

        </div>

      </div>

    </div>
  )
}
