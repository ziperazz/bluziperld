"use client"

import { use, useEffect, useRef, useState } from "react"
import { Send, Lock, Unlock } from "lucide-react"

const api =
  process.env.NEXT_PUBLIC_API_URL?.replace(/\/+$/, "") ||
  "http://localhost:5000"


interface Message {
  _id: string
  senderRole: "USER" | "ADMIN"
  text: string
  createdAt: string
}

interface Ticket {
  _id: string
  subject: string
  status: string
  messages: Message[]
}

export default function AdminSupportTicketPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = use(params)

  const [ticket, setTicket] = useState<Ticket | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [message, setMessage] = useState("")
  const [sending, setSending] = useState(false)

  const chatRef = useRef<HTMLDivElement>(null)
  const prevMessagesLengthRef = useRef(0)
  const shouldScrollToBottomRef = useRef(false)
  const isFirstLoadRef = useRef(true)

  const [token, setToken] = useState<string | null>(null)
  
  useEffect(() => {
  const t = localStorage.getItem("accessToken")
  setToken(t)
}, [])


  // 🔵 Auto scroll هوشمند (دقیقاً مثل صفحه کاربر)
  useEffect(() => {
    if (!chatRef.current || !ticket) return

    const el = chatRef.current
    const currentLength = ticket.messages.length
    const prevLength = prevMessagesLengthRef.current

    // لود اول: هیچ اسکرولی نکن
    if (isFirstLoadRef.current) {
      prevMessagesLengthRef.current = currentLength
      isFirstLoadRef.current = false
      return
    }

    // فقط اگر پیام جدید اضافه شده باشد بررسی کن
    if (currentLength > prevLength) {
      const distanceFromBottom = el.scrollHeight - el.scrollTop - el.clientHeight
      const isNearBottom = distanceFromBottom < 120

      if (shouldScrollToBottomRef.current || isNearBottom) {
        el.scrollTop = el.scrollHeight
        // اگر اسکرول نرم می‌خوای:
        // el.scrollTo({ top: el.scrollHeight, behavior: "smooth" })
      }
    }

    shouldScrollToBottomRef.current = false
    prevMessagesLengthRef.current = currentLength
  }, [ticket?.messages, ticket])

  // 📥 Load ticket details
useEffect(() => {
  if (token === null) return

  if (!token) {
    setError("ابتدا وارد پنل ادمین شوید.")
    setLoading(false)
    return
  }


    async function load() {
      try {
        const res = await fetch(`${api}/api/tickets/${id}`, {
          headers: { Authorization: `Bearer ${token}` },
        })

        const data = await res.json()

        if (data.success) setTicket(data.ticket)
        else setError("تیکت پیدا نشد")
      } catch {
        setError("خطا در ارتباط با سرور")
      } finally {
        setLoading(false)
      }
    }

    load()
  }, [id, token])

  // 🔄 Auto Refresh Messages (Polling)
  useEffect(() => {
    if (!token) return

    const interval = setInterval(async () => {
      try {
        const res = await fetch(`${api}/api/tickets/${id}`, {
          headers: { Authorization: `Bearer ${token}` },
        })
        const data = await res.json()
        if (data.success) {
          setTicket(data.ticket)
        }
      } catch {}
    }, 3000) // هر ۳ ثانیه

    return () => clearInterval(interval)
  }, [id, token])

  // 📤 Send admin message
  async function sendMessage() {
    if (!message.trim() || !token) return
    shouldScrollToBottomRef.current = true
    setSending(true)

    try {
      const res = await fetch(`${api}/api/tickets/${id}/messages`, {
        method: "POST",
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ text: message }),
      })

      const data = await res.json()
      if (data.success) {
        setTicket(data.ticket)
        setMessage("")
      }
    } finally {
      setSending(false)
    }
  }

  // ارسال با Enter
  function handleKeyDown(e: React.KeyboardEvent<HTMLInputElement>) {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault()
      sendMessage()
    }
  }

  // ✏️ Change ticket status
  async function toggleStatus() {
    if (!ticket || !token) return

    const newStatus = ticket.status === "CLOSED" ? "OPEN" : "CLOSED"

    const res = await fetch(`${api}/api/tickets/admin/${id}/status`, {
      method: "PATCH",
      headers: {
        Authorization: `Bearer ${token}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ status: newStatus }),
    })

    const data = await res.json()
    if (data.success) {
      setTicket({ ...ticket, status: newStatus })
    }
  }

  // Loading / Errors
  if (loading) {
    return <div className="text-gray-400 text-center p-10">در حال بارگذاری…</div>
  }

  if (error || !ticket) {
    return <div className="text-red-400 text-center p-10">{error || "تیکت پیدا نشد"}</div>
  }

  return (
    <div className="max-w-5xl mx-auto mt-8 space-y-5">
      {/* Header */}
      <div className="flex items-center justify-between px-2">
        <div className="text-white text-xl font-bold">
          تیکت — {ticket.subject}
        </div>

        <button
          onClick={toggleStatus}
          className={`px-4 py-2 rounded-xl text-white flex items-center gap-2 ${
            ticket.status === "CLOSED" ? "bg-green-600" : "bg-red-600"
          }`}
        >
          {ticket.status === "CLOSED" ? <Unlock size={16} /> : <Lock size={16} />}
          {ticket.status === "CLOSED" ? "باز کردن" : "بستن"}
        </button>
      </div>

      {/* Chat Box */}
      <div className="h-[75vh] bg-[#020617] border border-white/10 rounded-2xl flex flex-col shadow-xl">
        {/* Messages */}
        <div
          ref={chatRef}
          className="chat-scroll flex-1 overflow-y-auto p-4 space-y-4"
        >
          {ticket.messages.map((msg) => (
            <div
              key={msg._id}
              className={`flex ${
                msg.senderRole === "ADMIN" ? "justify-end" : "justify-start"
              }`}
            >
              <div
                className={`max-w-[75%] px-4 py-2 rounded-2xl text-sm ${
                  msg.senderRole === "ADMIN"
                    ? "bg-green-600 text-white"
                    : "bg-white/10 text-gray-300"
                }`}
              >
                {msg.text}

                <div className="text-[10px] text-gray-400 mt-1">
                  {new Date(msg.createdAt).toLocaleTimeString("fa-IR")}
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Input */}
        {ticket.status !== "CLOSED" && (
          <div className="border-t border-white/10 p-3 flex gap-2">
            <input
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              onKeyDown={handleKeyDown}
              placeholder="پاسخ بده..."
              className="flex-1 bg-white/5 border border-white/10 rounded-xl px-3 py-2 text-white text-sm outline-none"
            />
            <button
              onClick={sendMessage}
              disabled={sending}
              className="bg-green-600 hover:bg-green-500 transition rounded-xl px-4 text-white flex items-center disabled:opacity-60"
            >
              <Send size={16} />
            </button>
          </div>
        )}
      </div>
    </div>
  )
}
