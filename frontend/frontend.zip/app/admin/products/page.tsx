"use client";

import React, { useEffect, useState } from "react";
import { Trash2, Edit, Plus, Search, Eye, Package } from "lucide-react";
import ModalProductForm from "./ModalProductForm";

interface Product {
  _id: string;
  title: string;
  price: number;
  discount?: number;
  priceAfterDiscount?: number;
  instock: number;
  category: string;
  images?: string[];
  visits?: number;
  purchaseCount?: number;
  description?: string;
  ratingAverage?: number;
  rating?: number;
  specs?: Record<string, any>;
}

export default function AdminProductsPage() {
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState("");

  // ---- Modal States ----
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);

  useEffect(() => {
    fetchProducts();
  }, []);

  const fetchProducts = async () => {
    try {
      const res = await fetch("http://127.0.0.1:5000/api/products");
      const data = await res.json();
      setProducts(data);
    } catch (error) {
      console.error("خطا در دریافت محصولات:", error);
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async (id: string) => {
    if (!confirm("آیا از حذف این محصول مطمئن هستید؟")) return;
    try {
      const res = await fetch(`http://127.0.0.1:5000/api/products/${id}`, {
        method: "DELETE",
      });
      if (res.ok) {
        setProducts((prev) => prev.filter((p) => p._id !== id));
      }
    } catch (error) {
      alert("خطا در حذف");
    }
  };

  const handleSave = async (data: any) => {
    try {
      const formData = new FormData();

      // --- فیلدهای معمولی ---
      formData.append("title", data.title);
      formData.append("price", String(data.price));
      formData.append("discount", String(data.discount || 0));
      formData.append("instock", String(data.instock));
      formData.append("category", data.category);

      // --- فیلدهای تکمیلی / مدیریتی ---
      formData.append("description", data.description || "");
      formData.append("purchaseCount", String(data.purchaseCount || 0));
      formData.append("ratingAverage", String(data.ratingAverage || 0));
      formData.append("rating", String(data.rating || 0));
      formData.append("visits", String(data.visits || 0));

      // --- specs (اگر داشته باشی) ---
      if (data.specs) {
        formData.append("specs", JSON.stringify(data.specs));
      }

      // --- تصاویر جدید (فایل‌ها) ---
// --- تصاویر جدید (فایل‌ها) ---
if (data.imageFiles && data.imageFiles.length > 0) {
  data.imageFiles.forEach((file: File) => {
    formData.append("images", file);
  });
}

// --- تصاویر قبلی (URL ها) ---
if (data.images && data.images.length > 0) {
  // ارسال کل آرایه تصاویر قبلی به صورت JSON
  formData.append("existingImages", JSON.stringify(data.images));
}


      // اگر بک‌اندت به جای این، دنبال existingImages می‌گرده
      // این بلاک بالا رو بردار و به‌جاش از این استفاده کن:
      //
      // if (data.images && data.images.length > 0) {
      //   formData.append("existingImages", JSON.stringify(data.images));
      // }

      let url = `http://127.0.0.1:5000/api/products`;
      let method = "POST";

      if (editingProduct) {
        url = `http://127.0.0.1:5000/api/products/${editingProduct._id}`;
        method = "PUT";
      }

      const res = await fetch(url, {
        method,
        body: formData, // بدون تعیین Content-Type دستی
      });

      if (res.ok) {
        setIsModalOpen(false);
        setEditingProduct(null);
        fetchProducts();
      } else {
        const errorText = await res.text();
        console.error("خطا در ذخیره:", errorText);
        alert(`خطا در ذخیره‌سازی محصول: ${errorText || res.statusText}`);
      }
    } catch (err) {
      console.error("خطا در اتصال یا پردازش:", err);
      alert("خطا در اتصال به سرور یا پردازش داده");
    }
  };

  const filteredProducts = products.filter((p) =>
    p.title.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="p-6 text-right" dir="rtl">
      {/* HEADER */}
      <div className="flex justify-between items-center mb-8">
        <div>
          <h1 className="text-3xl font-extrabold bg-gradient-to-r from-blue-300 to-blue-500 bg-clip-text text-transparent">
            مدیریت محصولات
          </h1>
          <p className="text-blue-300/70 mt-1 text-sm">
            لیست کامل محصولات فروشگاه
          </p>
        </div>

        {/* ADD BUTTON */}
        <button
          onClick={() => {
            setEditingProduct(null);
            setIsModalOpen(true);
          }}
          className="bg-gradient-to-r from-blue-500 to-blue-700
            text-white px-5 py-2.5 rounded-xl shadow-lg shadow-blue-800/30
            hover:shadow-blue-600/40 transition-all flex items-center gap-2
            backdrop-blur-xl border border-blue-400/20"
        >
          <Plus size={20} />
          افزودن محصول جدید
        </button>
      </div>

      {/* SEARCH BOX */}
      <div
        className="bg-blue-900/20 border border-white/10 backdrop-blur-xl 
        p-5 rounded-2xl shadow-lg shadow-blue-900/10 mb-7
        flex flex-wrap gap-4 items-center"
      >
        <div className="relative flex-1 min-w-[300px]">
          <Search
            className="absolute right-3 top-1/2 -translate-y-1/2 text-blue-200"
            size={18}
          />
          <input
            type="text"
            placeholder="جستجو در نام محصول..."
            className="w-full pr-10 pl-4 py-2 rounded-xl 
              bg-blue-900/30 text-blue-100 placeholder-blue-300
              border border-blue-300/20 
              focus:outline-none focus:ring-2 focus:ring-blue-500/40"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>

        <span
          className="bg-blue-800/40 text-blue-100 border border-blue-500/20 
          px-3 py-1 rounded-lg text-sm"
        >
          تعداد کل: {products.length}
        </span>
      </div>

      {/* TABLE */}
      <div
        className="bg-blue-900/20 backdrop-blur-xl rounded-2xl
        border border-white/10 shadow-xl shadow-blue-900/20 overflow-hidden"
      >
        <table className="w-full text-right text-blue-100">
          <thead className="bg-blue-900/40 border-b border-white/10">
            <tr>
              <th className="p-4 text-sm font-semibold">تصویر و عنوان</th>
              <th className="p-4 text-sm font-semibold">قیمت</th>
              <th className="p-4 text-sm font-semibold">دسته</th>
              <th className="p-4 text-sm font-semibold">موجودی</th>
              <th className="p-4 text-sm font-semibold">تعداد خرید</th>
              <th className="p-4 text-sm font-semibold">بازدید</th>
              <th className="p-4 text-sm font-semibold text-center">عملیات</th>
            </tr>
          </thead>

          <tbody className="divide-y divide-white/5">
            {loading ? (
              <tr>
                <td colSpan={7} className="p-10 text-center text-blue-300/70">
                  ... در حال بارگذاری ...
                </td>
              </tr>
            ) : (
              filteredProducts.map((product) => (
                <tr
                  key={product._id}
                  className="hover:bg-blue-900/30 transition"
                >
                  {/* تصویر و عنوان */}
                  <td className="p-4">
                    <div className="flex items-center gap-3">
                      <div
                        className="w-12 h-12 rounded-lg bg-blue-800/40 border border-white/10
                        overflow-hidden flex items-center justify-center"
                      >
                        {product.images?.[0] ? (
                          <img
                            src={product.images[0]}
                            className="w-full h-full object-cover"
                            alt=""
                          />
                        ) : (
                          <Package className="text-blue-200 w-5 h-5" />
                        )}
                      </div>

                      <div>
                        <div className="font-bold text-blue-100">
                          {product.title}
                        </div>
                        <div className="text-xs text-blue-300/70">
                          {product.category}
                        </div>
                      </div>
                    </div>
                  </td>

                  {/* قیمت */}
                  <td className="p-4">
                    <div className="text-blue-300 font-bold">
                      {(
                        product.priceAfterDiscount ?? product.price
                      ).toLocaleString()}{" "}
                      تومان
                    </div>
                    {product.discount ? (
                      <div className="text-xs text-blue-400/50 line-through">
                        {product.price.toLocaleString()}
                      </div>
                    ) : null}
                  </td>

                  {/* دسته */}
                  <td className="p-4 text-blue-300/90">{product.category}</td>

                  {/* موجودی */}
                  <td className="p-4 text-sm">
                    <span
                      className={`text-xs ${
                        product.instock > 0
                          ? "text-green-300"
                          : "text-red-400"
                      }`}
                    >
                      {product.instock} عدد
                    </span>
                  </td>

                  {/* تعداد خرید */}
                  <td className="p-4 text-blue-300/90 text-sm">
                    {product.purchaseCount ?? 0}
                  </td>

                  {/* بازدید */}
                  <td className="p-4 text-sm flex items-center gap-1 text-blue-300/80">
                    <Eye size={13} />
                    {product.visits ?? 0}
                  </td>

                  {/* عملیات */}
                  <td className="p-4 text-center">
                    <div className="flex justify-center gap-2">
                      <button
                        onClick={() => {
                          setEditingProduct(product);
                          setIsModalOpen(true);
                        }}
                        className="p-2 rounded-lg text-blue-300 hover:bg-blue-800/40 transition"
                      >
                        <Edit size={18} />
                      </button>

                      <button
                        onClick={() => handleDelete(product._id)}
                        className="p-2 rounded-lg text-red-400 hover:bg-red-900/30 transition"
                      >
                        <Trash2 size={18} />
                      </button>
                    </div>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      {/* ---------- MODAL HERE ---------- */}
      <ModalProductForm
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        editData={editingProduct}
        onSave={handleSave}
      />
    </div>
  );
}
