"use client";

import React, { useEffect, useState } from "react";

interface Spec {
  label: string;
  value: string;
}

interface ProductFormData {
  title: string;
  price: number;
  description: string;
  images: string[];
  imageFiles: File[];
  specs: Spec[];
  category: string;
  instock: number;
  purchaseCount: number;
  ratingAverage: number;
  rating: number;
  discount: number;
  visits: number;
}

interface ModalProductFormProps {
  isOpen: boolean;
  onClose: () => void;
  editData: ProductFormData | null;
  onSave: (data: ProductFormData) => void;
}

const defaultProduct: ProductFormData = {
  title: "",
  price: 0,
  description: "",
  images: [],
  imageFiles: [],
  specs: [],
  category: "",
  instock: 0,
  purchaseCount: 0,
  ratingAverage: 0,
  rating: 0,
  discount: 0,
  visits: 0,
};

export default function ModalProductForm({
  isOpen,
  onClose,
  editData,
  onSave,
}: ModalProductFormProps) {

  const [formData, setFormData] = useState<ProductFormData>(defaultProduct);
  const [errors, setErrors] = useState<Record<string, string>>({});

  // -------------------------------
  // پر کردن فرم هنگام ویرایش
  // -------------------------------
  useEffect(() => {
    if (editData) {
      setFormData({
        ...editData,
        images: (editData.images || []).filter(
          (img) =>
            typeof img === "string" &&
            img.trim() !== "" &&
            img.trim() !== "/placeholder.png" &&
            img.trim() !== "placeholder.png"
        ),
        imageFiles: [],
      });
    } else {
      setFormData(defaultProduct);
    }
    setErrors({});
  }, [editData, isOpen]);

  // -------------------------------
  const updateField = (field: keyof ProductFormData, value: any) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
  };

  // -------------------------------
  function validate() {
    const errs: Record<string, string> = {};

    if (!formData.title.trim()) errs.title = "عنوان محصول الزامی است.";
    if (formData.price < 0) errs.price = "قیمت نمی‌تواند منفی باشد.";
    if (formData.discount < 0 || formData.discount > 100)
      errs.discount = "تخفیف باید بین 0 تا 100 باشد.";
    if (!formData.category.trim()) errs.category = "دسته‌بندی cannot be empty.";

    setErrors(errs);
    return Object.keys(errs).length === 0;
  }

  // -------------------------------
  const handleChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>
  ) => {
    const { name, value } = e.target;

    if (
      ["price", "instock", "purchaseCount", "ratingAverage", "rating", "discount", "visits"].includes(name)
    ) {
      updateField(name as any, Number(value));
    } else {
      updateField(name as any, value);
    }
  };

  // -------------------------------
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!validate()) return;

    const cleanedImages = (formData.images || []).filter(
      (img) =>
        typeof img === "string" &&
        img.trim() !== "" &&
        img.trim() !== "/placeholder.png" &&
        img.trim() !== "placeholder.png"
    );

    onSave({
      ...formData,
      images: cleanedImages,
    });
  };

  if (!isOpen) return null;

  return (
    <div
      dir="rtl"
      className="fixed inset-0 bg-black/50 backdrop-blur-lg flex items-center justify-center z-[9999]"
      onClick={onClose}
    >
      <div
        className="bg-blue-900/80 backdrop-blur-2xl shadow-blue-950 shadow-2xl
                   rounded-3xl p-8 max-w-4xl w-full max-h-[90vh] overflow-y-auto"
        onClick={(e) => e.stopPropagation()}
      >
        <h2 className="text-center text-3xl font-bold text-blue-100 mb-8">
          {editData ? "ویرایش محصول" : "افزودن محصول جدید"}
        </h2>

        <form onSubmit={handleSubmit} className="space-y-6">

          {/* فیلدها */}
          <InputField label="عنوان محصول" name="title" value={formData.title}
            onChange={handleChange} error={errors.title} placeholder="عنوان محصول" />

          <TextareaField label="توضیحات" name="description"
            value={formData.description} onChange={handleChange} placeholder="توضیحات محصول..." />

          <InputField type="number" label="قیمت (تومان)" name="price"
            value={formData.price} onChange={handleChange} error={errors.price} placeholder="قیمت محصول" />

          <InputField type="number" label="تخفیف (%)" name="discount"
            min={0} max={100} value={formData.discount} onChange={handleChange}
            error={errors.discount} placeholder="درصد تخفیف" />

          <InputField type="number" label="موجودی" name="instock"
            value={formData.instock} onChange={handleChange} placeholder="موجودی انبار" />

          <InputField label="دسته‌بندی (متنی آزاد)" name="category"
            value={formData.category} onChange={handleChange}
            error={errors.category} placeholder="مثال: لباس، دیجیتال، کتاب..." />

          <InputField type="number" label="تعداد خرید" name="purchaseCount"
            value={formData.purchaseCount} onChange={handleChange} />

          <InputField type="number" label="میانگین امتیاز" name="ratingAverage"
            value={formData.ratingAverage} onChange={handleChange} placeholder="بین 0 تا 5" />

          <InputField type="number" label="امتیاز" name="rating"
            value={formData.rating} onChange={handleChange} />

          <InputField type="number" label="بازدید" name="visits"
            value={formData.visits} onChange={handleChange} />

          {/* 📌 آپلود فایل (جدید) */}
          <FileImagesManager
            files={formData.imageFiles}
            onAdd={(files: File[]) =>
              updateField("imageFiles", [...formData.imageFiles, ...files])
            }
            onRemove={(i: number) =>
              updateField(
                "imageFiles",
                formData.imageFiles.filter((_, x) => x !== i)
              )
            }
          />

          {/* 📌 مدیریت عکس‌های قدیمی (فرانت) */}
          {formData.images && formData.images.length > 0 && (
            <ExistingImagesManager
              images={formData.images}
              onRemove={(idx: number) => {
                const updated = formData.images.filter((_, i) => i !== idx);
                updateField("images", updated);
              }}
            />
          )}

          {/* مشخصات فنی */}
          <SpecsManager
            specs={formData.specs}
            onAdd={() =>
              updateField("specs", [...formData.specs, { label: "", value: "" }])
            }
            onChange={(idx: number, field: string, val: string) => {
              const newSpecs = [...formData.specs];
              newSpecs[idx] = { ...newSpecs[idx], [field]: val };
              updateField("specs", newSpecs);
            }}
            onRemove={(idx: number) =>
              updateField("specs", formData.specs.filter((_, i) => i !== idx))
            }
          />

          {/* دکمه‌ها */}
          <div className="flex justify-end gap-4 pt-8 border-t border-blue-800">
            <button
              type="button"
              onClick={onClose}
              className="px-6 py-2 rounded-xl border border-blue-500 text-blue-200
                         hover:bg-blue-700 hover:text-white transition"
            >
              لغو
            </button>

            <button
              type="submit"
              className="px-6 py-2 rounded-xl bg-gradient-to-r from-blue-600 to-blue-900
                         text-white font-bold hover:shadow-blue-900/70 transition shadow-lg"
            >
              ذخیره محصول
            </button>
          </div>

        </form>
      </div>
    </div>
  );
}

/* ----------------------------------------------------
   🔹 Components
---------------------------------------------------- */

function InputField({ label, name, value, onChange, error, placeholder, type = "text", ...rest }: any) {
  return (
    <div>
      <label className="text-blue-200 font-semibold mb-1 block">{label}</label>
      <input
        name={name}
        type={type}
        value={value}
        onChange={onChange}
        className="glass-input w-full"
        placeholder={placeholder}
        {...rest}
      />
      {error && <p className="text-red-400 text-sm mt-1">{error}</p>}
    </div>
  );
}

function TextareaField({ label, name, value, onChange, placeholder }: any) {
  return (
    <div>
      <label className="text-blue-200 font-semibold mb-1 block">{label}</label>
      <textarea
        name={name}
        value={value}
        onChange={onChange}
        className="glass-input w-full resize-y"
        placeholder={placeholder}
        rows={3}
      />
    </div>
  );
}

/* ----------------------------------------------------
   📌 فایل‌های جدید
---------------------------------------------------- */

function FileImagesManager({ files, onAdd, onRemove }: any) {
  return (
    <div className="space-y-3">
      <label className="text-blue-200 font-semibold block">آپلود تصاویر</label>

      <input
        type="file"
        multiple
        accept="image/*"
        className="glass-input w-full"
        onChange={(e) => {
          if (!e.target.files) return;
          onAdd(Array.from(e.target.files));
        }}
      />

      {files.map((file: File, i: number) => (
        <div key={i} className="flex justify-between items-center text-blue-200 text-sm">
          {file.name}
          <button
            type="button"
            className="text-red-400"
            onClick={() => onRemove(i)}
          >
            حذف
          </button>
        </div>
      ))}
    </div>
  );
}

/* ----------------------------------------------------
   📌 نمایش و حذف عکس‌های قدیمی
---------------------------------------------------- */

function ExistingImagesManager({
  images,
  onRemove,
}: {
  images: string[];
  onRemove: (idx: number) => void;
}) {
  const apiBase =
    process.env.NEXT_PUBLIC_API_URL?.replace(/\/+$/, "") ||
    "http://localhost:5000";

  const buildImageUrl = (img: string) => {
    if (!img) return "/placeholder.png";
    if (/^https?:\/\//i.test(img)) return img;
    if (!img.startsWith("/uploads")) {
      return `${apiBase}/uploads/${img.replace(/^\/+/, "")}`;
    }
    return `${apiBase}${img}`;
  };

  return (
    <div className="space-y-3 mt-4">
      <label className="text-blue-200 font-semibold block">تصاویر فعلی محصول</label>

      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
        {images.map((img, i) => (
          <div
            key={i}
            className="relative bg-blue-900/40 border border-blue-700/50 rounded-xl p-2 flex flex-col items-center"
          >
            <img
              src={buildImageUrl(img)}
              alt={`product-image-${i}`}
              className="w-full h-24 object-contain rounded-lg mb-2 bg-blue-950/60"
              onError={(e) => {
                (e.currentTarget as HTMLImageElement).src = "/placeholder.png";
              }}
            />

            <button
              type="button"
              onClick={() => onRemove(i)}
              className="px-3 py-1 text-xs bg-red-600/80 text-white rounded-lg hover:bg-red-700 transition"
            >
              حذف تصویر
            </button>
          </div>
        ))}
      </div>
    </div>
  );
}

/* ----------------------------------------------------
   📌 مشخصات فنی
---------------------------------------------------- */

function SpecsManager({ specs, onAdd, onChange, onRemove }: any) {
  return (
    <div className="space-y-3">
      <label className="text-blue-200 font-semibold block">مشخصات فنی</label>

      <div className="space-y-3 border border-blue-700/40 bg-blue-900/40 rounded-xl p-4 max-h-52 overflow-y-auto">
        {specs.map((s: Spec, i: number) => (
          <div key={i} className="flex gap-3 items-center">
            <input
              className="glass-input flex-1"
              placeholder="برچسب"
              value={s.label}
              onChange={(e) => onChange(i, "label", e.target.value)}
            />

            <input
              className="glass-input flex-1"
              placeholder="مقدار"
              value={s.value}
              onChange={(e) => onChange(i, "value", e.target.value)}
            />

            <button
              type="button"
              className="px-3 py-1 text-red-300 hover:text-red-600 hover:bg-red-600/20 rounded-lg transition"
              onClick={() => onRemove(i)}
            >
              حذف
            </button>
          </div>
        ))}
      </div>

      <button
        type="button"
        onClick={onAdd}
        className="px-4 py-2 bg-blue-800 text-white rounded-lg font-semibold hover:bg-blue-900 transition"
      >
        افزودن مشخصه +
      </button>
    </div>
  );
}
