"use client";

import React, { useEffect, useState } from "react";

interface Spec {
  label: string;
  value: string;
}

interface LetterFormData {
  title: string;
  description: string;
  category: string;
  price: number;
  discount: number;
  instock: number;
  images: string[];
  imageFiles: File[];
  specs: Spec[];
  isActive: boolean;
  printingExtraPrice: number;
  handwritingExtraPrice: number;
  visits: number;
  purchaseCount: number;
  ratingAverage: number;
  rating: number;
}

interface Props {
  isOpen: boolean;
  onClose: () => void;
  editData: LetterFormData | null;
  onSave: (data: LetterFormData) => void;
}

const defaultLetter: LetterFormData = {
  title: "",
  description: "",
  category: "",
  price: 0,
  discount: 0,
  instock: 0,
  images: [],
  imageFiles: [],
  specs: [],
  isActive: true,
  printingExtraPrice: 0,
  handwritingExtraPrice: 0,
  visits: 0,
  purchaseCount: 0,
  ratingAverage: 0,
  rating: 0,
};

export default function ModalLetterForm({
  isOpen,
  onClose,
  editData,
  onSave,
}: Props) {
  const [formData, setFormData] = useState<LetterFormData>(defaultLetter);
  const [errors, setErrors] = useState<Record<string, string>>({});

  useEffect(() => {
    if (editData) {
      setFormData({
        ...editData,
        imageFiles: [],
      });
    } else {
      setFormData(defaultLetter);
    }
    setErrors({});
  }, [editData, isOpen]);

  const updateField = (field: keyof LetterFormData, value: any) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
  };

  function validate() {
    const errs: Record<string, string> = {};

    if (!formData.title.trim()) errs.title = "عنوان الزامی است";
    if (!formData.category.trim()) errs.category = "دسته‌بندی الزامی است";
    if (formData.price < 0) errs.price = "قیمت نامعتبر است";
    if (formData.discount < 0 || formData.discount > 100)
      errs.discount = "تخفیف بین 0 تا 100";

    setErrors(errs);
    return Object.keys(errs).length === 0;
  }

  const handleChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>
  ) => {
    const { name, value, type } = e.target;

    if (type === "checkbox") {
      updateField(name as any, (e.target as HTMLInputElement).checked);
      return;
    }

    if (
      [
        "price",
        "discount",
        "instock",
        "printingExtraPrice",
        "handwritingExtraPrice",
        "visits",
        "purchaseCount",
        "ratingAverage",
        "rating",
      ].includes(name)
    ) {
      updateField(name as any, Number(value));
    } else {
      updateField(name as any, value);
    }
  };

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!validate()) return;
    onSave(formData);
  };

  if (!isOpen) return null;

  return (
    <div
      dir="rtl"
      className="fixed inset-0 bg-black/50 backdrop-blur flex items-center justify-center z-[9999]"
      onClick={onClose}
    >
      <div
        className="bg-blue-900/80 backdrop-blur-xl rounded-3xl p-8 w-full max-w-4xl max-h-[90vh] overflow-y-auto"
        onClick={(e) => e.stopPropagation()}
      >
        <h2 className="text-3xl text-blue-100 font-bold mb-8 text-center">
          {editData ? "ویرایش پاکت نامه" : "افزودن پاکت نامه"}
        </h2>

        <form onSubmit={submit} className="space-y-6">
          <Input label="عنوان" name="title" value={formData.title} onChange={handleChange} error={errors.title} />

          <Textarea label="توضیحات" name="description" value={formData.description} onChange={handleChange} />

          <Input label="دسته بندی" name="category" value={formData.category} onChange={handleChange} error={errors.category} />

          <Input type="number" label="قیمت" name="price" value={formData.price} onChange={handleChange} error={errors.price} />

          <Input type="number" label="تخفیف" name="discount" value={formData.discount} onChange={handleChange} error={errors.discount} />

          <Input type="number" label="موجودی" name="instock" value={formData.instock} onChange={handleChange} />

          <Input type="number" label="هزینه چاپ اضافه" name="printingExtraPrice" value={formData.printingExtraPrice} onChange={handleChange} />

          <Input type="number" label="هزینه دست نویس" name="handwritingExtraPrice" value={formData.handwritingExtraPrice} onChange={handleChange} />

          <Input type="number" label="بازدید" name="visits" value={formData.visits} onChange={handleChange} />

          <Input type="number" label="تعداد خرید" name="purchaseCount" value={formData.purchaseCount} onChange={handleChange} />

          <Input type="number" label="میانگین امتیاز" name="ratingAverage" value={formData.ratingAverage} onChange={handleChange} />

          <Input type="number" label="امتیاز" name="rating" value={formData.rating} onChange={handleChange} />

          <div className="flex items-center gap-3">
            <input type="checkbox" name="isActive" checked={formData.isActive} onChange={handleChange} />
            <span className="text-blue-200">فعال باشد</span>
          </div>

          <FileImagesManager
            files={formData.imageFiles}
            onAdd={(files: File[]) =>
              updateField("imageFiles", [...formData.imageFiles, ...files])
            }
            onRemove={(i: number) =>
              updateField(
                "imageFiles",
                formData.imageFiles.filter((_, x) => x !== i)
              )
            }
          />

          {formData.images.length > 0 && (
            <ExistingImagesManager
              images={formData.images}
              onRemove={(idx: number) =>
                updateField(
                  "images",
                  formData.images.filter((_, i) => i !== idx)
                )
              }
            />
          )}

          <SpecsManager
            specs={formData.specs}
            onAdd={() =>
              updateField("specs", [...formData.specs, { label: "", value: "" }])
            }
            onChange={(i, field, val) => {
              const arr = [...formData.specs];
              arr[i] = { ...arr[i], [field]: val };
              updateField("specs", arr);
            }}
            onRemove={(i) =>
              updateField(
                "specs",
                formData.specs.filter((_, x) => x !== i)
              )
            }
          />

          <div className="flex justify-end gap-4 pt-6 border-t border-blue-800">
            <button type="button" onClick={onClose} className="px-5 py-2 border border-blue-500 rounded-xl text-blue-200">
              لغو
            </button>

            <button type="submit" className="px-6 py-2 bg-blue-700 rounded-xl text-white font-bold">
              ذخیره
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

/* ---------- Image Upload ---------- */

function FileImagesManager({ files, onAdd, onRemove }: any) {
  return (
    <div className="space-y-3">
      <label className="text-blue-200 font-semibold block">
        آپلود تصاویر پاکت نامه
      </label>

      <input
        type="file"
        multiple
        accept="image/*"
        className="w-full bg-blue-950/60 border border-blue-700 rounded-lg p-2 text-white"
        onChange={(e) => {
          if (!e.target.files) return;
          onAdd(Array.from(e.target.files));
        }}
      />

      {files.map((file: File, i: number) => (
        <div key={i} className="flex justify-between text-blue-200 text-sm">
          {file.name}
          <button type="button" className="text-red-400" onClick={() => onRemove(i)}>
            حذف
          </button>
        </div>
      ))}
    </div>
  );
}

/* ---------- Existing Images ---------- */

function ExistingImagesManager({ images, onRemove }: any) {
  const apiBase =
    process.env.NEXT_PUBLIC_API_URL?.replace(/\/+$/, "") ||
    "http://localhost:5000";

  const buildImageUrl = (img: string) => {
    if (/^https?:\/\//i.test(img)) return img;
    if (!img.startsWith("/uploads")) return `${apiBase}/uploads/${img}`;
    return `${apiBase}${img}`;
  };

  return (
    <div className="space-y-3 mt-4">
      <label className="text-blue-200 font-semibold block">
        تصاویر فعلی پاکت نامه
      </label>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {images.map((img: string, i: number) => (
          <div key={i} className="bg-blue-900/40 border border-blue-700 rounded-xl p-2">
            <img
              src={buildImageUrl(img)}
              className="w-full h-24 object-contain mb-2"
            />
            <button
              type="button"
              onClick={() => onRemove(i)}
              className="text-xs bg-red-600 text-white px-2 py-1 rounded"
            >
              حذف تصویر
            </button>
          </div>
        ))}
      </div>
    </div>
  );
}

/* ---------- Specs ---------- */

function SpecsManager({ specs, onAdd, onChange, onRemove }: any) {
  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <label className="text-blue-200 font-semibold">مشخصات</label>

        <button
          type="button"
          onClick={onAdd}
          className="px-3 py-1 bg-blue-700 text-white text-sm rounded"
        >
          افزودن
        </button>
      </div>

      {specs.map((spec: Spec, i: number) => (
        <div key={i} className="grid grid-cols-3 gap-3">
          <input
            value={spec.label}
            placeholder="عنوان"
            onChange={(e) => onChange(i, "label", e.target.value)}
            className="bg-blue-900/60 border border-blue-700 rounded px-2 py-1 text-white"
          />

          <input
            value={spec.value}
            placeholder="مقدار"
            onChange={(e) => onChange(i, "value", e.target.value)}
            className="bg-blue-900/60 border border-blue-700 rounded px-2 py-1 text-white"
          />

          <button
            type="button"
            onClick={() => onRemove(i)}
            className="bg-red-600 text-white rounded px-2"
          >
            حذف
          </button>
        </div>
      ))}
    </div>
  );
}

/* ---------- Inputs ---------- */

function Input({ label, name, value, onChange, type = "text", error }: any) {
  return (
    <div className="space-y-1">
      <label className="text-blue-200">{label}</label>
      <input
        type={type}
        name={name}
        value={value}
        onChange={onChange}
        className="w-full bg-blue-950/60 border border-blue-700 rounded px-3 py-2 text-white"
      />
      {error && <p className="text-red-400 text-sm">{error}</p>}
    </div>
  );
}

function Textarea({ label, name, value, onChange }: any) {
  return (
    <div className="space-y-1">
      <label className="text-blue-200">{label}</label>
      <textarea
        name={name}
        value={value}
        onChange={onChange}
        className="w-full h-32 bg-blue-950/60 border border-blue-700 rounded px-3 py-2 text-white"
      />
    </div>
  );
}
