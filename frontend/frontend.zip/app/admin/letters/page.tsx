"use client";

import React, { useEffect, useState } from "react";
import {
  Trash2,
  Edit,
  Plus,
  Search,
  Printer,
  PenTool,
  Eye,
  Package,
  ShoppingBag,
} from "lucide-react";
import ModalLetterForm from "./ModalLetterForm";

interface Letter {
  _id: string;
  title: string;
  price: number;
  description?: string;
  category: string;
  discount?: number;
  priceAfterDiscount?: number;
  instock: number;
  images?: string[];
  isActive?: boolean;
  printingExtraPrice?: number;
  handwritingExtraPrice?: number;
  visits?: number;
  purchaseCount?: number;
  ratingAverage?: number;
  rating?: number;
  specs?: any[];
}

const API_BASE = "http://127.0.0.1:5000/api/letters";

export default function AdminLettersPage() {
  const [letters, setLetters] = useState<Letter[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState("");
  const [modalOpen, setModalOpen] = useState(false);
  const [editingLetter, setEditingLetter] = useState<Letter | null>(null);

  useEffect(() => {
    fetchLetters();
  }, []);

  const fetchLetters = async () => {
    try {
      setLoading(true);
      const res = await fetch(API_BASE);

      if (!res.ok) {
        throw new Error("خطا در دریافت لیست پاکت‌نامه‌ها");
      }

      const data = await res.json();
      setLetters(Array.isArray(data) ? data : []);
    } catch (error) {
      console.error("خطا در دریافت پاکت‌نامه‌ها:", error);
      alert("خطا در دریافت پاکت‌نامه‌ها");
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async (id: string) => {
    const confirmed = confirm("آیا از حذف این پاکت‌نامه مطمئن هستید؟");
    if (!confirmed) return;

    try {
      const res = await fetch(`${API_BASE}/${id}`, {
        method: "DELETE",
      });

      if (!res.ok) {
        const msg = await res.text();
        throw new Error(msg || "حذف انجام نشد");
      }

      setLetters((prev) => prev.filter((item) => item._id !== id));
    } catch (error) {
      console.error("خطا در حذف:", error);
      alert("خطا در حذف");
    }
  };

  const openAddModal = () => {
    setEditingLetter(null);
    setModalOpen(true);
  };

  const openEditModal = (letter: Letter) => {
    setEditingLetter(letter);
    setModalOpen(true);
  };

  const handleSaveLetter = async (data: any) => {
    try {
      const formData = new FormData();

      const fields = [
        "title",
        "description",
        "category",
        "price",
        "discount",
        "instock",
        "isActive",
        "printingExtraPrice",
        "handwritingExtraPrice",
        "visits",
        "purchaseCount",
        "ratingAverage",
        "rating",
      ];

      fields.forEach((key) => {
        const value = data?.[key];
        if (value !== undefined && value !== null && value !== "") {
          formData.append(key, String(value));
        }
      });

      if (data?.specs) {
        formData.append("specs", JSON.stringify(data.specs));
      }

      if (Array.isArray(data?.images)) {
        data.images.forEach((img: string) => {
          if (typeof img === "string" && img.trim()) {
            formData.append("existingImages", img.trim());
          }
        });
      }

      if (Array.isArray(data?.imageFiles)) {
        data.imageFiles.forEach((file: File) => {
          if (file instanceof File) {
            formData.append("images", file);
          }
        });
      }

      const isEditMode = !!editingLetter?._id;
      const url = isEditMode ? `${API_BASE}/${editingLetter._id}` : API_BASE;
      const method = isEditMode ? "PUT" : "POST";

      console.log("Saving letter:", {
        method,
        url,
        editingLetter,
      });

      const res = await fetch(url, {
        method,
        body: formData,
      });

      if (!res.ok) {
        const msg = await res.text();
        console.error("❌ خطا در ذخیره:", msg);
        alert(`خطا در ذخیره: ${msg || "درخواست ناموفق بود"}`);
        return;
      }

      setModalOpen(false);
      setEditingLetter(null);
      await fetchLetters();
    } catch (err) {
      console.error("❌ خطا در اتصال:", err);
      alert("خطا در اتصال به سرور");
    }
  };

  const filteredLetters = letters.filter((letter) =>
    letter.title?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="p-6 text-right" dir="rtl">
      <div className="flex justify-between items-center mb-8">
        <div>
          <h1 className="text-3xl font-extrabold bg-gradient-to-r from-blue-300 to-blue-500 bg-clip-text text-transparent">
            مدیریت پاکت‌نامه‌ها
          </h1>
          <p className="text-blue-300/70 mt-1 text-sm">
            لیست محصولات بخش نامه و پاکت
          </p>
        </div>

        <button
          onClick={openAddModal}
          className="bg-gradient-to-r from-blue-500 to-blue-700 text-white px-5 py-2.5 rounded-xl shadow-lg flex items-center gap-2 border border-blue-400/20"
        >
          <Plus size={20} />
          افزودن نامه جدید
        </button>
      </div>

      <div className="bg-blue-900/20 border border-white/10 backdrop-blur-xl p-5 rounded-2xl mb-7 flex flex-wrap gap-4 items-center">
        <div className="relative flex-1 min-w-[300px]">
          <Search
            className="absolute right-3 top-1/2 -translate-y-1/2 text-blue-200"
            size={18}
          />
          <input
            type="text"
            placeholder="جستجو در عنوان پاکت‌نامه‌ها..."
            className="w-full pr-10 pl-4 py-2 rounded-xl bg-blue-900/30 text-blue-100 border border-blue-300/20 focus:outline-none"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>

        <span className="bg-blue-800/40 text-blue-100 border border-blue-500/20 px-3 py-1 rounded-lg text-sm">
          تعداد کل: {letters.length}
        </span>
      </div>

      <div className="bg-blue-900/20 backdrop-blur-xl rounded-2xl border border-white/10 shadow-xl overflow-hidden">
        <table className="w-full text-right text-blue-100">
          <thead className="bg-blue-900/40 border-b border-white/10">
            <tr>
              <th className="p-4 text-sm font-semibold">تصویر و عنوان</th>
              <th className="p-4 text-sm font-semibold">دسته</th>
              <th className="p-4 text-sm font-semibold">قیمت</th>
              <th className="p-4 text-sm font-semibold">خدمات اضافه</th>
              <th className="p-4 text-sm font-semibold">آمار و موجودی</th>
              <th className="p-4 text-sm font-semibold text-center">عملیات</th>
            </tr>
          </thead>

          <tbody className="divide-y divide-white/5">
            {loading ? (
              <tr>
                <td colSpan={6} className="p-10 text-center text-blue-300/70">
                  در حال بارگذاری...
                </td>
              </tr>
            ) : filteredLetters.length === 0 ? (
              <tr>
                <td colSpan={6} className="p-10 text-center text-blue-300/70">
                  موردی پیدا نشد
                </td>
              </tr>
            ) : (
              filteredLetters.map((letter) => (
                <tr key={letter._id} className="hover:bg-blue-900/30 transition">
                  <td className="p-4">
                    <div className="flex items-center gap-3">
                      <div className="w-12 h-12 rounded-lg bg-blue-800/40 border border-white/10 overflow-hidden">
                        {letter.images?.[0] ? (
                          <img
                            src={letter.images[0]}
                            className="w-full h-full object-cover"
                            alt={letter.title}
                          />
                        ) : (
                          <div className="w-full h-full flex items-center justify-center">
                            <Package className="text-blue-200 w-5" />
                          </div>
                        )}
                      </div>

                      <div>
                        <div className="font-bold text-blue-100">{letter.title}</div>
                        <div
                          className={`text-[10px] ${
                            letter.isActive ? "text-green-400" : "text-red-400"
                          }`}
                        >
                          {letter.isActive ? "● فعال" : "● غیرفعال"}
                        </div>
                      </div>
                    </div>
                  </td>

                  <td className="p-4 text-blue-300/90">{letter.category}</td>

                  <td className="p-4">
                    <div className="text-blue-300 font-bold">
                      {(letter.priceAfterDiscount ?? letter.price).toLocaleString()} تومان
                    </div>
                    {letter.discount ? (
                      <div className="text-xs text-blue-400/50 line-through">
                        {letter.price.toLocaleString()}
                      </div>
                    ) : null}
                  </td>

                  <td className="p-4 text-sm">
                    <div className="space-y-1 text-xs">
                      <div className="flex items-center gap-1 text-orange-300">
                        <Printer size={12} /> چاپ:{" "}
                        {letter.printingExtraPrice?.toLocaleString() ?? 0}
                      </div>
                      <div className="flex items-center gap-1 text-purple-300">
                        <PenTool size={12} /> خطاطی:{" "}
                        {letter.handwritingExtraPrice?.toLocaleString() ?? 0}
                      </div>
                    </div>
                  </td>

                  <td className="p-4 text-sm">
                    <div className="flex flex-col gap-1 text-[11px]">
                      <span
                        className={
                          letter.instock > 0 ? "text-green-300" : "text-red-400"
                        }
                      >
                        موجودی: {letter.instock}
                      </span>
                      <span className="flex items-center gap-1 text-blue-200/80">
                        <ShoppingBag size={11} /> {letter.purchaseCount ?? 0} خرید
                      </span>
                      <span className="flex items-center gap-1 text-blue-300/80">
                        <Eye size={11} /> {letter.visits ?? 0} بازدید
                      </span>
                    </div>
                  </td>

                  <td className="p-4 text-center">
                    <div className="flex justify-center gap-2">
                      <button
                        onClick={() => openEditModal(letter)}
                        className="p-2 text-blue-300 hover:bg-blue-800/40 rounded-lg"
                      >
                        <Edit size={18} />
                      </button>

                      <button
                        onClick={() => handleDelete(letter._id)}
                        className="p-2 text-red-400 hover:bg-red-900/30 rounded-lg"
                      >
                        <Trash2 size={18} />
                      </button>
                    </div>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      <ModalLetterForm
        isOpen={modalOpen}
        onClose={() => {
          setModalOpen(false);
          setEditingLetter(null);
        }}
        editData={editingLetter}
        onSave={handleSaveLetter}
      />
    </div>
  );
}
