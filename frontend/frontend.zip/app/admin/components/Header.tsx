"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation" // برای Next.js

export default function Header() {
  const [time, setTime] = useState(new Date())
  const router = useRouter()

  useEffect(() => {
    const timer = setInterval(() => setTime(new Date()), 1000)
    return () => clearInterval(timer)
  }, [])

  function handleLogout() {
    // پاک‌کردن توکن و ریدایرکت به صفحه اصلی
    router.push("/")
  }

  return (
    <header className="flex items-center justify-between h-16 px-6 bg-slate-900 text-white shadow-md select-none">
      
      {/* سمت چپ: عنوان */}
      <div className="text-lg font-semibold tracking-wide cursor-default">
        Admin Dashboard
      </div>

      {/* وسط: متن */}
      <div className="text-center flex-grow">
        <h1 className="text-white text-xl font-extrabold font-sans select-none drop-shadow-md">
          Let&apos;s go, nigge! 🚀
        </h1>
      </div>

      {/* سمت راست: ساعت و دکمه خروج */}
      <div className="flex items-center gap-6 min-w-[180px] justify-end font-mono text-sm tracking-wide">
        <div className="tabular-nums select-none">
          {time.toLocaleTimeString()}
        </div>
        <button
          onClick={handleLogout}
          type="button"
          aria-label="خروج"
          className="bg-red-600 hover:bg-red-700 px-4 py-2 rounded-md transition-shadow shadow-md"
        >
          خروج
        </button>
      </div>
    </header>
  )
}
