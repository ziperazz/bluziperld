// src/app/layout.tsx

import "./globals.css"
import localFont from "next/font/local"

import ConditionalNavbar from "@/components/ConditionalNavbar"
import SupportButton from "@/components/SupportButton"
import ConditionalFooter from "@/components/ConditionalFooter"

const estedad = localFont({
  src: [
    {
      path: "./fonts/estedad/Estedad-Light.woff2",
      weight: "300",
      style: "normal",
    },
    {
      path: "./fonts/estedad/Estedad-Regular.woff2",
      weight: "400",
      style: "normal",
    },
    {
      path: "./fonts/estedad/Estedad-Medium.woff2",
      weight: "500",
      style: "normal",
    },
    {
      path: "./fonts/estedad/Estedad-SemiBold.woff2",
      weight: "600",
      style: "normal",
    },
    {
      path: "./fonts/estedad/Estedad-Bold.woff2",
      weight: "700",
      style: "normal",
    },
    {
      path: "./fonts/estedad/Estedad-ExtraBold.woff2",
      weight: "800",
      style: "normal",
    },
    {
      path: "./fonts/estedad/Estedad-Black.woff2",
      weight: "900",
      style: "normal",
    },
  ],
  variable: "--font-estedad",
  display: "swap",
})

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="fa" dir="rtl">
      <body
        className={`${estedad.variable} min-h-screen bg-[#0d1117] text-white overflow-x-hidden`}
      >
        <ConditionalNavbar />
        {children}
        <ConditionalFooter />
        <SupportButton />
      </body>
    </html>
  )
}
