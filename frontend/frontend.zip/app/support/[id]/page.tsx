"use client"

import { use, useEffect, useRef, useState } from "react"
import { Send } from "lucide-react"

interface Message {
  _id: string
  senderRole: "USER" | "ADMIN"
  text: string
  createdAt: string
}

interface Ticket {
  _id: string
  subject: string
  status: string
  messages: Message[]
  createdAt: string
}

export default function SupportTicketPage(props: { params: Promise<{ id: string }> }) {
  const { id } = use(props.params)

  const [ticket, setTicket] = useState<Ticket | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [message, setMessage] = useState("")
  const [sending, setSending] = useState(false)
  const [adminOnline, setAdminOnline] = useState(false)

  const chatRef = useRef<HTMLDivElement>(null)
  const prevMessagesLengthRef = useRef(0)
  const shouldScrollToBottomRef = useRef(false)
  const isFirstLoadRef = useRef(true)

  const API = process.env.NEXT_PUBLIC_API_URL || "http://localhost:5000"

  // ✔ احراز هویت، فقط همین یک خط اصلاح شد
  const token = typeof window !== "undefined" ? localStorage.getItem("accessToken") : null

  // Auto scroll هوشمند
  useEffect(() => {
    if (!chatRef.current || !ticket) return

    const el = chatRef.current
    const currentLength = ticket.messages.length
    const prevLength = prevMessagesLengthRef.current

    if (isFirstLoadRef.current) {
      prevMessagesLengthRef.current = currentLength
      isFirstLoadRef.current = false
      return
    }

    if (currentLength > prevLength) {
      const distanceFromBottom = el.scrollHeight - el.scrollTop - el.clientHeight
      const isNearBottom = distanceFromBottom < 120

      if (shouldScrollToBottomRef.current || isNearBottom) {
        el.scrollTop = el.scrollHeight
      }
    }

    shouldScrollToBottomRef.current = false
    prevMessagesLengthRef.current = currentLength
  }, [ticket?.messages, ticket])

  // Load ticket
  useEffect(() => {
    if (!token) {
      setError("ابتدا وارد حساب کاربری شوید.")
      setLoading(false)
      return
    }

    const checkAdminHours = () => {
      const h = new Date().getHours()
      setAdminOnline(h >= 17 && h < 20)
    }

    async function load() {
      try {
        const res = await fetch(`${API}/api/tickets/${id}`, {
          headers: { Authorization: `Bearer ${token}` },
          credentials: "include",   // ✔ اضافه شد
        })

        const data = await res.json()

        if (data.success) {
          setTicket(data.ticket)
        } else {
          setError("تیکت یافت نشد.")
        }
      } catch {
        setError("خطا در ارتباط با سرور.")
      } finally {
        setLoading(false)
      }
    }

    checkAdminHours()
    load()
  }, [id, token, API])

  // Auto Refresh Messages (Polling)
  useEffect(() => {
    if (!token) return

    const interval = setInterval(async () => {
      try {
        const res = await fetch(`${API}/api/tickets/${id}`, {
          headers: { Authorization: `Bearer ${token}` },
          credentials: "include",    // ✔ اضافه شد
        })

        const data = await res.json()

        if (data.success) {
          setTicket(data.ticket)
        }
      } catch {}
    }, 3000)

    return () => clearInterval(interval)
  }, [id, token, API])

  // Send Message
  async function sendMessage() {
    if (!message.trim() || !token) return

    shouldScrollToBottomRef.current = true
    setSending(true)

    try {
      const res = await fetch(`${API}/api/tickets/${id}/messages`, {
        method: "POST",
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json",
        },
        credentials: "include",      // ✔ اضافه شد
        body: JSON.stringify({ text: message }),
      })

      const data = await res.json()

      if (data.success) {
        setTicket(data.ticket)
        setMessage("")
      }
    } finally {
      setSending(false)
    }
  }

  function handleKeyDown(e: React.KeyboardEvent<HTMLInputElement>) {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault()
      sendMessage()
    }
  }

  if (loading) {
    return <div className="text-gray-400 text-center p-10">در حال بارگذاری…</div>
  }

  if (error || !ticket) {
    return <div className="text-red-400 text-center p-10">{error}</div>
  }

  return (
    <div className="max-w-4xl mx-auto mt-8 space-y-5">

      {/* Header */}
      <div className="text-white text-xl font-bold px-2">
        پشتیبانی — {ticket.subject}
        {adminOnline && (
          <span className="text-green-400 text-sm mr-3">● پشتیبان آنلاین</span>
        )}
      </div>

      {/* Chat Box */}
      <div className="h-[75vh] bg-[#020617] border border-white/10 rounded-2xl flex flex-col shadow-xl">

        {/* Messages */}
        <div ref={chatRef} className="chat-scroll flex-1 overflow-y-auto p-4 space-y-4">
          {ticket.messages.map((msg) => (
            <div
              key={msg._id}
              className={`flex ${msg.senderRole === "USER" ? "justify-end" : "justify-start"}`}
            >
              <div
                className={`max-w-[75%] px-4 py-2 rounded-2xl text-sm ${
                  msg.senderRole === "USER"
                    ? "bg-blue-600 text-white"
                    : "bg-white/10 text-gray-200"
                }`}
              >
                {msg.text}
                <div className="text-[10px] text-gray-400 mt-1">
                  {new Date(msg.createdAt).toLocaleTimeString("fa-IR")}
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Input */}
        {ticket.status !== "CLOSED" && (
          <div className="border-t border-white/10 p-3 flex gap-2">
            <input
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              onKeyDown={handleKeyDown}
              placeholder="پیام خود را بنویسید..."
              className="flex-1 bg-white/5 border border-white/10 rounded-xl px-3 py-2 text-white text-sm outline-none"
            />

            <button
              onClick={sendMessage}
              disabled={sending}
              className="bg-blue-600 hover:bg-blue-500 transition rounded-xl px-4 text-white flex items-center disabled:opacity-60"
            >
              <Send size={16} />
            </button>
          </div>
        )}
      </div>

    </div>
  )
}
