"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { ArrowRight, Loader2 } from "lucide-react"

export default function NewTicketPage() {
  const router = useRouter()

  const [subject, setSubject] = useState("")
  const [priority, setPriority] = useState("MEDIUM")
  const [message, setMessage] = useState("")
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState("")

  const API = process.env.NEXT_PUBLIC_API_URL || "http://localhost:5000"

  async function handleSubmit(e: any) {
    e.preventDefault()

    if (!subject || !message) return

    try {
      setLoading(true)
      setError("")

      // ✔ فقط همین یک خط اصلاح شد
      const token = localStorage.getItem("accessToken")

      const res = await fetch(`${API}/api/tickets`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        credentials: "include", // ✔ اضافه شد
        body: JSON.stringify({ subject, priority, message }),
      })

      const data = await res.json()
      if (!res.ok || !data.success) {
        throw new Error(data.message || "خطا در ایجاد تیکت")
      }

      router.push("/support")
    } catch (err: any) {
      setError(err.message || "مشکلی پیش آمده")
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="w-full flex justify-center px-4 py-10">
      <div className="w-full max-w-2xl bg-[#0f172a] border border-white/10 rounded-2xl p-6 sm:p-8 shadow-xl">

        <h1 className="text-2xl font-bold text-white mb-2 text-right">
          ایجاد تیکت جدید
        </h1>
        <p className="text-xs text-gray-400 text-right mb-8 leading-relaxed">
          لطفاً موضوع و توضیحات کامل را وارد کنید تا سریع‌تر رسیدگی شود.
        </p>

        <form onSubmit={handleSubmit} className="space-y-7">

          {/* SUBJECT */}
          <div className="space-y-2 text-right">
            <label className="text-xs text-gray-300">موضوع تیکت</label>
            <input
              value={subject}
              onChange={(e) => setSubject(e.target.value)}
              className="w-full bg-white/5 border border-white/10 text-white text-sm px-4 py-3 rounded-lg outline-none focus:border-blue-500/60 transition"
              placeholder="مثال: مشکل در پرداخت سفارش"
            />
          </div>

          {/* PRIORITY */}
          <div className="space-y-3 text-right">
            <label className="text-xs text-gray-300">میزان اهمیت</label>

            <div className="grid grid-cols-3 gap-3">

              <PriorityButton
                label="کم"
                value="LOW"
                active={priority === "LOW"}
                color="emerald"
                onClick={() => setPriority("LOW")}
              />

              <PriorityButton
                label="متوسط"
                value="MEDIUM"
                active={priority === "MEDIUM"}
                color="amber"
                onClick={() => setPriority("MEDIUM")}
              />

              <PriorityButton
                label="زیاد"
                value="HIGH"
                active={priority === "HIGH"}
                color="red"
                onClick={() => setPriority("HIGH")}
              />

            </div>
          </div>

          {/* MESSAGE */}
          <div className="space-y-2 text-right">
            <label className="text-xs text-gray-300">توضیحات کامل</label>
            <textarea
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              className="w-full bg-white/5 border border-white/10 text-white text-sm px-4 py-3 rounded-lg outline-none min-h-[140px] focus:border-blue-500/60 transition"
              placeholder="توضیحات خود را با جزئیات کامل وارد کنید..."
            />
          </div>

          {/* ERROR */}
          {error && (
            <p className="text-xs text-red-400 bg-red-500/20 border border-red-500/40 p-3 rounded-lg">
              {error}
            </p>
          )}

          {/* BUTTON */}
          <button
            disabled={loading || !subject || !message}
            className="w-full bg-blue-600 hover:bg-blue-500 disabled:bg-blue-800/40 disabled:cursor-not-allowed
             text-sm text-white py-3 rounded-lg flex items-center justify-center gap-2 transition"
          >
            {loading ? (
              <>
                <Loader2 className="animate-spin" size={16} /> در حال ارسال...
              </>
            ) : (
              <>
                ارسال تیکت
                <ArrowRight size={16} />
              </>
            )}
          </button>

        </form>

      </div>
    </div>
  )
}

function PriorityButton({ label, value, active, color, onClick }: any) {
  const colorMap = {
    emerald: "border-emerald-500/40 bg-emerald-500/10 text-emerald-200",
    amber: "border-amber-500/40 bg-amber-500/10 text-amber-200",
    red: "border-red-500/40 bg-red-500/10 text-red-200",
  }

  return (
    <button
      type="button"
      onClick={onClick}
      className={`rounded-lg px-3 py-3 border text-xs transition
      ${active
        ? colorMap[color]
        : "border-white/10 bg-white/5 text-gray-300 hover:border-white/30"}
      `}
    >
      {label}
    </button>
  )
}
