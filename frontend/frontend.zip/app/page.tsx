"use client";

import { useState, useEffect, useRef } from "react";
import Image from "next/image";
import Link from "next/link";
import {
  PenTool,
  ShoppingCart,
  ChevronLeft,
  ChevronRight,
  Sparkles,
  Send,
  Heart,
  Quote,
} from "lucide-react";
import UserReviews from "@/components/UserReviews";
import { motion } from "framer-motion";
import ProductCard from "@/components/ProductCard";


const containerVariants = {
  hidden: { opacity: 0 },
  show: {
    opacity: 1,
    transition: { staggerChildren: 0.15 },
  },
};

const itemVariants = {
  hidden: { opacity: 0, y: 30 },
  show: { opacity: 1, y: 0, transition: { duration: 0.7, ease: "easeOut" } },
};

const API = process.env.NEXT_PUBLIC_API_URL || "http://localhost:5000";

export default function Home() {
  const [letters, setLetters] = useState([]);
  const [products, setProducts] = useState([]);
  const [loadingLetters, setLoadingLetters] = useState(true);
  const [loadingProducts, setLoadingProducts] = useState(true);

useEffect(() => {

  const loadData = async () => {
    try {
      const resLetters = await fetch(`${API}/api/letters`);
      if (!resLetters.ok) throw new Error("letters fetch failed");

      const lettersData = await resLetters.json();
      setLetters(lettersData);

    } catch (err) {
      console.error("letters error", err);
    } finally {
      setLoadingLetters(false);
    }

    try {
      const resProducts = await fetch(`${API}/api/products?sort=popular`);
      if (!resProducts.ok) throw new Error("products fetch failed");

      const productsData = await resProducts.json();
      setProducts(productsData);

    } catch (err) {
      console.error("products error", err);
    } finally {
      setLoadingProducts(false);
    }
  };

  loadData();

}, []);

  return (
    <main className="relative text-[#c7d5e0] min-h-screen overflow-hidden select-none">
      {/* پارتیکل‌های پس‌زمینه */}
      <div className="absolute top-[-5%] right-[-10%] w-[400px] h-[400px] bg-[#66c0f4]/15 rounded-full blur-[100px] -z-10" />
      <div className="absolute bottom-[20%] left-[-5%] w-[350px] h-[350px] bg-[#c186ff]/10 rounded-full blur-[100px] -z-10" />

      <div className="max-w-6xl mx-auto px-5 sm:px-8">
        
        {/* HERO SECTION */}
        <section className="py-16 sm:py-24 grid md:grid-cols-2 gap-12 items-center">
          {/* IMAGE */}
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 1 }}
            className="flex justify-center order-1 md:order-2"
          >
            <div className="relative w-[260px] sm:w-[340px] rounded-3xl overflow-hidden border border-white/10 bg-[#0d1117]/80 shadow-[0_0_50px_rgba(102,192,244,0.15)] group">
              {/*<div className="absolute -inset-1 bg-gradient-to-tr from-[#66c0f4] to-[#c186ff] rounded-3xl blur opacity-20 group-hover:opacity-40 transition duration-1000" /> */}
              <Image
                src="/hero-image-v2.png"
                alt="هنر نوشتن"
                width={800}
                height={800}
                className="w-full h-auto object-cover rounded-3xl transform transition duration-1000 group-hover:scale-110"
                priority
              />
            </div>
          </motion.div>

          {/* TEXT */}
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            className="text-center md:text-right flex flex-col gap-6 order-2 md:order-1"
          >
            <div className="inline-flex items-center gap-2 bg-[#66c0f4]/10 border border-[#66c0f4]/20 px-4 py-1.5 rounded-full text-xs sm:text-sm font-medium text-[#66c0f4] w-fit mx-auto md:mx-0">
              <Sparkles size={14} /> پلتفرم تخصصی نامه‌های دست‌نویس
            </div>

            <h1 className="text-3xl sm:text-5xl font-black text-white leading-[1.2]">
              لمس واقعی کلمات <br /> روی{" "}
              <span className="text-transparent bg-clip-text bg-gradient-to-l from-[#66c0f4] via-[#85d1ff] to-[#a4e1ff]">
                کاغذ ماندگار
              </span>
            </h1>

            <p className="text-base sm:text-lg text-[#b6c6d8] max-w-md mx-auto md:mx-0 leading-relaxed font-light">
              نامه‌ای بنویس که سال‌ها ورق بخورد؛ ما با خطی خوش و بسته‌بندی هنرمندانه، احساس شما را ارسال می‌کنیم.
            </p>

            <div className="flex flex-col sm:flex-row items-center gap-4 pt-4 justify-center md:justify-start">
              <Link
                href="/letters"
                className="group relative bg-[#66c0f4] text-[#0b141c] px-8 py-3.5 rounded-2xl font-bold text-base overflow-hidden transition-all hover:shadow-[0_0_25px_rgba(102,192,244,0.4)] hover:scale-105 w-full sm:w-auto text-center"
              >
                <span className="relative z-10 flex items-center justify-center gap-2">
                  شروع نوشتن نامه <Send size={18} />
                </span>
                <div className="absolute inset-0 bg-gradient-to-r from-white/0 via-white/30 to-white/0 -translate-x-full group-hover:translate-x-full transition-transform duration-1000" />
              </Link>

              <Link
                href="/products"
                className="text-sm sm:text-base text-white hover:text-[#66c0f4] px-6 py-3 transition-colors font-semibold border border-white/5 hover:border-[#66c0f4]/30 rounded-2xl"
              >
                مشاهده محصولات
              </Link>
            </div>
          </motion.div>
        </section>

        {/* WHY US / FEATURES */}
        <section className="py-20">
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-12"
          >
            <h2 className="text-2xl sm:text-3xl font-bold text-white mb-3">چرا بلو زیپر ؟</h2>
            <div className="h-1.5 w-12 bg-gradient-to-r from-[#66c0f4] to-[#c186ff] mx-auto rounded-full"></div>
          </motion.div>

<motion.div
  variants={containerVariants}
  initial="hidden"
  whileInView="show"
  viewport={{ once: true }}
  className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-5 lg:gap-6"
>
              <FeatureCard
    icon={<PenTool size={26} />}
    title="هنر خوش‌نویسی"
    description="هر نامه با دقت و علاقه توسط خطاطان ما نوشته میشود  برای شما"
  />
  <FeatureCard
    icon={<Heart size={26} />}
    title="بسته‌بندی نوستالژیک"
    description="استفاده از لاک و مهر و پاکت‌های خاص برای خلق حس ماندگار."
  />
  <FeatureCard
    icon={<ShoppingCart size={26} />}
    title="ارسال محرمانه"
    description="ارسال امن و کاملاً محرمانه به سراسر کشور."
  />
          </motion.div>
        </section>

        {/* SLIDERS */}
        <div className="space-y-28 sm:space-y-40 pb-20 sm:pb-32">
          <SectionRandomSlider
            title="پرطرفدارترین پاکت‌ها"
            loading={loadingLetters}
            data={letters}
            mode="letters"
          />

          <SectionRandomSlider
            title="محصولات شاهکار ما"
            loading={loadingProducts}
            data={products}
            mode="products"
          />
        </div>

        {/* REVIEWS - ENHANCED */}
        <section className="pb-24 sm:pb-32">
          <div className="relative p-8 sm:p-12 rounded-[2.5rem] bg-white/[0.02] border border-white/5 overflow-hidden">
            {/* نور پس‌زمینه نظرات */}
            <div className="absolute -top-24 -right-24 w-64 h-64 bg-[#66c0f4]/10 rounded-full blur-[80px]" />
            
            
            
            <div className="relative z-10">
              <UserReviews />
            </div>
          </div>
        </section>

      </div>
    </main>
  );
}

function FeatureCard({ icon, title, description }) {
  return (
    <motion.div
      variants={itemVariants}
      whileHover={{ y: -6 }}
      className="
        relative
        p-5 sm:p-6
        rounded-2xl
        bg-gradient-to-b
        from-white/[0.04]
        to-transparent
        border border-white/10
        hover:border-[#66c0f4]/40
        transition-all duration-300
        group
        overflow-hidden
      "
    >
      {/* glow */}
      <div className="absolute inset-0 opacity-0 group-hover:opacity-100 transition duration-500 bg-[radial-gradient(circle_at_top_right,rgba(102,192,244,0.10),transparent_45%)]" />

      <div className="
        mb-4
        inline-flex
        p-3
        rounded-xl
        bg-[#1b2838]
        text-[#66c0f4]
        group-hover:bg-[#66c0f4]
        group-hover:text-[#0d1117]
        transition-all duration-300
      ">
        {icon}
      </div>

      <h3 className="text-lg sm:text-xl font-bold text-white mb-2">
        {title}
      </h3>

      <p className="
        text-[#8f98a0]
        text-sm
        leading-7
        font-light
      ">
        {description}
      </p>
    </motion.div>
  );
}


function SectionRandomSlider({ title, loading, data, mode }) {
  const sliderRef = useRef(null);
  const [selectedItems, setSelectedItems] = useState([]);

  useEffect(() => {
    if (data?.length) {
      const shuffled = [...data].sort(() => 0.5 - Math.random());
      setSelectedItems(shuffled.slice(0, 8));
    }
  }, [data]);

  const scroll = (dir) => {
    if (!sliderRef.current) return;
    sliderRef.current.scrollBy({
      left: dir === "left" ? -280 : 280,
      behavior: "smooth",
    });
  };

  return (
    <section className="relative group/slider">
      <div className="flex justify-between items-end mb-10 px-2">
        <div className="relative">
          <h2 className="text-xl sm:text-3xl font-extrabold text-white mb-2 italic">
            {title}
          </h2>
          <div className="h-1 w-14 bg-[#66c0f4] rounded-full"></div>
        </div>
        <div className="flex gap-3">
          <button
            onClick={() => scroll("left")}
            className="p-3 rounded-xl bg-white/5 border border-white/10 hover:bg-[#66c0f4] hover:text-[#0d1117] transition-all"
          >
            <ChevronLeft size={20} />
          </button>
          <button
            onClick={() => scroll("right")}
            className="p-3 rounded-xl bg-white/5 border border-white/10 hover:bg-[#66c0f4] hover:text-[#0d1117] transition-all"
          >
            <ChevronRight size={20} />
          </button>
        </div>
      </div>

      {loading ? (
        <div className="flex gap-6 overflow-hidden py-4">
          {[...Array(4)].map((_, i) => (
            <div
              key={i}
              className="min-w-[260px] h-72 bg-white/5 animate-pulse rounded-3xl"
            />
          ))}
        </div>
      ) : (
        <div
          ref={sliderRef}
          className="flex gap-6 overflow-x-auto py-4 px-2 scroll-smooth snap-x snap-mandatory no-scrollbar"
        >
          {selectedItems.map((item) => (
            <motion.div
              key={item._id || item.id}
              whileHover={{ y: -5 }}
              className="flex-shrink-0 w-[240px] sm:w-[280px] snap-start"
            >
              <ProductCard product={item} mode={mode} />
            </motion.div>
          ))}
        </div>
      )}
    </section>
  );
}
