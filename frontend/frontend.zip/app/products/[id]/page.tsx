"use client"

import React, { useEffect, useState } from "react"
import { useParams } from "next/navigation"
import CommentsSection from "@/components/CommentsSection"

type Product = {
  _id: string
  slug?: string
  title: string
  price: number
  discount?: number
  priceAfterDiscount?: number
  instock?: number
  images?: string[]
  image?: string
  description?: string
  specs?: { label: string; value: string }[]
  purchaseCount?: number
  visits?: number
}

export default function ProductPage() {
  const params = useParams()
  const slug = params?.id as string | undefined // بر اساس مسیر [slug] خواهیم بود
  
  const [product, setProduct] = useState<Product | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(false)
  const [activeImage, setActiveImage] = useState(0)
  const [addLoading, setAddLoading] = useState(false)
  const [showToast, setShowToast] = useState(false)
  const [token, setToken] = useState<string | undefined>(undefined)

  const apiBase =
    process.env.NEXT_PUBLIC_API_URL?.replace(/\/+$/, "") ||
    "http://localhost:5000"

  // تابع ساخت URL تصویر به شکل کامل
  const buildImageUrl = (img?: string) => {
    if (!img) return "/placeholder.png"

    if (/^https?:\/\//i.test(img)) return img

    return img.startsWith("/uploads")
      ? `${apiBase}${img}`
      : `${apiBase}/uploads/${img.replace(/^\/+/, "")}`
  }

  useEffect(() => {
    if (!slug) return

    const fetchProduct = async () => {
      try {
        // استفاده از slug به جای id در API
        const res = await fetch(`${apiBase}/api/products/${slug}`)
        if (!res.ok) throw new Error()
        const data = await res.json()
        data.specs = Array.isArray(data.specs) ? data.specs : []
        setProduct(data)
      } catch {
        setError(true)
      } finally {
        setLoading(false)
      }
    }

    fetchProduct()
  }, [slug, apiBase])

  useEffect(() => {
    if (typeof window !== "undefined") {
      const storedToken = localStorage.getItem("accessToken")
      if (storedToken) setToken(storedToken)
    }
  }, [])

  const finalPrice =
    product?.discount && product.discount > 0
      ? product.priceAfterDiscount ??
        product.price * (1 - product.discount / 100)
      : product?.price || 0

  const addToCart = () => {
    if (!product) return
    if (addLoading || product.instock === 0) return

    setAddLoading(true)

    try {
      const cart =
        typeof window !== "undefined"
          ? JSON.parse(localStorage.getItem("cart") || "[]")
          : []

      const newItem = {
        productId: product._id, // همیشه ID پایدار برای خرید
        productType: "product",
        title: product.title,
        price: finalPrice,
        image: buildImageUrl(product.images?.[0] || product.image),
        quantity: 1,
      }

      const existing = cart.find((i: any) => i.productId === product._id)

      if (existing) existing.quantity++
      else cart.push(newItem)

      localStorage.setItem("cart", JSON.stringify(cart))

      window.dispatchEvent(new Event("cart-updated"))

      setShowToast(true)
      setTimeout(() => setShowToast(false), 2500)
    } catch (e) {
      console.error("cart error", e)
    }

    setAddLoading(false)
  }

  if (loading)
    return (
      <div className="text-center text-gray-400 mt-10">
        در حال دریافت اطلاعات...
      </div>
    )

  if (error || !product)
    return (
      <div className="text-center text-red-400 mt-10">
        خطا در دریافت محصول
      </div>
    )

  return (
    <div className="min-h-screen text-slate-100 px-4 md:px-6 py-6 md:py-10">

      <div className="max-w-6xl mx-auto space-y-16">
        <div className="grid md:grid-cols-2 gap-10">
          <div className="space-y-3">
            <div className="relative aspect-[5/3] rounded-2xl overflow-hidden bg-[#0f172a] border border-[#1f2a44]">
              <img
                src={buildImageUrl(product.images?.[activeImage] || product.image)}
                alt={product.title} // Alt برای سئو
                className="w-full h-full object-cover"
                onError={(e) => {
                  ;(e.currentTarget as HTMLImageElement).src = "/placeholder.png"
                }}
              />
              {product.discount && product.discount > 0 && (
                <div className="absolute top-3 left-3 bg-red-500/90 text-white px-3 py-1 rounded-xl text-xs font-semibold animate-pulse">
                  %{product.discount} تخفیف
                </div>
              )}
            </div>

            {product.images?.length && product.images.length > 1 && (
              <div className="grid grid-cols-4 gap-2">
                {product.images.map((img, i) => (
                  <button
                    key={i}
                    onClick={() => setActiveImage(i)}
                    className={`
                      aspect-square rounded-lg overflow-hidden border transition
                      ${
                        activeImage === i
                          ? "border-blue-500 scale-105"
                          : "border-[#1f2a44] hover:border-blue-400"
                      }
                    `}
                    style={{ maxHeight: "70px" }}
                  >
                    <img
                      src={buildImageUrl(img)}
                      className="w-full h-full object-cover"
                      onError={(e) => {
                        ;(e.currentTarget as HTMLImageElement).src = "/placeholder.png"
                      }}
                    />
                  </button>
                ))}
              </div>
            )}
          </div>

          <div className="space-y-6">
            <div>
              <h1 className="text-2xl md:text-3xl font-semibold">{product.title}</h1>

              <p className="text-slate-400 text-sm mt-2 leading-relaxed">
                {product.description || "توضیحاتی برای این محصول ثبت نشده است."}
              </p>

              <div className="mt-4 text-sm">
                {product.instock && product.instock > 0 ? (
                  <span className="text-green-400">موجودی: {product.instock} عدد</span>
                ) : (
                  <span className="text-red-400">❌ ناموجود در انبار</span>
                )}
              </div>

              <div className="mt-4 space-y-2">
                <div className="text-xl font-semibold">
                  {finalPrice.toLocaleString()}
                  <span className="text-sm text-slate-400 mr-2">تومان</span>
                </div>

                {product.discount && product.discount > 0 && (
                  <div className="text-slate-500 text-sm line-through">
                    {product.price.toLocaleString()} تومان
                  </div>
                )}
              </div>
            </div>

            <div className="bg-[#0f172a]/60 border border-[#1e293b] rounded-2xl p-4">
              <h3 className="text-sm font-semibold mb-2 text-slate-300">مشخصات محصول</h3>

              <ul className="space-y-1 text-sm text-slate-400">
                {product.specs && product.specs.length > 0 ? (
                  product.specs.map((item, idx) => (
                    <li key={idx} className="flex justify-between">
                      <span>{item.label}</span>
                      <span className="text-slate-300">{item.value}</span>
                    </li>
                  ))
                ) : (
                  <li className="text-slate-500 text-xs">مشخصاتی ثبت نشده است</li>
                )}
              </ul>
            </div>

            <button
              onClick={addToCart}
              disabled={addLoading || product.instock === 0}
              className={`w-full py-3 rounded-2xl transition-all ${
                product.instock === 0
                  ? "bg-gray-700 cursor-not-allowed opacity-50"
                  : "bg-blue-600 hover:bg-blue-700"
              }`}
            >
              {product.instock === 0
                ? "ناموجود"
                : addLoading
                ? "در حال افزودن..."
                : "افزودن به سبد خرید"}
            </button>
          </div>
        </div>

        {/* فاصله 96px (mt-24) باکس دور کامنت‌ها */}
        <div className="mt-64">
          <CommentsSection
            productId={product._id}
            token={token}
            targetType="product"
          />
        </div>
      </div>

      <div
        className={`fixed top-6 right-6 z-50 transition-all duration-500 ${
          showToast ? "opacity-100 translate-y-0" : "opacity-0 -translate-y-4 pointer-events-none"
        }`}
      >
        <div className="bg-[#0f172a]/95 backdrop-blur-md border border-[#1e293b] text-slate-200 px-5 py-3 rounded-xl shadow-xl text-sm">
          ✔ به سبد خرید اضافه شد
        </div>
      </div>
    </div>
  )
}
