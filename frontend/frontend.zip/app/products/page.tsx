"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import ProductCard from "@/components/ProductCard";
import Filters from "@/components/Filters";
import SkeletonCard from "@/components/SkeletonCard";
import { SlidersHorizontal } from "lucide-react";

type Product = {
  _id: string;
  title: string;
  desc?: string;
  instock: number;
  price: number;
  discount?: number;
  category?: string;
  image?: string;
  createdAt?: string | number;
  purchaseCount?: number;
  visits?: number;
};

export default function ProductsPage() {
  const router = useRouter();
  const search = useSearchParams();

  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);

  const [category, setCategory] = useState(search.get("category") || "");
  const [price, setPrice] = useState(Number(search.get("price") || 2000000));
  const [onlyAvailable, setOnlyAvailable] = useState(search.get("available") === "true");
  const [onlyDiscounted, setOnlyDiscounted] = useState(search.get("discounted") === "true");
  const [sort, setSort] = useState(search.get("sort") || "new");

  const [filterOpen, setFilterOpen] = useState(false);

  // =======================
  // Fetch Products from API with filters
  // =======================
  useEffect(() => {
    const fetchProducts = async () => {
      try {
        const query = new URLSearchParams();

        if (category) query.set("category", category);
        if (price < 2000000) query.set("price", String(price));
        if (onlyAvailable) query.set("onlyAvailable", "true");
        if (onlyDiscounted) query.set("onlyDiscounted", "true");
        if (sort !== "new") query.set("sort", sort);

        // ✅ تغییر اضافه‌شده: آدرس پایه API
        const apiBase = process.env.NEXT_PUBLIC_API_URL || "http://localhost:5000";

        const res = await fetch(`${apiBase}/api/products?${query.toString()}`);
        const data = await res.json();
        setProducts(data);
      } catch (error) {
        console.error("Fetch Error:", error);
      } finally {
        setLoading(false);
      }
    };

    fetchProducts();
  }, [category, price, onlyAvailable, onlyDiscounted, sort]);

  // =======================
  // Sync URL
  // =======================
  useEffect(() => {
    const params = new URLSearchParams();

    if (category) params.set("category", category);
    if (price < 2000000) params.set("price", String(price));
    if (sort !== "new") params.set("sort", sort);
    if (onlyAvailable) params.set("available", "true");
    if (onlyDiscounted) params.set("discounted", "true");

    router.replace(params.toString() ? `/products?${params}` : "/products", { scroll: false });
  }, [category, price, sort, onlyAvailable, onlyDiscounted]);

  // =======================
  // Infinite Scroll Logic
  // =======================
  const [visibleCount, setVisibleCount] = useState(12);
  const loaderRef = useRef<HTMLDivElement | null>(null);
  const [isLoadingMore, setIsLoadingMore] = useState(false);

  useEffect(() => {
    setVisibleCount(12);
  }, [products]);

  useEffect(() => {
    if (!loaderRef.current) return;

    const observer = new IntersectionObserver((entries) => {
      if (
        entries[0].isIntersecting &&
        !isLoadingMore &&
        visibleCount < products.length
      ) {
        setIsLoadingMore(true);
        setTimeout(() => {
          setVisibleCount((v) => v + 12);
          setIsLoadingMore(false);
        }, 600);
      }
    });

    observer.observe(loaderRef.current);
    return () => observer.disconnect();
  }, [products.length, visibleCount, isLoadingMore]);

  const visibleProducts = products.slice(0, visibleCount);

  // =======================
  // Loading State
  // =======================
  if (loading) {
    return (
      <div className="grid grid-cols-2 md:grid-cols-4 gap-6 p-8">
        {Array.from({ length: 8 }).map((_, i) => (
          <SkeletonCard key={i} />
        ))}
      </div>
    );
  }

  // =======================
  // Render
  // =======================
  return (
    <div className="min-h-screen px-4 md:px-8 py-10">
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="text-2xl font-bold mb-1">فروشگاه</h1>
          <p className="text-xs text-gray-400">{products.length} محصول یافت شد</p>
        </div>

        <button
          onClick={() => setFilterOpen(true)}
          className="
            lg:hidden flex items-center gap-2
            bg-[#0a0f1e]
            text-white/90
            border border-white/10
            px-4 py-2
            rounded-xl
            shadow-lg
            shadow-blue-500/10
          "
        >
          <SlidersHorizontal size={18} strokeWidth={1.5} />
          <span className="text-sm">فیلتر</span>
        </button>
      </div>

      <div className="lg:sticky lg:top-4 lg:z-40 mb-10">
        <Filters
          price={price}
          setPrice={setPrice}
          onlyAvailable={onlyAvailable}
          setOnlyAvailable={setOnlyAvailable}
          onlyDiscounted={onlyDiscounted}
          setOnlyDiscounted={setOnlyDiscounted}
          sort={sort}
          setSort={setSort}
          filterOpen={filterOpen}
          setFilterOpen={setFilterOpen}
        />
      </div>

      {products.length > 0 ? (
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 md:gap-8">
          {visibleProducts.map((p) => (
            <ProductCard key={p._id} product={p} />
          ))}

          {isLoadingMore &&
            Array.from({ length: 4 }).map((_, i) => <SkeletonCard key={i} />)}
        </div>
      ) : (
        <div className="py-20 text-center text-gray-300">
          <h3 className="text-lg font-medium">محصولی پیدا نشد!</h3>
          <p className="text-sm text-gray-500 mt-2">فیلترها را تغییر دهید.</p>
        </div>
      )}

      {visibleCount < products.length && (
        <div ref={loaderRef} className="h-20 flex items-center justify-center">
          <div className="w-6 h-6 border-2 border-blue-500 border-t-transparent rounded-full animate-spin"></div>
        </div>
      )}
    </div>
  );
}
