"use client";

import Link from "next/link";
import { motion, useScroll, useTransform } from "framer-motion";
import {
  IoMailOutline,
  IoHeartOutline,
  IoCubeOutline,
  IoRocketOutline,
} from "react-icons/io5";
import React, { useRef, useCallback } from "react";
import Image from "next/image";


const enterAnimation = {
  hidden: { opacity: 0, y: 30 },
  visible: (custom: number) => ({
    opacity: 1,
    y: 0,
    transition: { delay: custom * 0.15, duration: 0.6, ease: "easeOut" },
  }),
};

export default function AboutUsPage() {
  const { scrollYProgress } = useScroll();
  const heroOpacity = useTransform(scrollYProgress, [0, 0.15], [1, 0.4]);
  const heroScale = useTransform(scrollYProgress, [0, 1], [1, 1.02]);

  const footerRef = useRef<HTMLElement | null>(null);

  const scrollToFooter = useCallback(() => {
    footerRef.current?.scrollIntoView({ behavior: "smooth", block: "start" });
  }, []);

  const values = [
    {
      icon: <IoMailOutline className="text-blue-500" size={36} />,
      title: "نامه‌هایی که حرف دل رو می‌زنن",
      desc: "هر نامه‌ای که از دست ما درمیاد، انگار با دقت خودت نوشتی؛ اما با قلمی بهتر و احساس بیشتر.",
    },
    {
      icon: <IoHeartOutline className="text-pink-500" size={36} />,
      title: "حفظ روح اصلی پیامت",
      desc: "چیزی مثل همون حس که می‌خوای منتقل کنی، نه رسمی و خشک، نه زیادی لوس. یه جور حس خوب بین این دو.",
    },
    {
      icon: <IoCubeOutline className="text-purple-500" size={36} />,
      title: "ارسال به هر جا که بخوای",
      desc: "پاکت رو انتخاب می‌کنی، متن رو می‌نویسی، ما چاپ می‌کنیم و می‌فرستیم به هر آدرسی که تو بگی.",
    },
    {
      icon: <IoRocketOutline className="text-teal-500" size={36} />,
      title: "کار راحت و بی‌دردسر",
      desc: "تو فقط تصمیم می‌گیری، ما باقی کارها رو می‌خونیم و با سرعت و دقت انجام می‌دیم.",
    },
  ];

  const faqs = [
    {
      q: "داستان ما از کجا شروع شد؟",
      a: "دیدیم همه‌چیز شده پیام فوری و ایمیل، اما خب هنوز خیلیا دنبال حس واقعی یه نامه تو دست گرفتن هستن. ما اومدیم این حس رو دوباره زنده کنیم، البته با رنگ و روی مدرن.",
    },
    {
      q: "واقعا خودتون نامه‌ها رو می‌فرستید؟",
      a: "آره، از اول تا آخر. وقتی پاکت رو انتخاب کردی و متن رو نوشتی، ما اون رو چاپ می‌کنیم، میذاریم داخل پاکت، و مستقیم می‌فرستیم به آدرست.",
    },
    {
      q: "متن‌ها چطور نوشته می‌شن؟",
      a: "کاملاً شخصی و طبیعی. دوست نداریم نامه‌هات شبیه متن‌های آماده و پیش‌فرض باشن. هر کدوم مخصوص تو و لحن خودته.",
    },
    {
      q: "اگه اشتباه نوشتیم چی؟",
      a: "نگران نباش! میتونی سریع به پشتیبانی بگی تا اگر نامه ات نوشته نشده سریع متنی که میخوایی رو تغییر یا درستش کنی . اینجا همیشه حق با توعه.",
    },
  ];

  return (
    <div className="min-h-screen px-4 md:px-8 lg:px-12 text-slate-900 dark:text-slate-100">
<motion.section
  style={{ opacity: heroOpacity, scale: heroScale }}
  className="max-w-6xl mx-auto pt-20 md:pt-28 pb-16 px-6 md:px-0"
>
  <div className="grid grid-cols-1 lg:grid-cols-2 gap-x-20 gap-y-12 items-center">
    
    {/* متن سمت راست */}
    <motion.div
      className="text-right"
      variants={enterAnimation}
      initial="hidden"
      whileInView="visible"
      viewport={{ once: true }}
      custom={0}
    >
      <motion.h1
        initial={{ opacity: 0, y: 24 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.7 }}
        className="text-4xl sm:text-5xl lg:text-6xl font-extrabold leading-tight tracking-tight"
      >
        درباره ما
        <span className="block mt-3 text-transparent bg-clip-text bg-gradient-to-r from-blue-600 via-blue-500 to-blue-400 font-black">
          BluZiperld
        </span>
      </motion.h1>

      <p className="mt-7 max-w-xl text-base sm:text-lg leading-relaxed text-slate-700 dark:text-slate-300">
        اینجا محیطیست برای آدمایی که می‌خوان حرف دلشون رو به سبک کلاسیک و با طعم نوآوری بفرستن.  
        تو فقط پاکت و متن رو انتخاب کن، بقیه رو همه‌چیز را به ما بسپار.
      </p>
      
    </motion.div>

    {/* آیکون بزرگ سمت چپ */}
    <motion.div
      className="flex justify-center order-1 md:order-2"
      variants={enterAnimation}
      initial="hidden"
      whileInView="visible"
      viewport={{ once: true }}
      custom={1}
    >
      <div className="relative w-[350px] sm:w-[440px] rounded-3xl overflow-hidden border border-white/10 bg-[#0d1117]/80 shadow-[0_0_50px_rgba(102,192,244,0.15)] group">
        {/* گرادیان پشت تصویر در صورت نیاز فعال شود */}
        {/* <div className="absolute -inset-1 bg-gradient-to-tr from-[#66c0f4] to-[#c186ff] rounded-3xl blur opacity-20 group-hover:opacity-40 transition duration-1000" /> */}
        <img
          src="/images/bluziperld-mailbox.png"
          alt="BluZiperld mailbox image"
          className="w-full h-auto object-cover rounded-3xl transform transition duration-1000 group-hover:scale-110"
          loading="lazy"
        />
      </div>
    </motion.div>
  </div>
</motion.section>


      {/* ارزش‌ها */}
      <div className="max-w-6xl mx-auto px-2 sm:px-6 md:px-0 py-16">
        <motion.div
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
          variants={{
            visible: {
              transition: { staggerChildren: 0.18, delayChildren: 0.3 },
            },
          }}
          className="text-center"
        >
          <motion.h2
            variants={enterAnimation}
            custom={0}
            className="text-3xl sm:text-4xl font-bold"
          >
            ارزش هایی  که باعث میشن عاشق کارمون باشی
          </motion.h2>

          <div className="mt-12 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8 px-2 md:px-0">
            {values.map((v, idx) => (
              <motion.div
                key={v.title}
                className="rounded-3xl border border-slate-300/40 dark:border-white/10 bg-white/5 p-6 text-right flex flex-col items-start gap-4"
                variants={enterAnimation}
                custom={idx + 1}
              >
                <div className="text-blue-600">{v.icon}</div>
                <h3 className="text-xl font-bold">{v.title}</h3>
                <p className="text-sm text-slate-600 dark:text-slate-300 leading-relaxed">
                  {v.desc}
                </p>
              </motion.div>
            ))}
          </div>
        </motion.div>
      </div>

      {/* روند کار */}
      <div className="max-w-6xl mx-auto px-2 sm:px-6 md:px-0 pb-20">
        <motion.div
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
          variants={{
            visible: { transition: { staggerChildren: 0.15, delayChildren: 0.3 } },
          }}
          className="text-center"
        >
          <motion.h2
            variants={enterAnimation}
            custom={0}
            className="text-3xl sm:text-4xl font-bold mb-12"
          >
            چجوری کار می‌کنیم؟ خیلی ساده:
          </motion.h2>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {[
              {
                n: "01",
                t: "پاکت رویایی‌ات رو انتخاب کن",
                d: "یه پاکت دلپذیر پیدا کن که حرفت رو قشنگ‌تر کنه.",
              },
              {
                n: "02",
                t: "متن دلت رو باکیفیت بنویس",
                d: "بدون استرس، هرچی تو دلت هست رو بنویس، ما کارمون اینه که قشنگ چاپش کنیم.",
              },
              {
                n: "03",
                t: "دست به کار چاپ و بسته‌بندی",
                d: "متنت چاپ میشه و تو پاکت قرار می‌گیره، مثل یه ابزار جادویی.",
              },
              {
                n: "04",
                t: "نامه میره به مقصدش",
                d: "ما نامه رو میفرستیم تا برسد دست اون که باید حسش کنه.",
              },
            ].map((x, idx) => (
              <motion.div
                key={x.n}
                className="rounded-3xl border border-slate-300/40 dark:border-white/10 bg-white/5 p-6 text-right"
                variants={enterAnimation}
                custom={idx + 1}
              >
                <div className="text-blue-500 font-bold text-lg">{x.n}</div>
                <div className="mt-2 text-lg font-semibold">{x.t}</div>
                <div className="mt-1 text-sm text-slate-600 dark:text-slate-300 leading-relaxed">
                  {x.d}
                </div>
              </motion.div>
            ))}
          </div>
        </motion.div>
          </div>
          
          {/* اعتمادسازی */}
<div className="max-w-6xl mx-auto px-2 sm:px-6 md:px-0 py-20">
  <motion.div
    initial="hidden"
    whileInView="visible"
    viewport={{ once: true }}
    variants={{
      visible: { transition: { staggerChildren: 0.15, delayChildren: 0.2 } },
    }}
    className="text-center"
  >
    <motion.h2
      variants={enterAnimation}
      custom={0}
      className="text-3xl sm:text-4xl font-extrabold"
    >
      چجوری به ما اعتماد کنید؟
    </motion.h2>

    <motion.p
      variants={enterAnimation}
      custom={1}
      className="mt-4 max-w-2xl mx-auto text-slate-600 dark:text-slate-300 leading-relaxed"
    >
      کاملاً طبیعیه که قبل از ثبت سفارش بخوای مطمئن شی.  
      بالاخره داری یه حس واقعی رو می‌سپاری دست ما.  
      برای همین چند تا نکته مهم هست که خیالت رو راحت می‌کنه.
    </motion.p>

    <div className="mt-14 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
      {[
        {
          title: "نماد اعتماد الکترونیکی",
          desc: "سایت ما دارای نماد اینماد هست. یعنی هویت و فعالیت سایت توسط مراجع رسمی بررسی شده. می‌تونی از پایین سایت روی نماد کلیک کنی و اطلاعاتش رو ببینی.",
        },
        {
          title: "پرداخت امن با زرین‌پال",
          desc: "پرداخت‌ها از طریق درگاه معتبر زرین‌پال انجام میشه. یعنی اطلاعات کارت بانکی اصلاً داخل سایت ما ذخیره نمی‌شه و مستقیم داخل درگاه امن پرداخت می‌کنی.",
        },
        {
          title: "حفظ حریم خصوصی",
          desc: "متن نامه‌ای که می‌نویسی فقط برای چاپ استفاده میشه. نه جایی منتشر میشه نه استفاده دیگه‌ای ازش می‌کنیم. احترام به حریم خصوصی برای ما جدیه.",
        },
        {
          title: "پشتیبانی واقعی",
          desc: "اگر هر سوال یا مشکلی داشته باشی، تیم پشتیبانی پاسخگو هست. ما ترجیح میدیم مشکل سریع حل بشه تا اینکه کاربر ناراضی بمونه.",
        },
      ].map((item, idx) => (
        <motion.div
          key={item.title}
          variants={enterAnimation}
          custom={idx + 2}
          className="rounded-3xl border border-slate-300/40 dark:border-white/10 bg-white/5 backdrop-blur p-6 text-right shadow-md hover:shadow-xl transition-all"
        >
          <div className="text-blue-500 font-bold text-lg">
            {item.title}
          </div>
          <p className="mt-3 text-sm text-slate-600 dark:text-slate-300 leading-relaxed">
            {item.desc}
          </p>
        </motion.div>
      ))}
    </div>

    <motion.div
      variants={enterAnimation}
      custom={6}
      className="mt-16 rounded-3xl border border-slate-300/40 dark:border-white/10 bg-gradient-to-r from-blue-500/10 to-purple-500/10 p-10"
    >
      <p className="text-sm text-slate-600 dark:text-slate-300 max-w-2xl mx-auto leading-relaxed">
        اگر هنوز شک داری، کاملاً حق داری. پیشنهاد می‌کنیم یه نگاه به پایین سایت بندازی.  
        اونجا می‌تونی نماد اعتماد  (اینماد) و اطلاعات پرداخت امن زرین‌پال رو ببینی.  
                (بخدا پولتو نمیخوریم 🙏🥀)
      </p>
    </motion.div>
  </motion.div>
</div>


      {/* سوالات متداول */}
      <div className="max-w-6xl mx-auto px-2 sm:px-6 md:px-0 py-16">
        <motion.div
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
          variants={{
            visible: { transition: { staggerChildren: 0.15, delayChildren: 0.2 } },
          }}
        >
          <motion.h2
            variants={enterAnimation}
            custom={0}
            className="text-3xl sm:text-4xl font-bold text-center"
          >
           سوالایی که شاید جوابشون رو بخوای!
          </motion.h2>

          <div className="mt-10 space-y-5 max-w-4xl mx-auto px-4">
            {faqs.map((f, idx) => (
              <motion.details
                key={f.q}
                className="rounded-3xl border border-slate-300/40 dark:border-white/10 bg-white/5 p-6 cursor-pointer"
                variants={enterAnimation}
                custom={idx + 1}
              >
                <summary className="font-bold select-none">{f.q}</summary>
                <p className="mt-3 text-sm text-slate-600 dark:text-slate-300 leading-relaxed">
                  {f.a}
                </p>
              </motion.details>
            ))}
          </div>
        </motion.div>
      </div>

          
      {/* CTA */}
      <div className="max-w-6xl mx-auto px-4 md:px-0 pb-20">
        <motion.div
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
          variants={enterAnimation}
          custom={0}
          className="rounded-3xl border border-slate-300/40 dark:border-white/10 bg-white/5 p-10 text-center"
        >
          <h2 className="text-3xl sm:text-4xl font-extrabold">
            آماده‌ای یه نامه واقعی بسازی؟
          </h2>
          <p className="mt-4 text-slate-600 dark:text-slate-300 leading-relaxed max-w-md mx-auto">
            فقط پاکت و متن رو انتخاب کن، بقیه‌ش رو بسپر دست ما؛  
            ما با عشق و دقت همه چی رو برات انجام می‌دیم.
          </p>

          <div className="mt-8 flex justify-center gap-4 flex-wrap">
            <Link
              href="/letters"
              className="px-8 py-3 rounded-full bg-gradient-to-r from-blue-500 to-blue-600 text-white font-bold shadow-lg hover:scale-[1.03] transition-transform"
            >
              شروع سفارش
            </Link>
            <Link
              href="/support"
              className="px-8 py-3 rounded-full border border-slate-300/40 dark:border-white/10 text-slate-700 dark:text-slate-200 hover:bg-white/10 transition"
            >
              پشتیبانی
            </Link>
          </div>
        </motion.div>
      </div>

      {/* FOOTER */}
      <footer
        ref={footerRef}
        className="max-w-6xl mx-auto px-6 py-12 border-t border-slate-300/40 dark:border-white/10 text-right text-sm text-slate-700 dark:text-slate-300"
      >
    
      </footer>
    </div>
  );
}
