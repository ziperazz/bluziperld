"use client";

import { useState, useEffect, useMemo, useRef } from "react";
import {
  Truck,
  ShoppingCart,
  CreditCard,
  CheckCircle2,
  ChevronRight,
} from "lucide-react";
import Link from "next/link";
import { useRouter } from "next/navigation";

const isValidToken = (token: string) => {
  try {
    const payload = JSON.parse(atob(token.split(".")[1]));
    if (!payload) return false;

    if (payload.exp) {
      const now = Date.now() / 1000;
      if (payload.exp < now) return false;
    }

    return true;
  } catch {
    return false;
  }
};

const phoneRegex = /^09\d{9}$/;
const postalCodeRegex = /^\d{10}$/;


/* --------------------------------------
   روش‌های ارسال
-----------------------------------------*/
const shippingMethods = [
  {
    id: "post",
    title: "پست",
    description: "تحویل ۳ تا ۵ روز کاری – اقتصادی و قابل پیگیری",
    active: true,
  },
  {
    id: "tipax",
    title: "تیپاکس",
    description: "تحویل سریع ۱ تا ۲ روز کاری – هزینه بیشتر",
    active: false,
  },
  {
    id: "chapar",
    title: "چاپار",
    description: "ارسال فوق سریع برون‌شهری",
    active: true,
  },
  {
    id: "snapp",
    title: "اسنپ‌باکس",
    description: "ارسال فوری داخل شهر – تحویل ۳۰ تا ۹۰ دقیقه",
    active: false,
  },
] as const;

type ShippingMethodId = (typeof shippingMethods)[number]["id"];

export default function ShippingPage() {
  const router = useRouter();

  useEffect(() => {
const token = localStorage.getItem("accessToken");


  if (!token || !isValidToken(token)) {
    localStorage.removeItem("accessToken");

    router.push("/auth");
  }
}, [router]);


  const [fullName, setFullName] = useState("");
  const [phone, setPhone] = useState("");
  const [address, setAddress] = useState("");
  const [province, setProvince] = useState(""); // input متنی برای استان
  const [city, setCity] = useState(""); // input متنی برای شهر
  const [postalCode, setPostalCode] = useState("");
  const [method, setMethod] = useState<ShippingMethodId>("post");
  const [customerNote, setCustomerNote] = useState("");

  const [shippingPrice, setShippingPrice] = useState<number | null>(null);
  const [loadingPrice, setLoadingPrice] = useState(false);

  const noteRef = useRef<HTMLTextAreaElement | null>(null);
  const maxNoteChars = 350;

  useEffect(() => {
    if (!noteRef.current) return;
    noteRef.current.style.height = "auto";
    noteRef.current.style.height = noteRef.current.scrollHeight + "px";
  }, [customerNote]);

  useEffect(() => {
    // قیمت ثابت فقط برای پست و چاپار به درخواست شما
    setLoadingPrice(true);
    if (method === "post") {
      setShippingPrice(163000);
    } else if (method === "chapar") {
      setShippingPrice(237000);
    } else {
      setShippingPrice(null);
    }
    setLoadingPrice(false);
  }, [method]);

  useEffect(() => {
    try {
      const saved = localStorage.getItem("shippingInfo");
      if (saved) {
        const info = JSON.parse(saved);
        setFullName(info.fullName || "");
        setPhone(info.phone || "");
        setAddress(info.address || "");
        setProvince(info.province || "");
        setCity(info.city || "");
        setPostalCode(info.postalCode || "");
        // اگر روش غیر فعال بوده، فرض کن پست انتخاب باشه
        if (info.shippingMethod === "post" || info.shippingMethod === "chapar") {
          setMethod(info.shippingMethod);
        } else {
          setMethod("post");
        }
        setCustomerNote(info.note || "");
      }
    } catch (error) {
      console.error("Error loading shipping info:", error);
    }
  }, []);

  const [touched, setTouched] = useState(false);
  const [submitError, setSubmitError] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

const errors = useMemo(() => {
  const e: Record<string, string> = {};

  if (!fullName.trim()) {
    e.fullName = "نام و نام خانوادگی را وارد کنید";
  }

  if (!phone.trim()) {
    e.phone = "شماره تماس را وارد کنید";
  } else if (!phoneRegex.test(phone)) {
    e.phone = "شماره موبایل معتبر نیست (مثال: 09123456789)";
  }

  if (!address.trim()) {
    e.address = "آدرس کامل را وارد کنید";
  }

  if (!province.trim()) {
    e.province = "استان را وارد کنید";
  }

  if (!city.trim()) {
    e.city = "شهر را وارد کنید";
  }

  if (!postalCode.trim()) {
    e.postalCode = "کد پستی را وارد کنید";
  } else if (!postalCodeRegex.test(postalCode)) {
    e.postalCode = "کد پستی باید ۱۰ رقم باشد";
  }

  return e;
}, [fullName, phone, address, province, city, postalCode]);


  const isValid = Object.keys(errors).length === 0;

  const onSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setTouched(true);
    if (!isValid) {
      setSubmitError("لطفاً اطلاعات را کامل کنید.");
      return;
    }

    const payload = {
      fullName,
      phone,
      address,
      province,
      city,
      postalCode,
      shippingMethod: method,
      shippingPrice,
      note: customerNote,
    };

    try {
      setIsSubmitting(true);
      localStorage.setItem("shippingInfo", JSON.stringify(payload));
      router.push("/payment");
    } catch (error) {
      setSubmitError("خطا در ذخیره اطلاعات.");
    } finally {
      setIsSubmitting(false);
    }
  };

  const shortNote =
    customerNote.length > 20
      ? customerNote.slice(0, 20) + "..."
      : customerNote;

  return (
    <div className="min-h-screen bg-[#050A18] text-gray-100 p-3 md:p-6 pb-20">
      <div className="max-w-5xl mx-auto">
        {/* Steps */}
        <div className="flex items-center justify-center mb-8 gap-2 md:gap-3">
          <StepItem icon={<ShoppingCart size={18} />} label="سبد خرید" />
          <StepLine />
          <StepItem icon={<Truck size={18} />} label="اطلاعات ارسال" active />
          <StepLine />
          <StepItem icon={<CreditCard size={18} />} label="پرداخت" />
          <StepLine />
          <StepItem icon={<CheckCircle2 size={18} />} label="پایان" />
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <form onSubmit={onSubmit} className="lg:col-span-2 space-y-6">
            <SectionTitle title="اطلاعات گیرنده" />

            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              <Field
                label="نام و نام خانوادگی"
                value={fullName}
                onChange={setFullName}
                placeholder="مثلاً: علی رضایی"
                error={touched ? errors.fullName : undefined}
              />
              <Field
                label="شماره تماس"
                value={phone}
                onChange={setPhone}
                placeholder="مثلاً: ۰۹۱۲..."
                error={touched ? errors.phone : undefined}
              />
            </div>

            <Field
              label="آدرس کامل"
              value={address}
              onChange={setAddress}
              placeholder="خیابان، پلاک، واحد..."
              error={touched ? errors.address : undefined}
            />

            {/* استان و شهر به ورودی متنی تبدیل شدند */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
              <Field
                label="استان"
                value={province}
                onChange={setProvince}
                placeholder="مثلاً: تهران"
                error={touched ? errors.province : undefined}
              />

              <Field
                label="شهر"
                value={city}
                onChange={setCity}
                placeholder="مثلاً: تهران"
                error={touched ? errors.city : undefined}
              />

              <Field
                label="کد پستی"
                value={postalCode}
                onChange={setPostalCode}
                placeholder="۱۰ رقمی"
                error={touched ? errors.postalCode : undefined}
              />
            </div>

            {/* روش ارسال */}
            <SectionTitle title="انتخاب روش ارسال" />

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {shippingMethods.map((m) => (
                <button
                  key={m.id}
                  type="button"
                  disabled={!m.active}
                  onClick={() => m.active && setMethod(m.id)}
                  className={`text-right p-4 rounded-2xl border transition backdrop-blur-xl ${
                    m.id === method
                      ? "border-blue-500/40 bg-blue-500/10 shadow-[0_0_18px_rgba(37,99,235,0.20)]"
                      : "border-white/10 bg-white/5 hover:bg-white/10"
                  } ${
                    !m.active ? "opacity-40 grayscale cursor-not-allowed" : ""
                  }`}
                >
                  <div className="flex items-center justify-between gap-3">
                    <span className="font-semibold text-sm">{m.title}</span>
                    {m.active && (
                      <span
                        className={`w-2.5 h-2.5 rounded-full transition ${
                          m.id === method
                            ? "bg-blue-400 shadow-[0_0_10px_rgba(59,130,246,0.45)]"
                            : "bg-white/20"
                        }`}
                      />
                    )}
                  </div>
                  <p className="text-[11px] mt-1 leading-5 text-gray-400">
                    {m.active ? m.description : "فعلاً در دسترس نیست"}
                  </p>
                </button>
              ))}
            </div>

            {/* توضیحات */}
            <div className="p-4 rounded-2xl border border-white/10 bg-white/5 backdrop-blur-md space-y-3">
              <label className="text-xs text-gray-400">
                توضیحات شما (اختیاری)
              </label>
              <textarea
                ref={noteRef}
                value={customerNote}
                maxLength={maxNoteChars}
                onChange={(e) => setCustomerNote(e.target.value)}
                className="w-full px-3 py-2 text-sm rounded-xl bg-black/20 border border-white/10 text-gray-200 placeholder:text-gray-500 outline-none transition focus:border-blue-500/60 resize-none overflow-y-auto max-h-[140px]"
                placeholder="اگر توضیح خاصی برای مرسوله دارید..."
              />
              <div className="w-full h-1 rounded-full bg-black/30 overflow-hidden">
                <div
                  className="h-full bg-blue-500 transition-all"
                  style={{
                    width: `${(customerNote.length / maxNoteChars) * 100}%`,
                  }}
                />
              </div>
              <p className="text-[11px] text-gray-400 text-left">
                {customerNote.length} / {maxNoteChars}
              </p>
            </div>

            <div className="flex flex-col sm:flex-row gap-3 sm:items-center sm:justify-between pt-2">
              <button
                type="submit"
                disabled={isSubmitting}
                className="w-full sm:w-auto flex-1 py-3 rounded-xl text-white font-semibold text-sm transition hover:scale-[1.02] active:scale-95 flex items-center justify-center gap-2"
                style={{
                  background: "linear-gradient(135deg,#2563eb,#3b82f6)",
                }}
              >
                {isSubmitting ? "در حال ذخیره و ادامه..." : "ادامه تا پرداخت"}
                <ChevronRight size={18} className="rotate-180" />
              </button>

              <Link
                href="/cart"
                className="text-center sm:w-auto py-2 px-3 rounded-xl border border-white/10 bg-white/5 hover:bg-white/10 transition text-sm text-gray-200"
              >
                ← بازگشت به سبد خرید
              </Link>
            </div>

            {submitError && (
              <p className="text-red-400 text-xs mt-2">{submitError}</p>
            )}
          </form>

          {/* Sidebar Summary */}
          <aside className="lg:col-span-1">
            <div
              className="sticky top-24 p-4 rounded-2xl border border-white/10"
              style={{
                background: "rgba(15,16,22,0.75)",
                backdropFilter: "blur(30px)",
                boxShadow: "0 12px 35px rgba(0,0,0,0.35)",
              }}
            >
              <h3 className="text-base font-bold mb-4 text-white border-b border-white/5 pb-3">
                چک اجمالی
              </h3>
              <div className="space-y-3 text-sm">
                <Row label="نام گیرنده" value={fullName || "—"} />
                <Row label="شماره تماس" value={phone || "—"} />
                <Row
                  label="استان / شهر"
                  value={
                    province || city
                      ? `${province || "—"} / ${city || "—"}`
                      : "—"
                  }
                />
                <Row label="کد پستی" value={postalCode || "—"} />
                <Row
                  label="روش ارسال"
                  value={
                    shippingMethods.find((m) => m.id === method)?.title || "—"
                  }
                />
                <Row
                  label="هزینه ارسال"
                  value={
                    loadingPrice
                      ? "در حال محاسبه..."
                      : shippingPrice !== null
                      ? `${shippingPrice.toLocaleString()} تومان`
                      : "—"
                  }
                />
                <Row label="توضیحات" value={shortNote || "—"} />
              </div>
            </div>
          </aside>
        </div>
      </div>
    </div>
  );
}

/* ---------------- HELPER COMPONENTS ---------------- */

function SectionTitle({ title }: { title: string }) {
  return (
    <div className="flex items-center justify-between">
      <h3 className="text-sm font-semibold text-white">{title}</h3>
      <span className="text-[11px] text-gray-500">—</span>
    </div>
  );
}

function Field({ label, value, onChange, placeholder, error }: any) {
  return (
    <div className="space-y-2">
      <label className="text-xs text-gray-400">{label}</label>
      <input
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder={placeholder}
        className={`w-full px-3 py-2 text-sm rounded-xl bg-black/20 text-gray-200 placeholder:text-gray-500 border ${
          error ? "border-red-500/40" : "border-white/10"
        } outline-none transition focus:border-blue-500/60`}
      />
      {error && <p className="text-red-400 text-[11px]">{error}</p>}
    </div>
  );
}

function Row({ label, value }: any) {
  return (
    <div className="flex items-center justify-between gap-3">
      <span className="text-gray-400 text-xs">{label}</span>
      <span className="text-gray-200 text-xs font-medium">{value}</span>
    </div>
  );
}

function StepItem({ icon, label, active = false }: any) {
  return (
    <div className="flex flex-col items-center gap-1.5">
      <div
        className={`w-10 h-10 rounded-xl flex items-center justify-center transition ${
          active
            ? "bg-blue-600 text-white shadow-[0_0_14px_rgba(37,99,235,0.45)]"
            : "bg-white/5 text-gray-500 border border-white/5"
        }`}
      >
        {icon}
      </div>
      <span
        className={`text-[10px] md:text-[11px] whitespace-nowrap ${
          active ? "text-white" : "text-gray-500"
        }`}
      >
        {label}
      </span>
    </div>
  );
}

function StepLine() {
  return <div className="w-6 md:w-10 h-[2px] bg-white/5 mb-5" />;
}
