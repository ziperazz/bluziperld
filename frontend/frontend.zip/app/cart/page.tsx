"use client"

import { useState, useEffect } from "react"
import {
  Trash2, Plus, Minus, ChevronRight,
  ShoppingCart, Truck, CreditCard, CheckCircle2
} from "lucide-react"
import Link from "next/link"
import { useRouter } from "next/navigation"

const isValidToken = (token: string) => {
  try {
    const payload = JSON.parse(atob(token.split(".")[1]))

    if (!payload) return false

    if (payload.exp) {
      const now = Date.now() / 1000
      if (payload.exp < now) return false
    }

    return true
  } catch {
    return false
  }
}


const discountCodes: any = {
  off20: { type: "percent", value: 20 },
  off50k: { type: "fixed", value: 50000 },
}

export default function CartPage() {

  const router = useRouter()
  const [items, setItems] = useState<any[]>([])
  const [loading, setLoading] = useState(true)

  const [discountInput, setDiscountInput] = useState("")
  const [discount, setDiscount] = useState(0)
  const [discountError, setDiscountError] = useState("")
  const [discountInfo, setDiscountInfo] = useState<{ type: string; value: number } | null>(null)

  const [toast, setToast] = useState<{ show: boolean, message: string }>({
    show: false,
    message: ""
  })

  const showToast = (message: string) => {
    setToast({ show: true, message })
    setTimeout(() => {
      setToast({ show: false, message: "" })
    }, 4000)
  }

  const loadCart = () => {
    const saved = JSON.parse(localStorage.getItem("cart") || "[]")
    setItems(saved)
    setLoading(false)
  }

  useEffect(() => {

    loadCart()

    const handler = () => loadCart()
    window.addEventListener("cart-updated", handler)

    return () => window.removeEventListener("cart-updated", handler)

  }, [])

  const handleCheckout = () => {

    if (items.length === 0) return

    const hasLetter = items.some(i => i.productType === "letter")
    const hasProduct = items.some(i => i.productType !== "letter")

    if (hasLetter && hasProduct) {
      showToast("پاکت نامه باید فقط به تنهایی ثبت سفارش شود")
      return
    }

const token = localStorage.getItem("accessToken");

if (!token || !isValidToken(token)) {
  localStorage.removeItem("accessToken");
  router.push("/auth")
  return
}

router.push("/shipping")


  }

  const updateQty = (productId: string, delta: number, currentQty: number) => {

    const newQty = Math.max(1, currentQty + delta)

    const updated = items.map(i =>
      i.productId === productId
        ? { ...i, quantity: newQty }
        : i
    )

    setItems(updated)
    localStorage.setItem("cart", JSON.stringify(updated))
    window.dispatchEvent(new Event("cart-updated"))

  }

  const removeItem = (productId: string) => {

    const updated = items.filter(i => i.productId !== productId)

    setItems(updated)
    localStorage.setItem("cart", JSON.stringify(updated))
    window.dispatchEvent(new Event("cart-updated"))

  }

  const subtotal = items.reduce(
    (acc, item) => acc + item.price * item.quantity,
    0
  )

  const applyDiscount = () => {

    const code = discountInput.trim().toLowerCase()

    if (!discountCodes[code]) {
      setDiscountError("کد تخفیف نامعتبر است")
      setDiscount(0)
      setDiscountInfo(null)
      return
    }

    setDiscountError("")
    const info = discountCodes[code]

    setDiscountInfo(info)

    if (info.type === "percent") {
      setDiscount((subtotal * info.value) / 100)
    } else {
      setDiscount(info.value)
    }

  }

  const finalPrice = Math.max(0, subtotal - discount)

  if (loading)
    return (
      <div className="h-screen flex items-center justify-center text-gray-300 bg-[#0F1016]">
        در حال بارگذاری سبد خرید...
      </div>
    )

  return (

    <div className="min-h-screen bg-[#050A18] text-gray-100 p-3 md:p-6 pb-20">

      {toast.show && <Toast message={toast.message} />}

      <div className="max-w-5xl mx-auto">

        <div className="flex items-center justify-center mb-8 gap-2 md:gap-3">
          <StepItem icon={<ShoppingCart size={18} />} label="بررسی سبد" active />
          <StepLine />
          <StepItem icon={<Truck size={18} />} label="اطلاعات ارسال" />
          <StepLine />
          <StepItem icon={<CreditCard size={18} />} label="پرداخت" />
          <StepLine />
          <StepItem icon={<CheckCircle2 size={18} />} label="پایان" />
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">

          <div className="lg:col-span-2 space-y-3">

            <h2 className="text-lg font-bold mb-4 flex items-center gap-2">
              <span className="w-1.5 h-6 bg-blue-600 rounded-full"></span>
              سبد خرید ({items.length})
            </h2>

            {items.length === 0 && (
              <div className="text-center py-20 border border-white/5 rounded-3xl bg-white/5">
                <p className="text-gray-400 text-sm mb-4">سبد خرید شما خالی است.</p>
                <Link href="/letters" className="text-blue-500 text-xs hover:underline">
                  مشاهده محصولات
                </Link>
              </div>
            )}

            {items.map((item) => (

              <div
                key={item.productId}
                className="relative group flex flex-col sm:flex-row items-center gap-4 p-3 rounded-2xl border border-white/5 hover:border-white/10 transition"
                style={{
                  background: "linear-gradient(145deg, rgba(255,255,255,0.03), rgba(255,255,255,0.01))",
                  backdropFilter: "blur(10px)",
                }}
              >

                <div className="w-20 h-20 rounded-xl overflow-hidden flex-shrink-0 border border-white/5">
                  <img
                    src={item.image || "/images/letter1.jpg"}
                    alt={item.title}
                    className="w-full h-full object-cover transition group-hover:scale-105"
                  />
                </div>

                <div className="flex-grow text-center sm:text-right">

                  <h3 className="text-sm font-semibold text-white mb-1">
                    {item.title || (item.productType === "letter" ? "نامه" : "محصول")}
                  </h3>

                  {item.productType === "letter" && item.letterText && (
  <p 
    className="text-[12px] text-gray-400 mb-2 leading-relaxed break-all overflow-hidden"
    style={{ wordBreak: 'break-all' }} // این استایل برای اطمینان بیشتر از شکستن متن
  >
    {item.letterText.length > 80
      ? item.letterText.slice(0, 80) + "..."
      : item.letterText}
  </p>
)}


                  <p className="text-[11px] text-gray-500 mb-2">
                    کد کالا: {item.productId}
                  </p>

                  <span className="text-blue-400 text-sm font-semibold">
                    {(item.price * item.quantity).toLocaleString()} تومان
                  </span>

                </div>

                <div className="flex items-center gap-3 bg-black/30 px-3 py-1.5 rounded-xl border border-white/5">

                  <button
                    onClick={() => updateQty(item.productId, 1, item.quantity)}
                    className="text-blue-400 hover:text-blue-300"
                  >
                    <Plus size={16} />
                  </button>

                  <span className="text-sm w-5 text-center">
                    {item.quantity}
                  </span>

                  {item.quantity > 1 ? (
                    <button
                      onClick={() => updateQty(item.productId, -1, item.quantity)}
                      className="text-gray-400 hover:text-white"
                    >
                      <Minus size={16} />
                    </button>
                  ) : (
                    <button
                      onClick={() => removeItem(item.productId)}
                      className="text-red-400/70 hover:text-red-400"
                    >
                      <Trash2 size={16} />
                    </button>
                  )}

                </div>

              </div>

            ))}

          </div>

          <div className="lg:col-span-1">

            <div
              className="sticky top-24 p-4 rounded-2xl border border-white/10"
              style={{
                background: "rgba(15,16,22,0.75)",
                backdropFilter: "blur(30px)",
                boxShadow: "0 12px 35px rgba(0,0,0,0.35)",
              }}
            >

              <h3 className="text-base font-bold mb-4 text-white border-b border-white/5 pb-3">
                خلاصه سفارش
              </h3>

              <div className="space-y-3 mb-6">

                <div className="flex justify-between text-gray-400 text-sm">
                  <span>قیمت کالاها</span>
                  <span>{subtotal.toLocaleString()} تومان</span>
                </div>

                {discount > 0 && (
                  <div className="flex justify-between text-green-400 text-sm">
                    <span>تخفیف</span>
                    <span>{discount.toLocaleString()} تومان</span>
                  </div>
                )}

                <div className="flex justify-between text-gray-400 text-sm">
                  <span>هزینه ارسال</span>
                  <span className="text-green-400 text-xs">
                    وابسته به آدرس
                  </span>
                </div>

                <div className="pt-3 border-t border-white/5 flex justify-between items-center">

                  <span className="text-sm font-semibold text-white">
                    جمع کل
                  </span>

                  <span className="text-lg font-bold text-blue-500">
                    {finalPrice.toLocaleString()}
                    <span className="text-xs font-normal"> تومان</span>
                  </span>

                </div>

              </div>

              <button
                onClick={handleCheckout}
                disabled={items.length === 0}
                className="w-full py-3 rounded-xl text-white font-semibold text-sm transition hover:scale-[1.02] active:scale-95 flex items-center justify-center gap-2 disabled:opacity-50"
                style={{ background: "linear-gradient(135deg,#2563eb,#3b82f6)" }}
              >
                ثبت و ادامه سفارش
                <ChevronRight size={18} className="rotate-180" />
              </button>

            </div>

          </div>

        </div>

      </div>

    </div>

  )
}

function Toast({ message }: { message: string }) {
  return (
    <div className="fixed top-6 left-1/2 -translate-x-1/2 z-50">
      <div
        className="px-5 py-3 rounded-xl border border-red-500/30 text-sm text-white shadow-xl"
        style={{
          background: "rgba(20,20,25,0.85)",
          backdropFilter: "blur(12px)"
        }}
      >
        <div className="flex items-center gap-3">
          <div className="w-2.5 h-2.5 rounded-full bg-red-500 animate-pulse"></div>
          <span>{message}</span>
        </div>
      </div>
    </div>
  )
}

function StepItem({ icon, label, active = false }: { icon: any, label: string, active?: boolean }) {

  return (

    <div className="flex flex-col items-center gap-1.5">

      <div
        className={`
        w-10 h-10 rounded-xl flex items-center justify-center transition
        ${active
          ? "bg-blue-600 text-white shadow-[0_0_14px_rgba(37,99,235,0.45)]"
          : "bg-white/5 text-gray-500 border border-white/5"
        }
      `}
      >
        {icon}
      </div>

      <span className={`text-[10px] md:text-[11px] whitespace-nowrap ${active ? "text-white" : "text-gray-500"}`}>
        {label}
      </span>

    </div>

  )

}

function StepLine() {
  return <div className="w-6 md:w-10 h-[2px] bg-white/5 mb-5" />
}
